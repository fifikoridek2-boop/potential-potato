import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  Plus, 
  Trash2, 
  Check, 
  TrendingUp, 
  ShoppingBag, 
  Users, 
  Database,
  ArrowRight,
  ShieldCheck,
  UserPlus,
  ArrowLeftRight,
  Sparkles,
  Search,
  CheckCircle,
  Clock,
  Settings,
  Mail,
  RefreshCw,
  Eye,
  EyeOff,
  Sliders,
  Globe,
  AlertCircle
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { Order, OrderStatus } from '../types';

export const Admin: React.FC = () => {
  const {
    locale,
    currency,
    formatPrice,
    showToast,
    orders,
    usersList,
    settings,
    updateSettings,
    updateOrder,
    seedAllDatabase,
    resetAndReinitDatabase,
    getOranosConfig,
    updateOranosConfig,
    syncOranosCatalog
  } = useStore();

  // Tabs strictly restricted to the sections requested, adding automated API configuration
  const [activeTab, setActiveTab] = useState<'stats' | 'orders' | 'add_admin' | 'oranos_api'>('stats');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');

  // Oranos Integration state variables
  const [oranosConfig, setOranosConfig] = useState<any>(null);
  const [oranosApiTokenInput, setOranosApiTokenInput] = useState('');
  const [isFetchingConfig, setIsFetchingConfig] = useState(false);
  const [isSavingToken, setIsSavingToken] = useState(false);
  const [isSyncingProducts, setIsSyncingProducts] = useState(false);
  const [showToken, setShowToken] = useState(false);

  // Stats Calculations
  const completedOrders = orders.filter(o => o.status === 'completed');
  
  // Calculate total earnings converted back appropriately to USD representation
  const totalVolumeUSD = completedOrders.reduce((sum, o) => sum + o.total, 0);

  const pendingOrders = orders.filter(o => !['completed', 'canceled'].includes(o.status));
  const activeAdmins = settings?.adminEmails || ['akiocodex1@gmail.com'];

  const getOrderStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'completed':
        return 'text-emerald-400 bg-emerald-950/40 border border-emerald-900/50';
      case 'canceled':
        return 'text-rose-400 bg-rose-950/40 border border-rose-900/50';
      case 'processing':
        return 'text-amber-400 bg-amber-950/40 border border-amber-900/50';
      default:
        return 'text-blue-400 bg-blue-950/40 border border-blue-900/50';
    }
  };

  const getOrderStatusText = (status: OrderStatus) => {
    if (locale === 'ar') {
      if (status === 'completed') return 'مكتمل ومكتسب';
      if (status === 'canceled') return 'ملغي';
      if (status === 'processing') return 'قيد المعالجة';
      return 'انتظار المراجعة';
    }
    return status;
  };

  // Add Admin Email logic
  const handleAddAdmin = () => {
    if (!newAdminEmail.trim()) {
      showToast(locale === 'ar' ? 'الرجاء إدخال بريد إلكتروني صالح.' : 'Please enter a valid email.', 'error');
      return;
    }
    if (!newAdminEmail.includes('@')) {
      showToast(locale === 'ar' ? 'نموذج البريد الإلكتروني غير صحيح.' : 'Invalid email pattern.', 'error');
      return;
    }

    const currentEmails = Array.isArray(activeAdmins) ? [...activeAdmins] : [activeAdmins];
    
    if (currentEmails.includes(newAdminEmail.trim())) {
      showToast(locale === 'ar' ? 'هذا المسؤول مسجل بالفعل!' : 'Admin already exist!', 'error');
      return;
    }

    const updated = [...currentEmails, newAdminEmail.trim()];
    updateSettings({
      ...settings,
      adminEmails: updated
    });

    setNewAdminEmail('');
    showToast(locale === 'ar' ? 'تم إضافة المسؤول الجديد بنجاح.' : 'New admin added successfully.', 'success');
  };

  const handleRemoveAdmin = (email: string) => {
    const currentEmails = Array.isArray(activeAdmins) ? [...activeAdmins] : [activeAdmins];
    if (currentEmails.length <= 1) {
      showToast(locale === 'ar' ? 'لا يمكن حذف المسؤول الأخير!' : 'Cannot delete the only admin!', 'error');
      return;
    }

    const updated = currentEmails.filter(e => e !== email);
    updateSettings({
      ...settings,
      adminEmails: updated
    });
    showToast(locale === 'ar' ? 'تمت إزالة المسؤول بنجاح.' : 'Admin removed successfully.', 'success');
  };

  // Fetch Oranos API on Tab Shift
  const fetchOranosConfig = async () => {
    setIsFetchingConfig(true);
    try {
      const config = await getOranosConfig();
      setOranosConfig(config);
      if (config && config.configured) {
        setOranosApiTokenInput(config.maskedToken || '');
      }
    } catch (err) {
      console.error("fetchOranosConfig failed:", err);
    } finally {
      setIsFetchingConfig(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'oranos_api') {
      fetchOranosConfig();
    }
  }, [activeTab]);

  const handleSaveOranosToken = async () => {
    if (!oranosApiTokenInput.trim()) {
      showToast(locale === 'ar' ? 'الرجاء إدخال توكن صالح' : 'Please enter a valid Token', 'error');
      return;
    }
    setIsSavingToken(true);
    try {
      const data = await updateOranosConfig(oranosApiTokenInput.trim());
      if (data.success) {
        showToast(
          locale === 'ar' 
            ? 'تم حفظ وتوثيق مفتاح وربط حساب Oranos API بنجاح!' 
            : 'Oranos API Token saved and verified successfully!', 
          'success'
        );
        fetchOranosConfig();
      } else {
        showToast(data.error || 'Authorization failed', 'error');
      }
    } catch (err: any) {
      showToast(locale === 'ar' ? 'فشل التوثيق: الرمز المدخل غير فعال لدى Oranos' : 'Validation failed: Invalid token credentials', 'error');
    } finally {
      setIsSavingToken(false);
    }
  };

  const handleSyncOranosProducts = async () => {
    setIsSyncingProducts(true);
    try {
      const data = await syncOranosCatalog();
      if (data.success) {
        showToast(
          locale === 'ar'
            ? `تم شحن ومزامنة ${data.productsSynced} منتجاً و ${data.categoriesSynced} تصنيف بنجاح فوري!`
            : `Success! Synced ${data.productsSynced} items and ${data.categoriesSynced} catalog folders instantenously!`,
          'success'
        );
      } else {
        showToast(data.error || 'Synchronize transaction failed', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Downstream sync connection timeout error', 'error');
    } finally {
      setIsSyncingProducts(false);
    }
  };

  const handleApproveOrder = async (order: Order) => {
    try {
      const updatedOrder = {
        ...order,
        status: 'completed' as OrderStatus,
        trackingSteps: order.trackingSteps.map(step => ({
          ...step,
          completed: true,
          timestamp: new Date().toISOString()
        }))
      };
      await updateOrder(updatedOrder);
      showToast(locale === 'ar' ? 'تم إكمال الطلب بنجاح وتم تحويل الرصيد التلقائي للمحفظة!' : 'Order marked Completed! Balance sent.', 'success');
    } catch (e) {
      showToast('Error modifying order state', 'error');
    }
  };

  const handleCancelOrder = async (order: Order) => {
    try {
      const updatedOrder = {
        ...order,
        status: 'canceled' as OrderStatus
      };
      await updateOrder(updatedOrder);
      showToast(locale === 'ar' ? 'تم إلغاء طلب الشحن بنجاح.' : 'Order canceled successfully.', 'success');
    } catch (e) {
      showToast('Error', 'error');
    }
  };

  // Charts Source generator
  const getSalesTrend = () => {
    const trends: { [key: string]: number } = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', numberingSystem: 'latn' });
      trends[key] = 0;
    }

    completedOrders.forEach(o => {
      const dateKey = new Date(o.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric', numberingSystem: 'latn' });
      if (trends[dateKey] !== undefined) {
        trends[dateKey] += Math.round(o.total);
      }
    });

    return Object.keys(trends).map(key => ({ day: key, sales: trends[key] }));
  };

  // Filter queue of orders
  const filteredOrders = orders.filter(o => {
    const matchesSearch = o.id.toLowerCase().includes(orderSearch.toLowerCase()) || 
                          (o.userEmail && o.userEmail.toLowerCase().includes(orderSearch.toLowerCase())) ||
                          (o.userPhone && o.userPhone.includes(orderSearch));
    const matchesStatus = orderStatusFilter === 'all' || o.status === orderStatusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-[#07090e] text-white flex flex-col md:flex-row" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
      
      {/* Side Control Centre Navigation */}
      <aside className="w-full md:w-64 bg-[#0a0d16] p-5 shrink-0 border-r border-gray-850 md:sticky md:top-0 z-20 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-3 mb-8">
            <span className="p-2.5 rounded-xl bg-emerald-600 text-white">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <div>
              <h1 className="text-sm font-black tracking-normal text-white uppercase">
                {locale === 'ar' ? 'قاضي تيك إداري ⚙️' : 'Qadi Tech Admin'}
              </h1>
              <p className="text-[10px] text-gray-500 font-bold mt-0.5">
                {locale === 'ar' ? 'لوحة تحكم المحفظة والشحنات' : 'Command center v3.0'}
              </p>
            </div>
          </div>

          <nav className="space-y-1.5">
            <button
              onClick={() => setActiveTab('stats')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-black transition-all ${
                activeTab === 'stats' 
                  ? 'bg-emerald-600 text-white font-black' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-900'
              }`}
            >
              <TrendingUp className="h-4 w-4" />
              <span>{locale === 'ar' ? 'لوحة الإحصائيات الأساسية' : 'Dashboard Stats'}</span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-black transition-all ${
                activeTab === 'orders' 
                  ? 'bg-emerald-600 text-white font-black' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-900'
              }`}
            >
              <ShoppingBag className="h-4 w-4" />
              <span>{locale === 'ar' ? 'إدارة الطلبات والشحن ⚡' : 'Orders Management'}</span>
              {pendingOrders.length > 0 && (
                <span className="bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full ml-auto">
                  {pendingOrders.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('add_admin')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-black transition-all ${
                activeTab === 'add_admin' 
                  ? 'bg-emerald-600 text-white font-black' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-900'
              }`}
            >
              <UserPlus className="h-4 w-4" />
              <span>{locale === 'ar' ? 'إضافة مسؤول (Add Admin)' : 'Add Admin'}</span>
            </button>

            <button
              onClick={() => setActiveTab('oranos_api')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-black transition-all ${
                activeTab === 'oranos_api' 
                  ? 'bg-emerald-600 text-white font-black' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-900'
              }`}
            >
              <Sliders className="h-4 w-4" />
              <span>{locale === 'ar' ? 'بوابة المزود Oranos API 🔌' : 'Oranos API Gateway'}</span>
            </button>
          </nav>
        </div>

        <div className="pt-4 border-t border-gray-850 mt-10">
          <button
            onClick={resetAndReinitDatabase}
            className="w-full bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/40 text-[10px] font-black text-rose-400 rounded-xl py-2.5 flex items-center gap-2 justify-center transition-all cursor-pointer"
          >
            <Database className="h-3.5 w-3.5 text-rose-400" />
            <span>{locale === 'ar' ? 'فرمتة وإعادة تهيئة Firebase ⚙️' : 'Format & Re-initialize Firebase'}</span>
          </button>
        </div>
      </aside>

      {/* Primary working panel viewport */}
      <main className="flex-1 p-6 md:p-10 space-y-8 overflow-x-hidden">
        
        {/* STATS ANALYTICAL METRICS VIEW */}
        {activeTab === 'stats' && (
          <div className="space-y-8">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'الإحصائيات التشغيلية والمالية للمنصة' : 'Operational Metrics Telemetry'}</span>
            </h2>

            {/* Metrics cards grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'الأرباح الكلية المكتملة' : 'Completed Digital Volume'}</p>
                  <p className="text-xl font-black text-emerald-400 font-mono mt-1">{formatPrice(totalVolumeUSD)}</p>
                </div>
                <div className="p-3 rounded-xl bg-emerald-500/15 text-emerald-400">
                  <ArrowLeftRight className="h-5 w-5" />
                </div>
              </div>

              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'الطلبات قيد المراجعة والشحن' : 'Pending Approvals'}</p>
                  <p className="text-xl font-black text-amber-400 font-mono mt-1">{pendingOrders.length}</p>
                </div>
                <div className="p-3 rounded-xl bg-amber-500/15 text-amber-400">
                  <Clock className="h-5 w-5" />
                </div>
              </div>

              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'المستخدمين المسجلين' : 'Platform Register'}</p>
                  <p className="text-xl font-black text-teal-400 font-mono mt-1">{usersList.length}</p>
                </div>
                <div className="p-3 rounded-xl bg-teal-500/15 text-teal-400">
                  <Users className="h-5 w-5" />
                </div>
              </div>
            </div>

            {/* Trend chart card */}
            <div className="bg-[#0c101b] border border-gray-800 p-6 rounded-2xl">
              <h3 className="font-bold text-xs text-gray-300 uppercase tracking-wider mb-4">{locale === 'ar' ? 'منحنى الشحنات ومبيعات المحافظ (آخر ٧ أيام)' : 'Recharging Trend Matrix (USD volume)'}</h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={getSalesTrend()}>
                    <defs>
                      <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" opacity={0.3} />
                    <XAxis dataKey="day" stroke="#6b7280" fontSize={10} tickLine={false} />
                    <YAxis stroke="#6b7280" fontSize={10} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: '#0c101b', borderColor: '#1f2937', color: '#fff', fontSize: 11 }} />
                    <Area type="monotone" dataKey="sales" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorSales)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* ORDERS MANAGEMENT VIEW */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-gray-850">
              <h2 className="text-base font-black text-white flex items-center gap-2">
                <ShoppingBag className="h-4 w-4 text-emerald-400" />
                <span>{locale === 'ar' ? 'إدارة الطلبات والشحن والمراجعة المباشرة' : 'Review live deposit and digital credit requests'}</span>
              </h2>

              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-gray-550 font-bold uppercase">{locale === 'ar' ? 'تصفية الحالة:' : 'State:'}</span>
                <select
                  value={orderStatusFilter}
                  onChange={e => setOrderStatusFilter(e.target.value)}
                  className="bg-gray-950 border border-gray-800 text-xs font-black text-gray-250 rounded-xl px-3 py-1.5 focus:outline-hidden"
                >
                  <option value="all">{locale === 'ar' ? 'جميع الحالات' : 'All Orders'}</option>
                  <option value="pending">{locale === 'ar' ? 'انتظار المراجعة' : 'Pending'}</option>
                  <option value="preparing">{locale === 'ar' ? 'قيد المعالجة' : 'Processing'}</option>
                  <option value="completed">{locale === 'ar' ? 'مكتمل' : 'Completed'}</option>
                  <option value="canceled">{locale === 'ar' ? 'ملغي' : 'Canceled'}</option>
                </select>
              </div>
            </div>

            {/* Direct Quick search bar */}
            <div className="relative w-full max-w-md">
              <input
                type="text"
                placeholder={locale === 'ar' ? 'ابحث برقم الطلب، البريد، أو هاتف المستلم...' : 'Search by order ID, email or phone...'}
                value={orderSearch}
                onChange={e => setOrderSearch(e.target.value)}
                className="w-full rounded-2xl border border-gray-800 bg-[#0c101b] py-2.5 pl-4 pr-10 text-xs text-white outline-hidden focus:border-emerald-500 font-bold"
              />
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            </div>

            {/* Orders log lists */}
            <div className="space-y-3">
              {filteredOrders.length === 0 ? (
                <div className="py-12 text-center border border-dashed border-gray-800 rounded-2xl bg-gray-950/20">
                  <ShoppingBag className="h-8 w-8 mx-auto text-gray-600 mb-2" />
                  <p className="text-xs font-bold text-gray-500">
                    {locale === 'ar' ? 'لم يتم العثور على أي شحنات/طلبات مطابقة.' : 'No orders matched your search filters.'}
                  </p>
                </div>
              ) : (
                filteredOrders.map((order) => (
                  <div key={order.id} className="bg-[#0c101b] border border-gray-800 rounded-2xl p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-850">
                      <div>
                        <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono font-black py-0.5 px-2.5 rounded-md">
                          #ID: {order.id}
                        </span>
                        <div className="text-[11px] text-gray-400 font-bold mt-1.5 flex items-center gap-1.5">
                          <span>{order.userName || 'Guest User'}</span>
                          <span>•</span>
                          <span className="font-mono">{order.userPhone || 'No Phone provided'}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${getOrderStatusBadge(order.status)}`}>
                          {getOrderStatusText(order.status)}
                        </span>
                        <span className="text-xs text-gray-500 font-mono">{new Date(order.timestamp).toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                      <div className="space-y-1.5">
                        <p className="text-[11px] font-bold text-gray-300">
                          {locale === 'ar' ? 'باقات الشحن المطلوبة والكميات:' : 'Requested products:'}
                        </p>
                        {order.items.map((it, idx) => (
                          <div key={idx} className="text-xs font-black text-white flex items-center gap-1">
                            <span>• {it.quantity}X</span>
                            <span className="text-emerald-400">{locale === 'ar' ? it.productName_ar : it.productName_en}</span>
                          </div>
                        ))}

                        {/* Extra deposit reference notes */}
                        {order.additionalNotes && (
                          <div className="p-2 rounded-xl bg-orange-950/20 text-orange-400 border border-orange-900/30 text-[10px] font-bold mt-2">
                            🚨 {locale === 'ar' ? 'ملمح الشحنة / رقم الحوالة المعطى:' : 'Sender reference notes:'} {order.additionalNotes}
                          </div>
                        )}
                        {(order as any).receiptImage && (
                          <div className="mt-3">
                            <span className="text-[10px] font-bold text-gray-500 mb-1 block">صورة الإيصال (Receipt)</span>
                            <img src={(order as any).receiptImage} alt="Receipt" className="h-16 w-16 object-cover rounded-lg border border-gray-700 cursor-pointer hover:opacity-80 transition-opacity" onClick={() => window.open((order as any).receiptImage, '_blank')} />
                          </div>
                        )}
                      </div>

                      <div className="text-right flex flex-col sm:items-end gap-2.5">
                        <div className="text-sm font-black text-emerald-400 font-mono">
                          {locale === 'ar' ? 'الفاتورة الكلية:' : 'Grand cost sum:'} {formatPrice(order.total)}
                        </div>

                        {/* If pending/processing, allow approvals action */}
                        {!['completed', 'canceled'].includes(order.status) && (
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => handleCancelOrder(order)}
                              className="px-3.5 py-1.5 bg-rose-950 text-rose-400 hover:bg-rose-900 rounded-xl text-[10px] font-bold transition-all border border-rose-900/40 cursor-pointer"
                            >
                              {locale === 'ar' ? 'إلغاء ورفض' : 'Canceled/Decline'}
                            </button>

                            <button
                              onClick={() => handleApproveOrder(order)}
                              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[10px] font-black transition-all flex items-center gap-1 cursor-pointer"
                            >
                              <Check className="h-3 w-3" />
                              <span>{locale === 'ar' ? 'تأكيد وشحن رصيد المحفظة ⚡' : 'Approve & Credit Wallet'}</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ADD ADMINS SECTION */}
        {activeTab === 'add_admin' && (
          <div className="space-y-6">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <UserPlus className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'إدارة مسؤولي المنصة (Add Extra Administrators)' : 'Manage Platform Security Administrators'}</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Form card */}
              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-3xl space-y-4">
                <h3 className="font-bold text-xs uppercase text-emerald-400">{locale === 'ar' ? 'تعيين بريد مسؤول جديد' : 'Enroll New Administrator'}</h3>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1.5">
                    {locale === 'ar' ? 'عنوان البريد الإلكتروني (Google Email):' : 'Administrator Email Account:'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      placeholder="e.g. akiocodex1@gmail.com"
                      value={newAdminEmail}
                      onChange={e => setNewAdminEmail(e.target.value)}
                      className="flex-1 bg-gray-950 border border-gray-800 rounded-2xl py-2 px-3.5 text-xs text-white placeholder:text-gray-600 outline-hidden focus:border-emerald-500 font-mono font-bold"
                    />
                    <button
                      onClick={handleAddAdmin}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-2xl flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="h-4 w-4" />
                      <span>{locale === 'ar' ? 'إضافة' : 'Upgrade'}</span>
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-emerald-950/20 text-emerald-400 border border-emerald-900/30 rounded-xl leading-relaxed text-[10px] font-bold">
                  💡 {locale === 'ar' ? 'سيتمكن أي مسؤول يتم إضافته هنا من تصفح الإحصائيات وإدارة وتأكيد الشحنات وسحب وتأكيد الحوالات فوراً.' : 'Any Google accounts added in this database list can login with administrator permissions.'}
                </div>
              </div>

              {/* Emails List card */}
              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-3xl space-y-4">
                <h3 className="font-bold text-xs uppercase text-emerald-400">{locale === 'ar' ? 'المسؤولين النشطين بالمنصة' : 'Active Administrators List'}</h3>
                
                <div className="space-y-2">
                  {activeAdmins.map((adm: string, idx: number) => (
                    <div key={idx} className="p-3 bg-gray-950 border border-gray-850 rounded-2xl flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-emerald-400" />
                        <span className="text-gray-300 font-bold">{adm}</span>
                      </div>
                      
                      <button
                        onClick={() => handleRemoveAdmin(adm)}
                        className="p-1 text-gray-500 hover:text-rose-500 transition-colors cursor-pointer"
                        title={locale === 'ar' ? 'إزالة المسؤول' : 'Remove access'}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ORANOS API GATEWAY TAB */}
        {activeTab === 'oranos_api' && (
          <div className="space-y-6">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <Sliders className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'لوحة تحكم وتوجيه مزود الخدمات آلياً Oranos Market' : 'Oranos Market Automated Dispatch Gateway'}</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* ORANOS TOKEN & STATUS CARD */}
              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-3xl space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-xs uppercase text-emerald-400">
                    {locale === 'ar' ? 'رمز تفعيل وتكامل API' : 'API Authorization Settings'}
                  </h3>
                  <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                    oranosConfig?.ok 
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-900/55' 
                      : 'bg-rose-950 text-rose-400 border border-rose-900/55'
                  }`}>
                    {isFetchingConfig ? '...' : oranosConfig?.ok ? (locale === 'ar' ? 'متصل بنجاح' : 'ACTIVE') : (locale === 'ar' ? 'غير متصل' : 'DISCONNECTED')}
                  </span>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1.5">
                      {locale === 'ar' ? 'رمز الوصول البرمجي (api-token):' : 'Developer Access API Key Token:'}
                    </label>
                    <div className="relative">
                      <input
                        type={showToken ? 'text' : 'password'}
                        placeholder="Paste your api-token from Oranos Market"
                        value={oranosApiTokenInput}
                        onChange={e => setOranosApiTokenInput(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded-2xl py-2 px-3.5 pr-10 text-xs text-white placeholder:text-gray-600 outline-hidden focus:border-emerald-500 font-mono font-bold"
                      />
                      <button
                        type="button"
                        onClick={() => setShowToken(!showToken)}
                        className="absolute right-3 top-2.5 text-gray-400 hover:text-white"
                      >
                        {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={handleSaveOranosToken}
                    disabled={isSavingToken}
                    className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-800 disabled:text-gray-600 text-white text-xs font-black rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer font-sans"
                  >
                    {isSavingToken ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      <Check className="h-4 w-4" />
                    )}
                    <span>{locale === 'ar' ? 'حفظ وتوثيق المفتاح البرمجي' : 'Save and Verify Token Credentials'}</span>
                  </button>
                </div>

                {/* Connection Live telemetry stats */}
                {oranosConfig?.ok && (
                  <div className="pt-4 border-t border-gray-850 grid grid-cols-2 gap-3 font-sans">
                    <div className="p-3 bg-gray-950 border border-gray-850 rounded-xl">
                      <p className="text-[9px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'حساب المطور المعتمد' : 'Developer Email'}</p>
                      <p className="text-xs font-bold text-white mt-1 overflow-hidden text-ellipsis whitespace-nowrap">{oranosConfig.email}</p>
                    </div>
                    <div className="p-3 bg-gray-950 border border-gray-850 rounded-xl">
                      <p className="text-[9px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'رصيد حساب المطور' : 'API Pool Balance'}</p>
                      <p className="text-sm font-black text-emerald-400 font-mono mt-1">${parseFloat(oranosConfig.balance).toFixed(2)}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* AUTOMATIC PRODUCT SYNCHRONIZER CARD */}
              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-3xl flex flex-col justify-between space-y-4 font-sans">
                <div className="space-y-3">
                  <h3 className="font-bold text-xs uppercase text-emerald-400">
                    {locale === 'ar' ? 'المزامنة الآلية لكتالوج الشحن الرقمي' : 'Automated Inventory Catalog Synchronization'}
                  </h3>
                  <p className="text-xs font-semibold text-gray-400 leading-relaxed">
                    {locale === 'ar' 
                      ? 'تقوم هاته الأداة بالاتصال الفوري بكتالوج ومستودع Oranos Market، وسحب كافة باقات وعملات الألعاب والشدات المتاحة ثم تقسيمها آلياً إلى تصنيفات، وتخزينها مباشرة في قاعدة بيانات Firestore الخاصة بك.' 
                      : 'Connect with Oranos Market API, pull down all globally available gaming pins/cards/recharges catalog, structure them into beautifully managed local categories, and upsert them transactional-safe to your Firestore database.'}
                  </p>
                  <p className="text-xs font-semibold text-gray-400 leading-relaxed">
                    ⭐ <span className="text-emerald-400 font-bold">{locale === 'ar' ? 'هامش ربح تلقائي 10%' : 'Automatic 10% Profit Markup'}</span>: 
                    {locale === 'ar' 
                      ? ' يتم إضافته تلقائياً على سعر التكلفة لضمان تغطيتك وحمايتك مالياً وتحقيق أرباح لكل عملية شحن!' 
                      : ' added to selling price automatically to protect your operational commissions and earn profits on every single recharge!'}
                  </p>
                </div>

                <div className="space-y-3 pt-4">
                  <button
                    onClick={handleSyncOranosProducts}
                    disabled={isSyncingProducts || !oranosConfig?.ok}
                    className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-800 disabled:text-gray-600 text-white text-xs font-black rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-950/20"
                  >
                    <RefreshCw className={`h-4 w-4 ${isSyncingProducts ? 'animate-spin' : ''}`} />
                    <span>
                      {isSyncingProducts 
                        ? (locale === 'ar' ? 'جاري سحب وتصنيف كتالوج المنتجات...' : 'Fetching and Cataloging Sourced items...') 
                        : (locale === 'ar' ? 'ابدأ المزامنة والتحديث الشامل الآن ⚡' : 'Trigger Automated Sync & Update Catalog')}
                    </span>
                  </button>

                  {!oranosConfig?.ok && (
                    <div className="flex items-center gap-1.5 justify-center text-[10px] font-bold text-rose-400">
                      <AlertCircle className="h-3.5 w-3.5" />
                      <span>{locale === 'ar' ? 'يرجى تفعيل مفتاح الـ API والتوصيل أولاً لتفعيل المزامنة.' : 'Please authorize the API token to establish sync link.'}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
};
export default Admin;
