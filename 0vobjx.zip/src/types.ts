export type ProductStatus = 'in_stock' | 'out_of_stock';

export interface Product {
  id: string;
  name_en: string;
  name_ar: string;
  price: number;
  discountPrice?: number;
  coverImage: string;
  images: string[];
  description_en: string;
  description_ar: string;
  status: ProductStatus;
  rating: number;
  reviewsCount: number;
  categoryId: string;
  types?: string[];
  sizes?: string[];
  badge_en?: string;
  badge_ar?: string;
  // Oranos API integration additions
  name?: string; // added for direct product name
  image?: string; // added for image URL fallback
  isOranosProduct?: boolean;
  oranosProductId?: number;
  productType?: string;
  params?: string[];
  qtyValues?: any;
  qtyMin?: number;
  qtyMax?: number;
  allowedQuantities?: number[] | null;
  basePrice?: number;
  originalPrice?: number;
}

export interface Category {
  id: string;
  name_en: string;
  name_ar: string;
  icon: string;
  coverImage: string;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  uid?: string;
  avatarUrl?: string;
  role?: string;
  balanceUSD?: number;
  balanceSYP?: number;
  balanceEGP?: number;
}

export type OrderStatus =
  | 'pending'        // انتظار المراجعة
  | 'processing'     // قيد المعالجة (جاري الشحن الرقمي)
  | 'completed'      // مكتمل
  | 'canceled';      // ملغي

export interface TrackingStep {
  status: OrderStatus;
  timestamp: string;
  completed: boolean;
}

export interface OrderItem {
  product: Product;
  quantity: number;
  selectedType?: string;
  selectedSize?: string;
}

export interface Order {
  id: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
  items: OrderItem[];
  total: number;
  status: OrderStatus;
  timestamp: string;
  trackingSteps: TrackingStep[];
  playerId?: string;
  additionalNotes?: string;
  // Oranos integration tracking additions
  isOranosOrder?: boolean;
  oranosOrderId?: string;
  oranosOuuid?: string;
  replayApi?: any;
  rejectionReason?: string;
}
