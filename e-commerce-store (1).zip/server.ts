import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc, updateDoc, collection, writeBatch, getDocs } from "firebase/firestore";
import firebaseConfig from "./firebase-applet-config.json" with { type: "json" };

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Firestore client on server-side using Firebase-Applet config
const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);

// Core state storage for Oranos API token
const oranosToken = process.env.ORANOS_API_TOKEN || "";

/**
 * Middleware: Verify Firebase administrative access
 * Decodes client JWT ID Token via Google Identity Toolkit REST API
 */
async function verifyAdmin(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Access Denied: Missing Bearer token" });
  }

  const idToken = authHeader.split("Bearer ")[1];

  try {
    const identityUrl = `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${firebaseConfig.apiKey}`;
    const lookupRes = await fetch(identityUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ idToken })
    });

    if (!lookupRes.ok) {
      return res.status(401).json({ error: "Unauthorized: Invalid Session token" });
    }

    const payload = await lookupRes.json();
    const email = payload.users?.[0]?.email;
    if (!email) {
      return res.status(401).json({ error: "Unauthorized: Failed to retrieve user email context" });
    }

    const settingsDoc = await getDoc(doc(db, "settings", "general"));
    const adminEmails = settingsDoc.exists()
      ? (settingsDoc.data().adminEmails || ["akiocodex1@gmail.com"])
      : ["akiocodex1@gmail.com"];

    if (!adminEmails.includes(email)) {
      return res.status(403).json({ error: "Forbidden: Administrative permissions strictly required" });
    }

    req.adminEmail = email;
    next();
  } catch (err: any) {
    console.error("verifyAdmin Middleware error:", err);
    res.status(500).json({ error: "Authentication system failure verification" });
  }
}

/**
 * Secure Admin Config: Retrieve connection status and profile details
 */
app.get("/api/admin/oranos/config", verifyAdmin, async (req, res) => {
  if (!oranosToken) {
    return res.json({ 
      configured: false, 
      message: "API Token is not set." 
    });
  }

  try {
    // Test token using a profile endpoint call
    const response = await fetch("https://api.oranosmarket.com/profile", {
      headers: { 
        "api-token": oranosToken,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });

    if (!response.ok) {
      return res.json({
        configured: true,
        ok: false,
        message: "Token exists but API rejected it. Token may be invalid or expired."
      });
    }

    const profile = await response.json();
    return res.json({
      configured: true,
      ok: true,
      balance: profile.balance !== undefined ? String(profile.balance) : "Available",
      email: profile.email || (req as any).adminEmail || "Authenticated API User"
    });
  } catch (err) {
    return res.json({
      configured: true,
      ok: false,
      message: "API connection failed. Oranos may be down."
    });
  }
});

/**
 * Secure Admin Config: Verify new Oranos API Token (Instruction guidance only, no write/save)
 */
app.post("/api/admin/oranos/config", verifyAdmin, async (req, res) => {
  const { apiToken } = req.body;

  if (!apiToken || typeof apiToken !== "string" || apiToken.trim().length === 0) {
    return res.status(400).json({ 
      error: "apiToken parameter is required and must be a valid string." 
    });
  }

  // Prevent submittal of masked tokens
  if (apiToken.includes("...") || apiToken.includes("•••") || apiToken.length < 20) {
    return res.status(400).json({ 
      error: "Please enter the full API token, not a masked or truncated version." 
    });
  }

  try {
    // Validate the new token using profile endpoint
    const testResponse = await fetch("https://api.oranosmarket.com/profile", {
      headers: { 
        "api-token": apiToken.trim(),
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });

    if (!testResponse.ok) {
      return res.status(401).json({
        error: "Invalid API Token",
        message: "The provided token was rejected by Oranos API. Please check your credentials."
      });
    }

    const profile = await testResponse.json();

    return res.json({
      success: true,
      verified: true,
      envLine: `ORANOS_API_TOKEN="${apiToken.trim()}"`,
      balance: profile.balance !== undefined ? String(profile.balance) : "Available",
      email: profile.email || "Authenticated API User",
      message: "Token verified! You must add this environment variable to your project secrets/.env configuration."
    });
  } catch (err: any) {
    return res.status(500).json({
      error: "Connection failed",
      message: `Failed to communicate with Oranos API to verify token: ${err.message || err}`
    });
  }
});

/**
 * Secure Admin Profile: Fetch Oranos account profile and balance details
 */
app.get("/api/admin/oranos/profile", verifyAdmin, async (req, res) => {
  if (!oranosToken) {
    return res.status(400).json({ error: "Oranos API Token is not configured." });
  }

  try {
    const response = await fetch("https://api.oranosmarket.com/profile", {
      headers: { 
        "api-token": oranosToken,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });

    if (!response.ok) {
      return res.status(response.status).json({ error: "Failed to fetch account profile from Oranos." });
    }

    const result = await response.json();
    return res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: "Connection to Oranos API profile failed.", details: err.message });
  }
});

/**
 * Secure Admin Sync: Query all Oranos products & automatically structure and index them into Firestore
 */
app.post("/api/admin/oranos/sync-products", verifyAdmin, async (req, res) => {
  if (!oranosToken) {
    return res.status(400).json({ error: "Oranos API Token is not configured. Setup API token first." });
  }

  const startTime = Date.now();
  const errors: string[] = [];
  let newProductsCount = 0;
  let priceChangesCount = 0;
  let unavailableProductsCount = 0;

  try {
    const productsRes = await fetch("https://api.oranosmarket.com/products", {
      headers: { "api-token": oranosToken }
    });

    if (!productsRes.ok) {
      return res.status(productsRes.status).json({ error: "Failed to fetch catalog from Oranos Market API." });
    }

    const oranosProducts = await productsRes.json();

    // Fetch existing local products to check modifications
    const localProductsSnap = await getDocs(collection(db, "products"));
    const localProductsMap = new Map<string, any>();
    localProductsSnap.docs.forEach((d) => {
      const data = d.data();
      localProductsMap.set(d.id, { id: d.id, ...data });
    });

    // Map out unique categories and structural items
    const categoriesMap = new Map<string, any>();
    const productOperationsList: any[] = [];
    const activeOranosIds = new Set<string>();

    oranosProducts.forEach((item: any) => {
      const localId = `oranos_${item.id}`;
      activeOranosIds.add(localId);

      // 1. Structural slugification for consistent category IDs
      const categorySlug = `oranos_cat_${item.category_name.trim().toLowerCase().replace(/[^a-z0-9_]+/g, "_")}`;
      
      // Save category grouping metadata
      if (!categoriesMap.has(categorySlug)) {
        categoriesMap.set(categorySlug, {
          id: categorySlug,
          name_en: item.category_name,
          name_ar: item.category_name, // fallback structure
          description_en: `Authentic automated digital cards for ${item.category_name} sourced instantly.`,
          description_ar: `شحن فوري آلي موثوق باقات وعملات لـ ${item.category_name} بشكل تلقائي كلياً.`,
          imageUrl: item.category_img ? `https://api.oranosmarket.com/${item.category_img}` : "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=400&q=80",
          isOranosCategory: true
        });
      }

      // Convert quantity constraints dynamically to match the store requirement
      let qtyMin = 1;
      let qtyMax = 1;
      let allowedQuantities: number[] | null = null;

      if (item.qty_values) {
        if (Array.isArray(item.qty_values)) {
          allowedQuantities = item.qty_values.map((v: any) => parseInt(v));
        } else if (typeof item.qty_values === "object") {
          qtyMin = item.qty_values.min ? parseInt(item.qty_values.min) : 1;
          qtyMax = item.qty_values.max ? parseInt(item.qty_values.max) : 15000;
        }
      }

      const rawBasePrice = item.base_price || item.price;
      const apiImgUrl = item.category_img ? `https://api.oranosmarket.com/${item.category_img}` : "";

      const existingProduct = localProductsMap.get(localId);

      if (existingProduct) {
        // Product already exists - Preserve admin settings
        const basePriceChanged = existingProduct.basePrice !== rawBasePrice;
        if (basePriceChanged) {
          priceChangesCount++;
          // Trigger direct notification
          const notificationId = `price_alert_${Date.now()}_${item.id}`;
          const alertMessageEn = `${existingProduct.name_en} base price changed from $${existingProduct.basePrice} to $${rawBasePrice}`;
          const alertMessageAr = `تغير السعر الأساسي لـ ${existingProduct.name_ar} من $${existingProduct.basePrice} إلى $${rawBasePrice}`;
          
          productOperationsList.push({
            type: "notification",
            id: notificationId,
            data: {
              id: notificationId,
              title: "Price Change Alert / تنبيه تغيير السعر",
              title_en: "Price Change Alert",
              title_ar: "تنبيه تغيير السعر",
              message: alertMessageEn,
              message_en: alertMessageEn,
              message_ar: alertMessageAr,
              type: "warning",
              createdAt: new Date().toISOString(),
              read: false
            }
          });
        }

        // Merge API changes safely while preserving modifications
        // Cover image defaults to customImage if set and useApiImage is false
        const useApiImage = existingProduct.useApiImage !== undefined ? existingProduct.useApiImage : true;
        const finalCoverImage = useApiImage ? apiImgUrl : (existingProduct.customImage || apiImgUrl);

        productOperationsList.push({
          type: "product_update",
          id: localId,
          data: {
            ...existingProduct,
            basePrice: rawBasePrice,
            originalPrice: item.price,
            oranosBasePrice: rawBasePrice,
            available: item.available === true,
            status: item.available === true ? 'in_stock' : 'out_of_stock',
            qtyValues: item.qty_values,
            qtyMin,
            qtyMax,
            allowedQuantities,
            productType: item.product_type || "package",
            params: item.params || ["ادخل الايدي الاعب"],
            apiImage: apiImgUrl,
            coverImage: finalCoverImage || existingProduct.coverImage,
            lastSyncedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          }
        });
      } else {
        // New Product - Create from scratch with reasonable profit margins (15%)
        newProductsCount++;
        const defaultMarginPercent = 15;
        const sellingPrice = parseFloat((rawBasePrice * (1 + defaultMarginPercent / 100)).toFixed(3));

        productOperationsList.push({
          type: "product_create",
          id: localId,
          data: {
            id: localId,
            categoryId: categorySlug,
            name: item.name,
            name_en: item.name,
            name_ar: item.name,
            description: `Delivered automatically in seconds. Player ID required. Sourced from Oranos.`,
            description_en: `Delivered automatically in seconds. Player ID required. Sourced from Oranos.`,
            description_ar: `تسليم رقمي آلي في ثوانٍ معدودة. يتطلب كتابة الايدي او المعرف اللازم للعملية لضمان التسليم الفوري.`,
            price: sellingPrice, // Compatibility fallback
            sellingPrice: sellingPrice,
            discountPrice: sellingPrice,
            profitMargin: defaultMarginPercent,
            profitAmount: parseFloat((sellingPrice - rawBasePrice).toFixed(3)),
            originalPrice: item.price,
            basePrice: rawBasePrice,
            oranosBasePrice: rawBasePrice,
            apiImage: apiImgUrl || "https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?auto=format&fit=crop&w=400&q=80",
            coverImage: apiImgUrl || "https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?auto=format&fit=crop&w=400&q=80",
            customImage: "",
            useApiImage: true,
            available: item.available === true,
            status: item.available === true ? 'in_stock' : 'out_of_stock',
            isActive: true,
            rating: 4.8,
            reviewsCount: Math.floor(Math.random() * 40) + 10,
            isOranosProduct: true,
            oranosProductId: item.id,
            productType: item.product_type || "amount",
            params: item.params || ["ادخل الايدي الاعب"],
            qtyValues: item.qty_values, 
            qtyMin,
            qtyMax,
            allowedQuantities,
            lastSyncedAt: new Date().toISOString(),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          }
        });
      }
    });

    // Mark products that are local but no longer returned by Oranos as out of stock
    for (const [key, existingItem] of localProductsMap.entries()) {
      if (existingItem.isOranosProduct && !activeOranosIds.has(key) && existingItem.available !== false) {
        unavailableProductsCount++;
        productOperationsList.push({
          type: "product_update",
          id: key,
          data: {
            ...existingItem,
            available: false,
            status: "out_of_stock",
            updatedAt: new Date().toISOString()
          }
        });
      }
    }

    // Committing bulk writes to Firestore
    const batch = writeBatch(db);

    // Write categories
    for (const [slug, catData] of categoriesMap.entries()) {
      batch.set(doc(db, "categories", slug), catData, { merge: true });
    }

    // Write creations/updates/notifications
    productOperationsList.forEach((op) => {
      if (op.type === "notification") {
        batch.set(doc(db, "notifications", op.id), op.data);
      } else {
        batch.set(doc(db, "products", op.id), op.data, { merge: true });
      }
    });

    // Save final SyncLog
    const durationMs = Date.now() - startTime;
    const logId = `synclog_${Date.now()}`;
    const syncLogData = {
      id: logId,
      timestamp: new Date().toISOString(),
      productsSynced: oranosProducts.length,
      categoriesSynced: categoriesMap.size,
      newProducts: newProductsCount,
      priceChanges: priceChangesCount,
      unavailableProducts: unavailableProductsCount,
      errors: errors,
      duration: durationMs
    };

    batch.set(doc(db, "syncLogs", logId), syncLogData);

    await batch.commit();

    res.json({
      success: true,
      productsSynced: oranosProducts.length,
      categoriesSynced: categoriesMap.size,
      newProducts: newProductsCount,
      priceChanges: priceChangesCount,
      unavailableProducts: unavailableProductsCount,
      message: `Complete synchronized: ${oranosProducts.length} items synced. New: ${newProductsCount}, Price changed: ${priceChangesCount}, Disabled: ${unavailableProductsCount}. Log reference: ${logId}`
    });
  } catch (err: any) {
    console.error("sync-products error:", err);
    res.status(500).json({ error: "Failed to execute catalog synchronization transaction.", details: err.message });
  }
});

/**
 * Public/User Secures API Proxy: Create Order with Oranos
 */
app.post("/api/oranos/order", async (req, res) => {
  if (!oranosToken) {
    return res.status(500).json({ error: "Downstream Oranos API integration is not configured by the system administrator." });
  }

  const { product_id, qty, playerId, order_uuid } = req.body;

  if (!product_id || !qty || !order_uuid) {
    return res.status(400).json({ error: "Required fields product_id, qty, and order_uuid of order attempt are missing." });
  }

  try {
    const payload = {
      product_id,
      qty,
      playerId,
      order_uuid
    };

    const response = await fetch("https://api.oranosmarket.com/order", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-token": oranosToken,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();
    return res.json(result);
  } catch (err: any) {
    console.error("Oranos proxy order creation failed:", err);
    res.status(500).json({ error: "Downstream network connection timeout processed", details: err.message });
  }
});

/**
 * Public/User Secures API Proxy: Real-time Check Order Status
 */
app.get("/api/oranos/check-order/:orderId", async (req, res) => {
  if (!oranosToken) {
    return res.status(500).json({ error: "Integration token unconfigured" });
  }

  const { orderId } = req.params;

  try {
    const response = await fetch(`https://api.oranosmarket.com/check-order/${orderId}`, {
      headers: { 
        "api-token": oranosToken,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });

    const result = await response.json();
    return res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: "Failed to retrieve live order status", details: err.message });
  }
});

/**
 * Public/User Secures API Proxy: Real-time Check Order by UUID
 */
app.get("/api/oranos/check-order-uuid/:uuid", async (req, res) => {
  if (!oranosToken) {
    return res.status(500).json({ error: "Integration token unconfigured" });
  }

  const { uuid } = req.params;

  try {
    const response = await fetch(`https://api.oranosmarket.com/check-order/${uuid}?uuid=1`, {
      headers: { 
        "api-token": oranosToken,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    });

    const result = await response.json();
    return res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: "Failed to retrieve live order uuid status", details: err.message });
  }
});

// Configure Vite middleware for development or Static Asset server for Production
async function initializeViteAndListen() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Port listening binds to 0.0.0.0 (necessary for container ingress)
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express Full-Stack Server listening on http://localhost:${PORT}`);
  });
}

initializeViteAndListen().catch(err => {
  console.error("Failed to start server:", err);
});
