import React from 'react';
import { useStore } from '../context/StoreContext';
import { ClipboardList, Trash2, Calendar, Target, ShieldCheck, HelpCircle } from 'lucide-react';

export const OrderHistory: React.FC = () => {
  const { locale, user, orders, formatPrice, navigate, deleteOrder, showConfirm } = useStore();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
      case 'processing':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black tracking-wider uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20 animate-pulse">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-400"></span>
            <span>{locale === 'ar' ? 'قيد الانتظار / قيد المعالجة' : 'Pending / Processing'}</span>
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black tracking-wider uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
            <span>{locale === 'ar' ? 'مكتمل / شحن ناجح' : 'Completed / Charged'}</span>
          </span>
        );
      case 'canceled':
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black tracking-wider uppercase bg-rose-500/10 text-rose-450 border border-rose-500/20">
            <span className="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
            <span>{locale === 'ar' ? 'مرفوض / ملغي' : 'Rejected / Canceled'}</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black tracking-wider uppercase bg-zinc-800 text-zinc-400 border border-zinc-700">
            <span>{status.toUpperCase()}</span>
          </span>
        );
    }
  };

  const formatDate = (isoString: string) => {
    const d = new Date(isoString);
    return d.toLocaleDateString(locale === 'ar' ? 'ar-EG' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      numberingSystem: 'latn'
    });
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center space-y-6">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-zinc-900 text-zinc-500 border border-zinc-800">
          <ClipboardList className="h-7 w-7" />
        </div>
        <div className="space-y-2">
          <h2 className="text-lg font-black text-white">{locale === 'ar' ? 'سجل الطلبات مقيد' : 'Access Restricted'}</h2>
          <p className="text-xs text-gray-400 max-w-md mx-auto leading-relaxed">
            {locale === 'ar' ? 'يرجى تسجيل الدخول بحسابك المتاح لتتبع سجل طلبات الشحن الفوري ومحفظتك.' : 'Sign in using your Google account to track your digital top-up logs and purchases.'}
          </p>
        </div>
        <button
          onClick={() => navigate('login')}
          className="rounded-xl bg-emerald-600 hover:bg-emerald-500 py-3 px-8 text-xs font-black text-white transition-all shadow-md shadow-emerald-900/10 cursor-pointer"
        >
          {locale === 'ar' ? 'تسجيل الدخول الآن' : 'Sign In Now'}
        </button>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center space-y-6">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-zinc-900 text-zinc-500 border border-zinc-800">
          <ClipboardList className="h-7 w-7" />
        </div>
        <div>
          <h2 className="text-lg font-black text-white">{locale === 'ar' ? 'لا توجد طلبات شحن سابقة' : 'No Top-up History'}</h2>
          <p className="text-xs text-gray-450 mt-1.5 leading-relaxed">
            {locale === 'ar' ? 'لم تقم بتنفيذ أي عمليات شحن رقمية بعد. تفضل بخصم رصيد لشحن آيدي ألعابك الآن!' : 'You have not initiated any game top-up or voucher balances. Browse the list to start.'}
          </p>
        </div>
        <button
          onClick={() => navigate('home')}
          className="rounded-xl bg-emerald-600 hover:bg-emerald-500 py-3 px-6 text-xs font-black text-white transition-colors cursor-pointer"
        >
          {locale === 'ar' ? 'تصفح باقات الشحن' : 'Browse Bundles'}
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <ClipboardList className="h-6 w-6 text-emerald-500" />
          <span>{locale === 'ar' ? 'سجل طلبات الشحن الرقمي' : 'Digital Orders History'}</span>
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          {locale === 'ar' ? 'متابعة كافة طلبات الشحن الفوري وتحركات الرصيد الرقمية المخصومة من حسابك.' : 'Audit all instant digital delivery requests and voucher actions deducted from your wallet.'}
        </p>
      </div>

      {/* Orders list stack */}
      <div className="space-y-4">
        {orders.map((order) => {
          const firstItem = order.items && order.items[0];
          const serviceName = firstItem 
            ? (locale === 'ar' ? firstItem.product.name_ar : firstItem.product.name_en)
            : (locale === 'ar' ? "شحن رصيد المحفظة" : "Wallet Credit Charge");

          const coverImage = firstItem?.product?.coverImage || 'https://images.unsplash.com/photo-1563013544-824ae1d704d3?auto=format&fit=crop&w=100&q=80';

          return (
            <div
              key={order.id}
              onClick={() => navigate('order-tracker', { orderId: order.id })}
              className="group cursor-pointer rounded-2xl border border-zinc-800 bg-zinc-900/40 p-5 hover:border-zinc-700/80 hover:bg-zinc-900/80 transition-all duration-300 shadow-xl shadow-black/20"
              style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800/85 pb-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-xl overflow-hidden border border-zinc-800 bg-zinc-950 shrink-0">
                    <img src={coverImage} alt={serviceName} className="h-full w-full object-cover" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white group-hover:text-emerald-400 transition-colors line-clamp-1">
                      {serviceName}
                    </h3>
                    <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-bold mt-0.5">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(order.timestamp)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-row sm:flex-col sm:items-end justify-between sm:justify-center items-center gap-2">
                  <span className="text-[10px] text-zinc-500 font-bold sm:hidden">
                    {locale === 'ar' ? 'الحالة الرقمية:' : 'Transaction Status:'}
                  </span>
                  {getStatusBadge(order.status)}
                </div>
              </div>

              {/* Order data body */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <Target className="h-3.5 w-3.5 text-emerald-500" />
                    <span>{locale === 'ar' ? 'معرّف الحساب Charged ID:' : 'Target Player ID:'}</span>
                    <span className="font-mono font-bold text-white pl-1 pr-1">{order.playerId || 'N/A'}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                    <span>{locale === 'ar' ? 'المبلغ المخصوم:' : 'Deducted Sum:'}</span>
                    <span className="font-mono font-extrabold text-emerald-400 pl-1 pr-1">
                      {formatPrice(order.total)}
                    </span>
                  </div>
                </div>

                {/* Left/Right controls */}
                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {order.status === 'completed' && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        showConfirm({
                          title: locale === 'ar' ? 'إخفاء الطلب المكتمل' : 'Archive Completed Order',
                          message: locale === 'ar' ? 'هل أنت متأكد من إخفاء هذا الطلب المكتمل من القائمة الحالية؟' : 'Are you sure you want to archive this completed order from your immediate history view?',
                          isDestructive: true,
                          confirmText: locale === 'ar' ? 'إخفاء' : 'Archive',
                          onConfirm: () => deleteOrder(order.id)
                        });
                      }}
                      className="p-2 sm:px-3 sm:py-2 rounded-xl text-zinc-550 border border-zinc-800/80 hover:border-rose-500/30 hover:text-rose-450 hover:bg-rose-550/5 transition-colors cursor-pointer"
                      title={locale === 'ar' ? 'حذف من السجل' : 'Delete Log'}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                  <button className="px-3 py-1.5 rounded-lg text-[10px] font-black bg-zinc-950 border border-zinc-850 hover:border-emerald-500 text-gray-300 transition-colors">
                    {locale === 'ar' ? 'تتبع الطلب ⚡' : 'Track Charge'}
                  </button>
                </div>
              </div>

              {/* Reject Reason Alert */}
              {order.status === 'canceled' && order.additionalNotes && (
                <div className="mt-3.5 p-3 rounded-xl bg-rose-950/10 border border-rose-500/10 text-[11px] text-rose-400 leading-relaxed font-sans flex items-start gap-1.5">
                  <HelpCircle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>
                    <strong>{locale === 'ar' ? 'سبب الإلغاء/الرفض:' : 'Rejection Reason:'}</strong> {order.additionalNotes}
                  </span>
                </div>
              )}

            </div>
          );
        })}
      </div>
    </div>
  );
};

export default OrderHistory;
