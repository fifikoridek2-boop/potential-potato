import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { useStore } from '../context/StoreContext';
import { ShoppingBag, ClipboardList, AlertTriangle, Key } from 'lucide-react';
import { Product } from '../types';

export const ProductDetail: React.FC = () => {
  const { locale, formatPrice, buyImmediately, navigate, showToast } = useStore();
  const { productId } = useParams<{ productId: string }>();

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  const [activeImage, setActiveImage] = useState('');
  const [playerId, setPlayerId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    async function fetchProduct() {
      if (!productId) {
        setErrorMsg(locale === 'ar' ? 'معرف الخدمة غير صالح' : 'Invalid service ID');
        setLoading(false);
        return;
      }

      setLoading(true);
      setErrorMsg('');
      try {
        const docRef = doc(db, 'products', productId);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const fetchedProduct = { id: docSnap.id, ...docSnap.data() } as Product;
          setProduct(fetchedProduct);
          setActiveImage(fetchedProduct.coverImage || '');
        } else {
          setProduct(null);
          setErrorMsg(locale === 'ar' ? 'عذراً، هذه الخدمة غير متوفرة حالياً.' : 'Service could not be found.');
        }
      } catch (err) {
        setErrorMsg(locale === 'ar' ? 'حدث خطأ أثناء تحميل بيانات الخدمة.' : 'An error occurred while loading service details.');
      } finally {
        setLoading(false);
      }
    }

    fetchProduct();
  }, [productId, locale]);

  const handleBuyNow = async () => {
    if (!product || product.status === 'out_of_stock') return;
    if (!playerId.trim()) {
      showToast(locale === 'ar' ? 'يرجى إدخال الآيدي (ID) أو معرف الحساب للمتابعة.' : 'Please enter the Player or Account ID to proceed.', 'error');
      return;
    }
    
    setIsProcessing(true);
    try {
      await buyImmediately(product, 1, playerId.trim());
    } catch (e: any) {
      if (e?.message === 'INSUFFICIENT_BALANCE') {
        setTimeout(() => {
          navigate('wallet');
        }, 2000);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-gray-400 py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500 mb-4"></div>
        <p className="text-sm font-semibold">{locale === 'ar' ? 'جاري تحميل تفاصيل الخدمة...' : 'Loading service details...'}</p>
      </div>
    );
  }

  if (errorMsg || !product) {
    return (
      <div className="mx-auto max-w-xl text-center py-16 px-4">
        <div className="inline-flex p-4 rounded-full bg-rose-500/10 text-rose-400 mb-4 border border-rose-500/20">
          <AlertTriangle className="h-8 w-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">{locale === 'ar' ? 'خطأ في التحميل' : 'Service Not Available'}</h2>
        <p className="text-sm text-gray-400 mb-6">{errorMsg || (locale === 'ar' ? 'الخدمة المطلوبة غير متوفرة حالياً.' : 'The requested service cannot be found.')}</p>
        <button onClick={() => navigate('home')} className="px-5 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition-all border border-zinc-700">
          {locale === 'ar' ? 'العودة للرئيسية' : 'Return to Home'}
        </button>
      </div>
    );
  }

  const name = locale === 'ar' ? product.name_ar : product.name_en;
  const descriptionHtml = locale === 'ar' ? product.description_ar : product.description_en;
  const isOutOfStock = product.status === 'out_of_stock';
  const finalPrice = product.discountPrice ?? product.price;

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="mb-6">
        <button onClick={() => navigate('home')} className="text-xs font-bold text-gray-400 hover:text-emerald-500 transition-colors flex items-center gap-1">
          <span>{locale === 'ar' ? '← العودة لمعرض الخدمات' : '← Back to Services'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        {/* Service Image Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-video sm:aspect-square overflow-hidden rounded-2xl bg-zinc-950 border border-zinc-800 shadow-xl shadow-black/40">
            <img src={activeImage} alt={name} className="h-full w-full object-cover object-center" referrerPolicy="no-referrer" />
          </div>
          {product.images && product.images.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <button onClick={() => setActiveImage(product.coverImage)} className={`h-14 w-14 overflow-hidden rounded-lg border transition-all ${activeImage === product.coverImage ? 'border-emerald-500' : 'border-zinc-800 hover:border-zinc-600'}`}>
                <img src={product.coverImage} alt={name} className="h-full w-full object-cover" />
              </button>
              {product.images.map((imgUrl, idx) => (
                <button key={idx} onClick={() => setActiveImage(imgUrl)} className={`h-14 w-14 overflow-hidden rounded-lg border transition-all ${activeImage === imgUrl ? 'border-emerald-500' : 'border-zinc-800 hover:border-zinc-600'}`}>
                  <img src={imgUrl} alt={`${name} angle ${idx}`} className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Purchase & Input Section */}
        <div className="flex flex-col justify-between" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
          <div className="space-y-6">
            <div>
              <p className="text-[11px] text-emerald-500 uppercase tracking-widest font-mono font-black bg-emerald-500/10 px-2.5 py-1 rounded-full w-max">
                {product.categoryId.toUpperCase()}
              </p>
              <h1 className="font-sans text-2xl sm:text-3xl font-extrabold text-white mt-3">
                {name}
              </h1>
            </div>

            <div className="py-4 border-y border-zinc-800 flex items-baseline gap-3">
              <span className="text-3xl font-black text-emerald-400 font-mono">
                {formatPrice(finalPrice)}
              </span>
              {product.discountPrice && (
                <span className="text-sm text-zinc-500 line-through font-mono">
                  {formatPrice(product.price)}
                </span>
              )}
            </div>

            <div className="space-y-4">
              {!isOutOfStock && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Key className="h-3.5 w-3.5 text-emerald-500" />
                    <span>{locale === 'ar' ? 'أدخل الآيدي (ID) أو معرف الحساب *' : 'Enter Player ID or Account ID *'}</span>
                  </label>
                  <input 
                    type="text" 
                    value={playerId}
                    onChange={(e) => setPlayerId(e.target.value)}
                    placeholder={locale === 'ar' ? 'أدخل الـ ID الخاص بحساب اللعبة' : 'e.g., 569103948'}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3.5 px-4 text-white placeholder-zinc-600 focus:outline-none focus:border-emerald-500 font-mono transition-colors text-sm"
                    required
                  />
                </div>
              )}
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-zinc-800 flex flex-col gap-3">
            <button
              onClick={handleBuyNow}
              disabled={isOutOfStock || isProcessing}
              className={`w-full flex items-center justify-center gap-2 rounded-xl py-4 font-black transition-all shadow-lg ${isOutOfStock ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer hover:shadow-emerald-950/20'}`}
            >
              <ShoppingBag className="h-5 w-5" />
              <span>{isProcessing ? (locale === 'ar' ? 'جاري المعالجة...' : 'Processing...') : (isOutOfStock ? (locale === 'ar' ? 'غير متوفر مؤقتاً' : 'Temporarily Unavailable') : (locale === 'ar' ? 'شحن فوري مباشر' : 'Instant Recharge'))}</span>
            </button>
            {isOutOfStock && (
              <p className="text-rose-400 text-xs text-center mt-1 font-semibold">
                {locale === 'ar' ? 'هذه الخدمة معلقة أو منتهية الصلاحية مؤقتاً.' : 'This service is currently disabled or out of stock.'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Description Section */}
      <section className="mt-12 border-t border-zinc-800 pt-8" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
        <h2 className="text-md sm:text-lg font-black text-white pb-3 flex items-center gap-2 border-b border-zinc-800">
          <ClipboardList className="h-5 w-5 text-emerald-500" />
          <span>{locale === 'ar' ? 'معلومات وتفاصيل الشحن' : 'Recharge Description & Details'}</span>
        </h2>
        <div className="mt-6 p-6 sm:p-8 bg-zinc-900/40 rounded-2xl border border-zinc-800/80 leading-relaxed font-sans text-sm text-zinc-300">
          <div dangerouslySetInnerHTML={{ __html: descriptionHtml }} />
        </div>
      </section>
    </div>
  );
};

export default ProductDetail;
