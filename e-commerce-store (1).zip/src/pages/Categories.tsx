import React from 'react';
import { useStore } from '../context/StoreContext';
import { CATEGORIES } from '../data';
import { Gamepad2, Smartphone, Coins, CreditCard, ChevronRight } from 'lucide-react';

const iconMap: Record<string, any> = {
  Gamepad2,
  Smartphone,
  Coins,
  CreditCard
};

export const Categories: React.FC = () => {
  const { locale, navigate } = useStore();

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
      <div className="mb-8">
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <Gamepad2 className="h-6 w-6 text-emerald-500" />
          <span>{locale === 'ar' ? 'فئات وأقسام الشحن' : 'Service Categories'}</span>
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          {locale === 'ar' ? 'اختر القسم المناسب لتصفح باقات شحن الألعاب والبطاقات المتوفرة.' : 'Select a category to browse our instant-charge bundles.'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {CATEGORIES.map((cat) => {
          const IconComponent = iconMap[cat.icon] || Gamepad2;
          const name = locale === 'ar' ? cat.name_ar : cat.name_en;

          return (
            <div
              key={cat.id}
              onClick={() => navigate('category-products', { categoryId: cat.id })}
              className="group relative overflow-hidden bg-zinc-900/60 hover:bg-zinc-900 border border-zinc-800/80 hover:border-emerald-500/40 rounded-3xl p-6 transition-all duration-300 cursor-pointer flex flex-col justify-between h-48 shadow-lg shadow-black/30"
            >
              <div className="absolute top-0 right-0 -mr-4 -mt-4 w-20 h-20 bg-emerald-500/5 rounded-full blur-xl group-hover:bg-emerald-500/10 transition-colors"></div>
              
              <div className="p-3 w-max rounded-2xl bg-zinc-950 border border-zinc-800 text-emerald-400 group-hover:scale-110 group-hover:border-emerald-500/20 transition-all">
                <IconComponent className="h-5 w-5" />
              </div>

              <div className="space-y-1">
                <h3 className="text-sm font-black text-white group-hover:text-emerald-400 transition-colors">
                  {name}
                </h3>
                <div className="flex items-center gap-1 text-[10px] text-gray-500 font-bold group-hover:text-gray-400 transition-colors">
                  <span>{locale === 'ar' ? 'تصفح الباقات' : 'Browse Bundles'}</span>
                  <ChevronRight className={`h-3 w-3 transform transition-transform ${locale === 'ar' ? 'rotate-180' : 'group-hover:translate-x-1'}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Categories;
