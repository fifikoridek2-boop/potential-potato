import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { OrderTimeline } from '../components/OrderTimeline';
import { OrderStatus, Order } from '../types';
import { ArrowLeft, ArrowRight, Package, MapPin, Receipt, Clock, UserCheck, RefreshCw, Eye, EyeOff } from 'lucide-react';
import { db } from '../services/firebase';
import { doc, onSnapshot } from 'firebase/firestore';

export const OrderTracker: React.FC = () => {
  const { locale, currentParams, orders, formatPrice, navigate, showToast, updateOrder } = useStore();
  const orderId = currentParams.orderId;

  const [dbOrder, setDbOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [checkingStatus, setCheckingStatus] = useState(false);

  // Search local orders first or use the fetched one. Fallback only if no specific orderId is provided.
  const localOrder = orderId ? orders.find(o => o.id === orderId) : null;
  const order = localOrder || dbOrder || (orderId ? null : orders[0]);

  const checkLiveOrderStatus = async () => {
    if (!order || !order.isOranosOrder || !order.id) return;
    setCheckingStatus(true);
    try {
      const idOrUuid = order.oranosOrderId || order.oranosOuuid || order.id.replace('QT-', '');
      const isUuid = !!order.oranosOuuid && !order.oranosOrderId;
      const endpoint = isUuid ? `/api/oranos/check-order-uuid/${idOrUuid}` : `/api/oranos/check-order/${idOrUuid}`;
      
      const res = await fetch(endpoint);
      const result = await res.json();
      
      if (result.status === "OK" && result.data) {
        const liveStatus = result.data.status; // accept, reject, wait
        const replayApi = result.data.replay_api || null;
        
        let targetStatus: OrderStatus = 'processing';
        if (liveStatus === "accept") {
          targetStatus = 'completed';
        } else if (liveStatus === "reject") {
          targetStatus = 'canceled';
        }
        
        if (targetStatus !== order.status || JSON.stringify(replayApi) !== JSON.stringify(order.replayApi)) {
          const updated: Order = {
            ...order,
            status: targetStatus,
            replayApi: replayApi || undefined,
            trackingSteps: [
              ...order.trackingSteps,
              { status: targetStatus, timestamp: new Date().toISOString(), completed: true }
            ]
          };
          
          await updateOrder(updated);
          showToast(
            locale === 'ar'
              ? 'تم تحديث حالة الشحنة آلياً بنجاح!'
              : 'Shipment tracking status updated successfully!',
            'success'
          );
        } else {
          showToast(
            locale === 'ar'
              ? 'الحالة محدثة بالفعل وهي قيد المعالجة السريعة حالياً.'
              : 'Tracking status up-to-date. Currently processing downstream.',
            'info'
          );
        }
      } else {
        showToast(
          locale === 'ar' 
            ? 'المزود لم يسجل تحديثاً جديداً بعد.' 
            : 'No new update returned by downstream gateway providers yet.', 
          'info'
        );
      }
    } catch (err: any) {
      console.error(err);
      showToast('Error syncing status', 'error');
    } finally {
      setCheckingStatus(false);
    }
  };

  const renderReplayCodes = () => {
    if (!order || !order.isOranosOrder || !order.replayApi) return null;
    const codes = typeof order.replayApi === 'string' 
      ? [order.replayApi] 
      : Array.isArray(order.replayApi) 
        ? order.replayApi 
        : typeof order.replayApi === 'object'
          ? Object.values(order.replayApi)
          : [];
          
    if (codes.length === 0) return null;

    return (
      <div className="rounded-2xl border-2 border-emerald-500 bg-emerald-950/25 p-5 md:p-6 shadow-lg space-y-3" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr', textAlign: locale === 'ar' ? 'right' : 'left' }}>
        <h3 className="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-1.5 font-sans">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{locale === 'ar' ? 'تم تسليم الرموز بنجاح فوري! ✔️' : 'Instant Codes Sourced successfully!'}</span>
        </h3>
        <p className="text-[10px] text-gray-400 font-bold font-sans">{locale === 'ar' ? 'يمكنك تفعيل الرموز الرقمية المرفقة أدناه لتعبئة حسابك مباشرة:' : 'You can claim the following digital keys to claim your balance/item directly:'}</p>
        <div className="space-y-2 mt-3">
          {codes.map((codeObj: any, index: number) => {
            const codeText = typeof codeObj === 'object' ? JSON.stringify(codeObj) : String(codeObj);
            return (
              <div key={index} className="p-3 bg-gray-950/60 border border-emerald-900/40 rounded-xl flex items-center justify-between gap-3 font-mono text-xs text-emerald-400 border-dashed">
                <span className="font-extrabold select-all leading-relaxed whitespace-pre-wrap break-all">{codeText}</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(codeText);
                    showToast(locale === 'ar' ? 'تم نسخ الرمز للحافظة!' : 'Code copied to clipboard!', 'success');
                  }}
                  className="px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg text-[10px] font-bold shrink-0 transition-all cursor-pointer font-sans"
                >
                  {locale === 'ar' ? 'نسخ الرمز' : 'Copy'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  useEffect(() => {
    if (!orderId) return;
    
    // Set loading only if there's no pre-existing local copy of the order to keep transition smooth
    if (!localOrder) {
      setLoading(true);
    }
    
    const docRef = doc(db, 'orders', orderId);
    const unsub = onSnapshot(docRef, (docSnap) => {
      setLoading(false);
      if (docSnap.exists()) {
        setDbOrder(docSnap.data() as Order);
      } else {
        setDbOrder(null);
      }
    }, (err) => {
      console.error("Error listening to single order tracking:", err);
      setLoading(false);
    });

    return () => unsub();
  }, [orderId, localOrder]);

  const translations = {
    header: locale === 'ar' ? 'تفاصيل حالة الطلب الرقمي' : 'Digital Order Status',
    orderIdTitle: locale === 'ar' ? 'رقم الطلب:' : 'Order Ref:',
    date: locale === 'ar' ? 'تاريخ العملية:' : 'Timestamp:',
    timelineHeader: locale === 'ar' ? 'تتبع حالة التنفيذ' : 'Execution Timeline',
    addressHeader: locale === 'ar' ? 'بيانات المستلم (معرّف اللعبة/الحساب)' : 'Recipient Data (Player ID / Account)',
    receiptHeader: locale === 'ar' ? 'الفاتورة الرقمية وملخص الحساب' : 'Digital Receipt Summary',
    productsHeader: locale === 'ar' ? 'الخدمات الرقمية المطلوبة' : 'Requested Digital Services',
    notes: locale === 'ar' ? 'ملاحظات إضافية مرسلة:' : 'Attached User Notes:',
    subtotal: locale === 'ar' ? 'القيمة الأساسية:' : 'Base Value:',
    delivery: locale === 'ar' ? 'رسوم الخدمة:' : 'Service Fee:',
    discount: locale === 'ar' ? 'خصومات/عروض:' : 'Promo Deductions:',
    grandTotal: locale === 'ar' ? 'المبلغ الإجمالي المقتطع:' : 'Grand Total Deducted:',
    free: locale === 'ar' ? 'بدون رسوم' : 'Free Service',
    backBtn: locale === 'ar' ? 'الرجوع لقائمة العمليات' : 'Back to Order History'
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-xl px-4 py-32 text-center space-y-4">
        <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-black border-t-transparent" />
        <p className="text-xs text-gray-500 font-bold">
          {locale === 'ar' ? 'جاري استيراد وتحديث تفاصيل شحنتك الكريمة...' : 'Retrieving secured shipment journey details...'}
        </p>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center space-y-6">
        <p className="text-gray-400">
          {locale === 'ar' ? 'عذراً، لم نتمكن من العثور على هذا الطلب.' : 'Could not find matching order details.'}
        </p>
        <button
          onClick={() => navigate('order-history')}
          className="rounded-full bg-black py-2.5 px-6 text-xs text-white hover:bg-neutral-800"
        >
          {translations.backBtn}
        </button>
      </div>
    );
  }

  const deliveryTime = new Date(order.timestamp).toLocaleDateString(locale === 'ar' ? 'ar-EG' : 'en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    numberingSystem: 'latn'
  });

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      
      {/* Back to listings button */}
      <div className="mb-6" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
        <button
          onClick={() => navigate('order-history')}
          className="text-xs font-semibold text-gray-400 hover:text-black transition-colors flex items-center justify-center gap-1.5 w-fit"
        >
          {locale === 'ar' ? (
            <>
              <ArrowRight className="h-4 w-4" />
              <span>{translations.backBtn}</span>
            </>
          ) : (
            <>
              <ArrowLeft className="h-4 w-4" />
              <span>{translations.backBtn}</span>
            </>
          )}
        </button>
      </div>

      {/* Main Title bar */}
      <div
        className="rounded-2xl border border-gray-100 bg-white p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6"
        style={{ direction: locale === 'ar' ? 'rtl' : 'ltr', textAlign: locale === 'ar' ? 'right' : 'left' }}
      >
        <div className="space-y-1">
          <h1 className="text-base sm:text-lg font-extrabold text-gray-900 uppercase">
            {translations.header}
          </h1>
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <span>{translations.orderIdTitle}</span>
            <span className="font-semibold text-black font-mono">{order.id}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-gray-400">
          <Clock className="h-4 w-4" />
          <span>{translations.date}</span>
          <span className="font-semibold text-gray-900">{deliveryTime}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        
        {/* Left: Tracker Stepper Timeline (takes 2 grid spaces) */}
        <div className="lg:col-span-2 space-y-6">

          {/* Active codes block */}
          {renderReplayCodes()}

          {/* Check dynamic status button for pending orders */}
          {order.isOranosOrder && order.status === 'processing' && (
            <div className="rounded-2xl border border-dashed border-gray-200 bg-[#0c101b] border-emerald-900/35 p-5 text-center space-y-3" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
              <p className="text-xs font-semibold text-gray-400">
                {locale === 'ar' 
                  ? 'طلبك موجه للربط التلقائي الفوري لمزود الخدمة. يمكنك جلب التحديث المباشر لحالة طلبك فوراً:' 
                  : 'Your shipment is dispatched to automated downstream gateways. You can refresh tracker to pull updates:'}
              </p>
              <button
                onClick={checkLiveOrderStatus}
                disabled={checkingStatus}
                className="mx-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-800 disabled:text-gray-650 text-white text-xs font-extrabold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-emerald-950/10 font-sans"
              >
                <RefreshCw className={`h-4 w-4 ${checkingStatus ? 'animate-spin' : ''}`} />
                <span>{checkingStatus ? (locale === 'ar' ? 'جاري التحقق...' : 'Polling update...') : (locale === 'ar' ? 'تحديث حالة الشحن المباشرة ⚡' : 'Check Direct Live Status')}</span>
              </button>
            </div>
          )}
          
          {/* Stepper block */}
          <div
            className="rounded-2xl border border-gray-100 bg-white p-6 sm:p-8 shadow-md"
            style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}
          >
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-gray-900 pb-3 border-b border-gray-100 flex items-center gap-2 mb-6" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
              <Clock className="h-4.5 w-4.5 text-black" />
              <span>{translations.timelineHeader}</span>
            </h2>

            <OrderTimeline steps={order.trackingSteps} currentStatus={order.status} />
          </div>

          {/* items packaging list */}
          <div
            className="rounded-2xl border border-gray-100 bg-white p-6 shadow-md"
            style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}
          >
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-gray-900 pb-3 border-b border-gray-100 flex items-center gap-2 mb-4" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
              <Package className="h-4.5 w-4.5 text-black" />
              <span>{translations.productsHeader}</span>
            </h2>

            <div className="divide-y divide-gray-50 text-xs">
              {order.items.map((line, lIdx) => {
                const prod = line.product;
                const activePrice = prod.discountPrice ?? prod.price;
                const nameLink = locale === 'ar' ? prod.name_ar : prod.name_en;

                return (
                  <div key={lIdx} className="py-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-gray-50 border border-gray-100">
                        <img src={prod.coverImage} alt={prod.name_en} className="h-full w-full object-cover" />
                      </div>
                      <div className="space-y-0.5" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
                        <p className="font-bold text-gray-900">{nameLink}</p>
                        
                        {/* option details */}
                        {(line.selectedType || line.selectedSize) && (
                          <div className="flex flex-wrap items-center gap-1 text-[9px] text-gray-400">
                            {line.selectedType && <span>{line.selectedType}</span>}
                            {line.selectedType && line.selectedSize && <span>•</span>}
                            {line.selectedSize && <span>{line.selectedSize}</span>}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="shrink-0 text-right font-mono text-xs">
                      <span className="text-gray-400">
                        {line.quantity} x{' '}
                      </span>
                      <span className="font-bold text-gray-950">
                        {formatPrice(activePrice)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right: Address & Bill overview */}
        <div className="space-y-6">
          
          {/* Dispatch coordinates summary */}
          <div
            className="rounded-2xl border border-gray-100 bg-white p-6 shadow-md space-y-4"
            style={{ direction: locale === 'ar' ? 'rtl' : 'ltr', textAlign: locale === 'ar' ? 'right' : 'left' }}
          >
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-gray-900 pb-2 border-b border-gray-50 flex items-center gap-2">
              <UserCheck className="h-4 w-4" />
              <span>{translations.addressHeader}</span>
            </h2>

            <div className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <span className="text-[10px] text-gray-400 uppercase tracking-widest block">{locale === 'ar' ? 'الاسم:' : 'Name:'}</span>
                <span className="font-bold text-gray-900">{order.userName || 'N/A'}</span>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] text-gray-400 uppercase tracking-widest block">{locale === 'ar' ? 'رقم الاتصال:' : 'Contact Phone:'}</span>
                <span className="font-mono text-gray-900" style={{ direction: 'ltr', display: 'inline-block' }}>{order.userPhone || 'N/A'}</span>
              </div>

              {order.playerId && (
                <div className="space-y-1">
                  <span className="text-[10px] text-gray-400 uppercase tracking-widest block">{locale === 'ar' ? 'معرّف اللعبة (Player ID):' : 'Game Player ID:'}</span>
                  <span className="text-emerald-700 font-mono font-black py-1 px-2.5 bg-emerald-50 rounded-lg inline-block border border-emerald-100">{order.playerId}</span>
                </div>
              )}

              {order.additionalNotes && (
                <div className="p-3 bg-neutral-50 rounded-lg text-[11px] text-neutral-600 border border-neutral-100">
                  <span className="font-bold block text-gray-900 mb-0.5">{translations.notes}</span>
                  <span>{order.additionalNotes}</span>
                </div>
              )}
            </div>
          </div>

          {/* Bill details */}
          <div
            className="rounded-2xl border border-gray-100 bg-white p-6 shadow-md space-y-4"
            style={{ direction: locale === 'ar' ? 'rtl' : 'ltr', textAlign: locale === 'ar' ? 'right' : 'left' }}
          >
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-gray-900 pb-2 border-b border-gray-50 flex items-center gap-2">
              <Receipt className="h-4 w-4" />
              <span>{translations.receiptHeader}</span>
            </h2>

            <div className="space-y-3 text-xs pb-3 border-b border-gray-50">
              
              {/* Cost products */}
              <div className="flex justify-between items-center text-gray-500">
                <span>{translations.subtotal}</span>
                <span className="font-mono font-semibold text-gray-900">
                  {formatPrice(order.subtotal)}
                </span>
              </div>

              {/* Delivery rate */}
              <div className="flex justify-between items-center text-gray-500">
                <span>{translations.delivery}</span>
                <span className="font-mono font-semibold text-gray-900">
                  {order.shipping === 0 ? (
                    <span className="text-green-600 font-bold">{translations.free}</span>
                  ) : (
                    formatPrice(order.shipping)
                  )}
                </span>
              </div>

              {/* Payment Method */}
              <div className="flex justify-between items-center text-gray-500">
                <span>{locale === 'ar' ? 'وسيلة الدفع:' : 'Payment Method:'}</span>
                <span className="font-semibold text-gray-900">
                  {order.paymentMethod === 'cod'
                    ? (locale === 'ar' ? 'الدفع عند الاستلام' : 'Cash on Delivery')
                    : (locale === 'ar' ? 'بطاقة بنكية إلكترونية' : 'Credit / Debit Card')}
                </span>
              </div>

              {/* Discount rates */}
              {order.discount > 0 && (
                <div className="flex justify-between items-center text-green-650 font-semibold">
                  <span>{translations.discount}</span>
                  <span className="font-mono">
                    -{formatPrice(order.discount)}
                  </span>
                </div>
              )}

            </div>

            {/* Total Aggregate price */}
            <div className="flex justify-between items-end text-sm pt-1">
              <span className="font-extrabold text-gray-900">{translations.grandTotal}</span>
              <span className="text-base font-black text-black font-mono">
                {formatPrice(order.total)}
              </span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
export default OrderTracker;
