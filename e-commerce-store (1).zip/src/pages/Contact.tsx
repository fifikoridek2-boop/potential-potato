import React from 'react';
import { useStore } from '../context/StoreContext';
import { 
  LifeBuoy, 
  AlertCircle, 
  Phone, 
  Mail, 
  MessageCircle, 
  Send, 
  ArrowUpRight,
  ShieldCheck,
  Clock
} from 'lucide-react';

export const Contact: React.FC = () => {
  const { locale } = useStore();

  const contactChannels = [
    {
      id: 'whatsapp',
      name_ar: 'الواتساب المباشر',
      name_en: 'Direct WhatsApp Chat',
      value: '+963 935 444 656',
      desc_ar: 'تواصل مالي وتأكيد سريع للحوالات المالية على مدار الساعة.',
      desc_en: 'Instant order, deposit verification and financial clearances.',
      link: 'https://wa.me/963935444656',
      icon: MessageCircle,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
    },
    {
      id: 'telegram',
      name_ar: 'قناة وتواصل تيليجرام',
      name_en: 'Telegram Support Line',
      value: '@QadiTechSupport',
      desc_ar: 'قناة المنصة الرسمية ومحادثة الدعم الفني الفوري والمجند للرد.',
      desc_en: 'Get live system broadcast announcements and direct chats.',
      link: 'https://t.me/QadiTechSupport',
      icon: Send,
      color: 'text-sky-400 bg-sky-500/10 border-sky-500/20'
    },
    {
      id: 'phone',
      name_ar: 'خط الاتصال المباشر',
      name_en: 'Direct Telephone Line',
      value: '+963 11 234 5678',
      desc_ar: 'للمكالمات الصوتية المباشرة وحل المشاكل الحرجة والدعم الهاتفي.',
      desc_en: 'Direct voice calls to resolve high priority order blocks.',
      link: 'tel:+963112345678',
      icon: Phone,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/20'
    },
    {
      id: 'email',
      name_ar: 'البريد الإلكتروني المعتمد',
      name_en: 'Official Email Mailbox',
      value: 'support@qaditech.com',
      desc_ar: 'أرسل لنا استفساراتك التجارية والاقتراحات على تذاكر البريد.',
      desc_en: 'Send partnership proposals or high tier business queries.',
      link: 'mailto:support@qaditech.com',
      icon: Mail,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/20'
    }
  ];

  const faqs = [
    {
      q_ar: 'كم يستغرق شحن الرصيد بعد تأكيد الحوالة؟',
      q_en: 'How long does wallet recharge take after confirmation?',
      a_ar: 'يتم مراجعة إيصال التحويل وشحن المحفظة تلقائياً أو يدوياً خلال فترة تتراوح بين دقيقة إلى 15 دقيقة كحد أقصى على مدار 24 ساعة.',
      a_en: 'Transfer slips are checked and processed within 1 to 15 minutes max, active 24/7.'
    },
    {
      q_ar: 'ماذا لو أخطأت في كتابة الآيدي الـ ID الخاص باللاعب؟',
      q_en: 'What happens if I enter an incorrect Player ID?',
      a_ar: 'المنصة تشحن آلياً فور تأكيد الشراء. يرجى مراجعة الآيدي بدقة قبل الإرسال، حيث لا يمكن استرداد الرصيد المشحون لمعرف خاطئ قد تم تنفيذه فعلياً.',
      a_en: 'Since transactions are automated based on the input ID, please verify it diligently. Vouchers successfully deployed to invalid IDs cannot be refunded.'
    },
    {
      q_ar: 'ما هي بوابات الدفع المحلية المدعومة لشحن المحفظة؟',
      q_en: 'What local payment options are supported?',
      a_ar: 'ندعم بوابات دفع سريعة وآمنة تشمل: سيريتل كاش (Syriatel Cash)، شام كاش (Cham Cash)، فودافون كاش (Vodafone Cash)، بالإضافة لعملة USDT الرقمية المستقرة للتعبئة الفورية.',
      a_en: 'We support local cash networks including Syriatel Cash, Sham Cash, Vodafone Cash, alongside USDT stablecoins for instant global top-ups.'
    }
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
      {/* Page Title Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <LifeBuoy className="h-6 w-6 text-emerald-500 animate-pulse" />
          <span>{locale === 'ar' ? 'الدعم الفني وقنوات الاتصال المباشر' : 'Technical Support & Direct Contact'}</span>
        </h1>
        <p className="text-xs text-gray-400 mt-1 max-w-xl leading-relaxed">
          {locale === 'ar' 
            ? 'تخطي حواجز الانتظار وتواصل معنا مباشرة عبر قنوات الاتصال الفورية لحل أي مشكلة شحن أو إيداع مالي.' 
            : 'Skip the line and interface directly with our customer support representatives across our instant messaging networks for immediate billing checkouts.'}
        </p>
      </div>

      {/* Info Warning Bar */}
      <div className="mb-8 p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex gap-3 items-center">
          <Clock className="h-5 w-5 text-emerald-400 shrink-0" />
          <div>
            <h4 className="text-xs font-black text-white">
              {locale === 'ar' ? 'فريق الدعم متصل حالياً' : 'Support Desk is Currently Active'}
            </h4>
            <p className="text-[10px] sm:text-xs text-gray-400">
              {locale === 'ar' ? 'أوقات الاستجابة الفورية تتراوح بين دقيقة إلى ١٠ دقائق كحد أقصى.' : 'Real-time response times typically range between 1 to 10 minutes.'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-black uppercase px-2.5 py-1 rounded-full">
          <ShieldCheck className="h-3.5 w-3.5" />
          <span>{locale === 'ar' ? 'آمن بنسبة ١٠٠٪' : '100% Certified Safe'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left column: Grid of direct contact channel cards */}
        <div className="lg:col-span-7 space-y-4">
          <h2 className="text-xs font-black uppercase text-emerald-400 tracking-wider">
            {locale === 'ar' ? 'روابط وقنوات التواصل الفورية المباشرة' : 'Instant Direct Communications'}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {contactChannels.map((chan) => {
              const IconComp = chan.icon;
              const name = locale === 'ar' ? chan.name_ar : chan.name_en;
              const desc = locale === 'ar' ? chan.desc_ar : chan.desc_en;

              return (
                <a
                  key={chan.id}
                  href={chan.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group relative block overflow-hidden bg-zinc-900/40 hover:bg-zinc-900 border border-zinc-800/80 hover:border-emerald-500/30 rounded-3xl p-5 transition-all duration-350 shadow-xl"
                >
                  <div className="absolute top-0 right-0 -mr-4 -mt-4 w-16 h-16 bg-emerald-500/5 rounded-full blur-xl group-hover:bg-emerald-500/10 transition-colors"></div>

                  <div className="flex justify-between items-start mb-4">
                    <div className={`p-3 rounded-2xl border ${chan.color}`}>
                      <IconComp className="h-5 w-5" />
                    </div>
                    <div className="text-zinc-500 group-hover:text-emerald-400 transition-colors">
                      <ArrowUpRight className="h-4.5 w-4.5" />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="text-xs font-black text-white group-hover:text-emerald-400 transition-colors">
                      {name}
                    </h3>
                    <p className="text-xs font-mono font-bold text-emerald-400/90 tracking-wide select-all">
                      {chan.value}
                    </p>
                    <p className="text-[10px] text-zinc-500 leading-relaxed font-semibold">
                      {desc}
                    </p>
                  </div>
                </a>
              );
            })}
          </div>
        </div>

        {/* Right column: FAQ section */}
        <div className="lg:col-span-5 space-y-4">
          <h2 className="text-xs font-black uppercase text-emerald-400 tracking-wider flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-emerald-400" />
            <span>{locale === 'ar' ? 'الأسئلة الشائعة والحلول السريعة' : 'Frequently Asked Questions'}</span>
          </h2>

          <div className="space-y-4">
            {faqs.map((faq, idx) => {
              const q = locale === 'ar' ? faq.q_ar : faq.q_en;
              const a = locale === 'ar' ? faq.a_ar : faq.a_en;

              return (
                <div key={idx} className="bg-zinc-900/30 border border-zinc-800/80 rounded-3xl p-5 hover:border-zinc-700/50 transition-colors">
                  <h4 className="text-xs sm:text-sm font-extrabold text-white mb-2 flex items-start gap-1.5 leading-relaxed">
                    <span className="text-emerald-500 text-sm font-black">؟</span>
                    <span>{q}</span>
                  </h4>
                  <p className="text-xs text-zinc-400 leading-relaxed pl-3 pr-3">
                    {a}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
