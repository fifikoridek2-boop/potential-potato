import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../services/firebase';
import { useStore } from '../context/StoreContext';
import { Product } from '../types';
import { Gamepad2, ArrowUpRight, Search, Star, Sparkles } from 'lucide-react';

export const CategoryProducts: React.FC = () => {
  const { locale, formatPrice, navigate, categories } = useStore();
  const { categoryId } = useParams<{ categoryId?: string }>();
  const [searchParams] = useSearchParams();
  const queryParam = searchParams.get('q') || '';

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState(queryParam);

  const category = categories?.find(c => c.id === categoryId);

  useEffect(() => {
    async function loadProducts() {
      setLoading(true);
      try {
        let items: Product[] = [];
        const colRef = collection(db, 'products');
        
        let q = query(colRef);
        if (categoryId) {
          q = query(colRef, where('categoryId', '==', categoryId));
        }
        
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          snapshot.forEach(docSnap => {
            items.push({ id: docSnap.id, ...docSnap.data() } as Product);
          });
        }

        setProducts(items);
      } catch (err) {
        setProducts([]);
      } finally {
        setLoading(false);
      }
    }
    loadProducts();
  }, [categoryId]);

  // Apply search filtering
  const filteredProducts = products.filter(p => {
    const name = (locale === 'ar' ? p.name_ar : p.name_en).toLowerCase();
    const desc = (locale === 'ar' ? p.description_ar : p.description_en).toLowerCase();
    const searchLow = searchQuery.toLowerCase();
    return name.includes(searchLow) || desc.includes(searchLow);
  });

  const categoryName = category 
    ? (locale === 'ar' ? category.name_ar : category.name_en) 
    : (locale === 'ar' ? 'جميع باقات الشحن' : 'All Charging Bundles');

  const categoryDesc = category
    ? (locale === 'ar' ? `باقات واشتراكات مخصصة لـ ${categoryName}` : `Exclusive premium bundles for ${categoryName}`)
    : (locale === 'ar' ? 'شحن فوري مباشر لمختلف حسابات الألعاب والبطاقات' : 'Instant direct vouchers and game credit loads');

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
      {/* Category Jumbotron */}
      <div className="bg-zinc-900/40 border border-zinc-800 p-6 sm:p-8 rounded-3xl mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Gamepad2 className="h-6 w-6 text-emerald-500" />
            <span>{categoryName}</span>
          </h1>
          <p className="text-xs text-zinc-400 mt-1">{categoryDesc}</p>
        </div>

        {/* Instant Search Bar */}
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
          <input
            type="text"
            placeholder={locale === 'ar' ? 'بحث عن باقة...' : 'Search for a bundle...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2.5 pl-9 pr-4 text-white text-xs placeholder-zinc-600 focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500 mb-4 animate-pulse"></div>
          <p className="text-xs font-semibold">{locale === 'ar' ? 'جاري تحميل باقات الشحن الفوري...' : 'Loading instant-charge bundles...'}</p>
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="text-center py-16 bg-zinc-900/20 border border-zinc-800/50 rounded-3xl p-8 max-w-md mx-auto">
          <Sparkles className="h-8 w-8 text-emerald-500 mx-auto mb-3 opacity-60" />
          <h3 className="text-sm font-bold text-white mb-1">
            {locale === 'ar' ? 'لا توجد نتائج بحث مطابقة' : 'No Bundles Found'}
          </h3>
          <p className="text-xs text-zinc-500 leading-relaxed mb-4">
            {locale === 'ar' ? 'لم نجد أي باقات شحن تتبع كلمات البحث المدخلة. حاول بعبارة بديلة.' : 'We could not find any active top-up packages matching your check. Try another word.'}
          </p>
          <button onClick={() => setSearchQuery('')} className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-bold transition-all border border-zinc-700">
            {locale === 'ar' ? 'عرض الكل' : 'View All'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const name = locale === 'ar' ? product.name_ar : product.name_en;
            const finalPrice = product.discountPrice ?? product.price;
            const badge = locale === 'ar' ? product.badge_ar : product.badge_en;

            return (
              <div
                key={product.id}
                onClick={() => navigate('product-detail', { productId: product.id })}
                className="group relative flex flex-col justify-between overflow-hidden bg-zinc-900/60 hover:bg-zinc-900 border border-zinc-800/80 hover:border-emerald-500/40 rounded-3xl p-5 transition-all duration-300 cursor-pointer shadow-lg shadow-black/30 w-full"
              >
                {/* Visual Badge */}
                {badge && (
                  <span className="absolute top-4 left-4 z-10 bg-emerald-500 text-black text-[9px] font-black uppercase px-2.5 py-1 rounded-full shadow-md font-mono">
                    {badge}
                  </span>
                )}

                {/* Cover Asset */}
                <div className="relative aspect-video overflow-hidden rounded-2xl bg-zinc-950 border border-zinc-800">
                  <img
                    src={product.coverImage}
                    alt={name}
                    className="h-full w-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                    <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                      <span>{locale === 'ar' ? 'شحن فوري مباشر' : 'Instant Direct Delivery'}</span>
                      <ArrowUpRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </div>

                <div className="space-y-4 mt-4 flex-1 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <h3 className="text-sm font-extrabold text-white group-hover:text-emerald-400 line-clamp-1 transition-colors">
                      {name}
                    </h3>
                    <p className="text-[11px] text-zinc-500 line-clamp-2 leading-relaxed">
                      {locale === 'ar' ? 'باقات شحن سريعة وآمنة بضمان معتمد دائم.' : 'Fast digital charging bundle with secure server authorization.'}
                    </p>
                  </div>

                  <div className="flex justify-between items-center pt-3 border-t border-zinc-800/80 mt-auto">
                    <div className="flex items-baseline gap-1.5 font-mono">
                      <span className="text-base font-black text-emerald-400">
                        {formatPrice(finalPrice)}
                      </span>
                      {product.discountPrice && (
                        <span className="text-[10px] text-zinc-500 line-through">
                          {formatPrice(product.price)}
                        </span>
                      )}
                    </div>
                    {product.rating && (
                      <div className="flex items-center gap-1 bg-zinc-950/80 px-2 py-0.5 rounded-md border border-zinc-800/50">
                        <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
                        <span className="text-[10px] font-bold text-gray-300 font-mono">{product.rating}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default CategoryProducts;
