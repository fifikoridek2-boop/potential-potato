import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { User, Mail, Phone, Wallet, Coins, Save, CheckCircle } from 'lucide-react';

export const Settings: React.FC = () => {
  const { locale, user, updateProfile, formatPrice, currency, toggleCurrency, showToast } = useStore();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState<'USD' | 'SYP' | 'EGP'>('USD');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setEmail(user.email || '');
      setPhone(user.phone || '');
    }
  }, [user]);

  useEffect(() => {
    setSelectedCurrency(currency);
  }, [currency]);

  // Sync currency dropdown selection to the global context state using toggle currency cycle
  const handleCurrencyChange = (newCurr: 'USD' | 'SYP' | 'EGP') => {
    setSelectedCurrency(newCurr);
    // Cycle toggleCurrency until match
    if (currency !== newCurr) {
      localStorage.setItem('store_currency', newCurr);
      // We can trigger window reload or toggle to sync
      window.location.reload();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast(locale === 'ar' ? 'الاسم مطلوب' : 'Name is required', 'error');
      return;
    }
    if (!phone.trim()) {
      showToast(locale === 'ar' ? 'رقم الهاتف إجباري ومحوري لتوريد طلباتك' : 'Phone number is mandatory for your orders', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      await updateProfile({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim()
      });
      showToast(locale === 'ar' ? 'تم تحديث الملف الشخصي بنجاح' : 'Profile updated successfully', 'success');
    } catch (err) {
      showToast(locale === 'ar' ? 'فشل التحديث' : 'Failed to update profile', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getBalance = () => {
    if (!user) return 0;
    if (currency === 'SYP') return user.balanceSYP ?? 3500000;
    if (currency === 'EGP') return user.balanceEGP ?? 12000;
    return user.balanceUSD ?? 250;
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-8" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
      <div className="mb-8">
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <User className="h-6 w-6 text-emerald-500" />
          <span>{locale === 'ar' ? 'ملفي الشخصي' : 'My Profile / Settings'}</span>
        </h1>
        <p className="text-xs text-gray-400 mt-1">
          {locale === 'ar' ? 'تعديل بيانات الحساب وتفضيلات العملة على Qadi Tech.' : 'Manage profile info and currency preferences on Qadi Tech.'}
        </p>
      </div>

      {/* Prominent Wallet Balance Card */}
      <div className="relative overflow-hidden bg-gradient-to-br from-zinc-900 to-zinc-950 p-6 sm:p-8 rounded-3xl border border-zinc-800 shadow-xl shadow-black/50 mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl"></div>
        <div className="space-y-1.5 z-10">
          <div className="text-[11px] font-black uppercase text-emerald-500 tracking-widest flex items-center gap-1">
            <Coins className="h-3 w-3" />
            <span>{locale === 'ar' ? 'الرصيد المتاح حالياً' : 'Current Wallet Balance'}</span>
          </div>
          <div className="text-2xl sm:text-3.5xl font-black text-white font-mono">
            {formatPrice(getBalance())}
          </div>
        </div>
        <div className="p-3 sm:p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold z-10 text-xs flex items-center gap-2">
          <Wallet className="h-4 w-4" />
          <span>{locale === 'ar' ? 'المحفظة الرقمية نشطة' : 'Digital Wallet Active'}</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-zinc-900/60 border border-zinc-800/80 p-6 sm:p-8 rounded-3xl space-y-6">
        {/* Full Name */}
        <div className="space-y-2">
          <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider">
            {locale === 'ar' ? 'الاسم الكامل *' : 'Full Name *'}
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-emerald-500 font-sans transition-colors"
              required
            />
          </div>
        </div>

        {/* Phone [Obligatory] */}
        <div className="space-y-2">
          <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
            <span>{locale === 'ar' ? 'رقم الهاتف المعتمد لشحن البطاقات (إجباري)*' : 'Verified Phone Number (Mandatory)*'}</span>
          </label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+963..."
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono transition-colors"
              required
            />
          </div>
        </div>

        {/* Email */}
        <div className="space-y-2">
          <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider">
            {locale === 'ar' ? 'البريد الإلكتروني' : 'Email Address'}
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-emerald-500 font-sans transition-colors"
              disabled
            />
          </div>
        </div>

        {/* Preferred Currency Dropdown */}
        <div className="space-y-2 pt-2 border-t border-zinc-800/80">
          <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider">
            {locale === 'ar' ? 'العملة المفضلة لعرض الأسعار' : 'Preferred Billing Currency'}
          </label>
          <select
            value={selectedCurrency}
            onChange={(e) => handleCurrencyChange(e.target.value as 'USD' | 'SYP' | 'EGP')}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-emerald-500 font-sans transition-colors"
          >
            <option value="USD">{locale === 'ar' ? 'USD ($) - الدولار الأمريكي' : 'USD ($) - US Dollar'}</option>
            <option value="SYP">{locale === 'ar' ? 'SYP (ل.س) - الليرة السورية' : 'SYP (SP) - Syrian Pound'}</option>
            <option value="EGP">{locale === 'ar' ? 'EGP (ج.م) - الجنيه المصري' : 'EGP (LE) - Egyptian Pound'}</option>
          </select>
          <p className="text-[10px] text-zinc-500 mt-1">
            {locale === 'ar' ? 'سيتم التبديل التلقائي لجميع باقات الشحن والأسعار وفق العملة المختارة.' : 'All system items prices and balance will adapt to your choice.'}
          </p>
        </div>

        {/* Submit */}
        <div className="pt-4 flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs px-6 py-3.5 rounded-xl transition-all shadow-md shadow-emerald-900/10 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Save className="h-4 w-4" />
            <span>{isSubmitting ? (locale === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (locale === 'ar' ? 'حفظ التغييرات' : 'Save Profiles')}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default Settings;
