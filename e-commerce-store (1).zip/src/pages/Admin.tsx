import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  TrendingUp, 
  ShoppingBag, 
  Users, 
  Sliders, 
  UserPlus, 
  Database, 
  Mail, 
  Trash2, 
  Plus, 
  Check, 
  RefreshCw, 
  Key, 
  ShieldCheck, 
  Search, 
  Clock, 
  FileText, 
  Coins, 
  ArrowLeftRight, 
  AlertTriangle,
  User,
  Settings,
  Image as ImageIcon
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { doc, updateDoc, collection, addDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { Order, OrderStatus } from '../types';
import { ProductManager } from '../components/admin/ProductManager';
import { SyncManager } from '../components/admin/SyncManager';

export const Admin: React.FC = () => {
  const {
    locale,
    currency,
    formatPrice,
    showToast,
    orders,
    products,
    categories,
    usersList,
    settings,
    updateSettings,
    updateOrder,
    seedAllDatabase,
    resetAndReinitDatabase,
    getOranosConfig,
    updateOranosConfig,
    syncOranosCatalog
  } = useStore();

  const [activeTab, setActiveTab] = useState<'stats' | 'products' | 'sync' | 'orders' | 'customers' | 'settings'>('stats');
  
  // Search states
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [customerSearch, setCustomerSearch] = useState('');

  // Admins state
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const activeAdmins = settings?.adminEmails || ['akiocodex1@gmail.com'];

  // Oranos config and live profile
  const [oranosConfig, setOranosConfig] = useState<any>(null);
  const [liveProfile, setLiveProfile] = useState<any>(null);
  const [isFetchingProfile, setIsFetchingProfile] = useState(false);

  // Customer balance adjustment modal state
  const [selectedCustomer, setSelectedCustomer] = useState<any | null>(null);
  const [balanceDelta, setBalanceDelta] = useState<number>(0);
  const [adjustmentType, setAdjustmentType] = useState<'credit' | 'debit'>('credit');
  const [isAdjustingBalance, setIsAdjustingBalance] = useState(false);

  // Fetch connection config and live Oranos API Profile
  const fetchOranosStatusAndProfile = async () => {
    try {
      const config = await getOranosConfig();
      setOranosConfig(config);
      
      if (config && config.configured && firebaseUserToken) {
        setIsFetchingProfile(true);
        const refRes = await fetch('/api/admin/oranos/profile', {
          headers: {
            'Authorization': `Bearer ${firebaseUserToken}`
          }
        });
        if (refRes.ok) {
          const profileData = await refRes.json();
          setLiveProfile(profileData);
        }
        setIsFetchingProfile(false);
      }
    } catch (err) {
      console.warn("Error loading Oranos connection/profile details:", err);
      setIsFetchingProfile(false);
    }
  };

  // Get administrative idToken
  const [firebaseUserToken, setFirebaseUserToken] = useState('');
  const { auth } = useStore(); // use auth from firebase
  useEffect(() => {
    const fetchToken = async () => {
      if (auth?.currentUser) {
        const token = await auth.currentUser.getIdToken();
        setFirebaseUserToken(token);
      }
    };
    fetchToken();
  }, [auth?.currentUser, activeTab]);

  useEffect(() => {
    fetchOranosStatusAndProfile();
  }, [activeTab, firebaseUserToken]);

  // Calculations for stats
  const completedOrders = orders.filter(o => o.status === 'completed');
  const pendingOrders = orders.filter(o => !['completed', 'canceled'].includes(o.status));
  const totalVolumeUSD = completedOrders.reduce((sum, o) => sum + o.total, 0);

  // Profit margins accumulated
  const totalProfitUSD = completedOrders.reduce((sum, o) => sum + (o.profit || 0), 0);

  // Generate charts trend on days
  const getSalesTrend = () => {
    const trends: { [key: string]: number } = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', numberingSystem: 'latn' });
      trends[key] = 0;
    }

    completedOrders.forEach(o => {
      const dateKey = new Date(o.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric', numberingSystem: 'latn' });
      if (trends[dateKey] !== undefined) {
        trends[dateKey] += Math.round(o.total);
      }
    });

    return Object.keys(trends).map(key => ({ day: key, sales: trends[key] }));
  };

  // Filter orders
  const filteredOrders = orders.filter(o => {
    const matchesSearch = 
      o.id.toLowerCase().includes(orderSearch.toLowerCase()) || 
      (o.userEmail && o.userEmail.toLowerCase().includes(orderSearch.toLowerCase())) ||
      (o.userPhone && o.userPhone.includes(orderSearch)) ||
      (o.playerId && o.playerId.toLowerCase().includes(orderSearch.toLowerCase()));
    
    const matchesStatus = orderStatusFilter === 'all' || o.status === orderStatusFilter;
    return matchesSearch && matchesStatus;
  });

  // Filter customers
  const filteredCustomers = usersList.filter(u => {
    const query = customerSearch.toLowerCase();
    return (
      (u.displayName || '').toLowerCase().includes(query) ||
      (u.email || '').toLowerCase().includes(query) ||
      (u.phone || '').toLowerCase().includes(query) ||
      (u.uid || '').toLowerCase().includes(query)
    );
  });

  // Action: approve wallet/manual order re-charge
  const handleApproveOrder = async (order: Order) => {
    try {
      const updatedOrder = {
        ...order,
        status: 'completed' as OrderStatus,
        trackingSteps: order.trackingSteps.map(step => ({
          ...step,
          completed: true,
          timestamp: new Date().toISOString()
        }))
      };
      await updateOrder(updatedOrder);
      showToast(locale === 'ar' ? 'تم تأكيد ومعالجة الطلب بالكامل!' : 'Order marked as completed immediately!', 'success');
    } catch (e) {
      showToast('Error completing order', 'error');
    }
  };

  const handleCancelOrder = async (order: Order) => {
    try {
      const updatedOrder = {
        ...order,
        status: 'canceled' as OrderStatus
      };
      await updateOrder(updatedOrder);
      showToast(locale === 'ar' ? 'تم إلغاء طلب الشحن بنجاح.' : 'Order marked as canceled.', 'success');
    } catch (e) {
      showToast('Error canceling', 'error');
    }
  };

  // Action: Add Admin email rules
  const handleAddAdmin = () => {
    if (!newAdminEmail.trim() || !newAdminEmail.includes('@')) {
      showToast(locale === 'ar' ? 'الرجاء إدخال بريد إلكتروني صالح.' : 'Please enter a valid email.', 'error');
      return;
    }
    const currentEmails = [...activeAdmins];
    if (currentEmails.includes(newAdminEmail.trim())) {
      showToast(locale === 'ar' ? 'هذا المسؤول مسجل بالفعل!' : 'Admin email already exists!', 'error');
      return;
    }
    const updated = [...currentEmails, newAdminEmail.trim()];
    updateSettings({
      ...settings,
      adminEmails: updated
    });
    setNewAdminEmail('');
    showToast(locale === 'ar' ? 'تم إضافة المسؤول الجديد بنجاح.' : 'New administrator successfully added!', 'success');
  };

  const handleRemoveAdmin = (email: string) => {
    if (activeAdmins.length <= 1) {
      showToast(locale === 'ar' ? 'لا يمكن حذف المسؤول الأخير بالتطبيق!' : 'Cannot delete the single active administrator!', 'error');
      return;
    }
    const updated = activeAdmins.filter(e => e !== email);
    updateSettings({
      ...settings,
      adminEmails: updated
    });
    showToast(locale === 'ar' ? 'تمت إزالة المسؤول بنجاح.' : 'Administrator removed successfully.', 'success');
  };

  // Adjust customer balance
  const handleAdjustBalanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer || balanceDelta <= 0 || isAdjustingBalance) return;
    setIsAdjustingBalance(true);

    try {
      const currentBalance = Number(selectedCustomer.balance) || 0;
      let targetBalance = currentBalance;

      if (adjustmentType === 'credit') {
        targetBalance += balanceDelta;
      } else {
        targetBalance = Math.max(0, currentBalance - balanceDelta);
      }

      // Update Firestore user document
      await updateDoc(doc(db, 'users', selectedCustomer.uid), {
        balance: targetBalance,
        updatedAt: new Date().toISOString()
      });

      // Write administrative logging document
      const adjustLogId = `admin_bal_${Date.now()}`;
      await addDoc(collection(db, 'balanceLogs'), {
        id: adjustLogId,
        uid: selectedCustomer.uid,
        userEmail: selectedCustomer.email,
        type: adjustmentType,
        amount: balanceDelta,
        previousBalance: currentBalance,
        currentBalance: targetBalance,
        timestamp: new Date().toISOString(),
        issuer: auth?.currentUser?.email || 'Admin Agent'
      });

      showToast(
        locale === 'ar'
          ? `تم تحديث رصيد (${selectedCustomer.displayName}) بنجاح! الرصيد الجديد: $${targetBalance.toFixed(2)}`
          : `Balance adjustment processed! New balance: $${targetBalance.toFixed(2)} for ${selectedCustomer.displayName}`,
        'success'
      );
      setSelectedCustomer(null);
      setBalanceDelta(0);
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsAdjustingBalance(false);
    }
  };

  const getOrderStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'completed': return 'text-emerald-400 bg-emerald-950/40 border border-emerald-900/50';
      case 'canceled': return 'text-rose-400 bg-rose-950/40 border border-rose-900/50';
      case 'processing': return 'text-amber-400 bg-amber-950/40 border border-amber-900/50';
      default: return 'text-blue-400 bg-blue-950/40 border border-blue-900/50';
    }
  };

  const t = {
    adminTitle: locale === 'ar' ? 'قاضي تيك إداري ⚙️' : 'Qadi Tech Admin Panel',
    commandVersion: locale === 'ar' ? 'لوحة تحكم وتحكم المتجر v3.0' : 'Command center v3.0',
    tabStats: locale === 'ar' ? 'إحصائيات المنصة والأداء' : 'Analytics & Stats',
    tabProducts: locale === 'ar' ? 'إدارة كتالوج المنتجات' : 'Products Manager',
    tabSync: locale === 'ar' ? 'لوحة مزامنة أورانوس' : 'Oranos API Sync',
    tabOrders: locale === 'ar' ? 'إدارة الطلبات والشحن ⚡' : 'Orders & Queue',
    tabCustomers: locale === 'ar' ? 'حسابات العملاء والمحفظة' : 'Customer Wallets',
    tabSettings: locale === 'ar' ? 'الإعدادات العامة والأمان' : 'General & Admins',
    formatFirebase: locale === 'ar' ? 'فرمتة وإعادة تهيئة Firebase ⚙️' : 'Re-initialize Firebase DB',
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-white flex flex-col md:flex-row font-sans" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-[#0a0d16] p-5 shrink-0 border-r border-gray-850 md:sticky md:top-0 z-20 flex flex-col justify-between">
        <div className="space-y-8">
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-xl bg-emerald-600 text-white shadow-lg shadow-emerald-500/15">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <div>
              <h1 className="text-sm font-black tracking-normal text-white uppercase">{t.adminTitle}</h1>
              <p className="text-[10px] text-gray-500 font-bold mt-0.5">{t.commandVersion}</p>
            </div>
          </div>

          <nav className="space-y-1.5">
            <button
              onClick={() => setActiveTab('stats')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'stats' ? 'bg-emerald-600 text-white shadow-md' : 'text-gray-400 hover:text-white hover:bg-gray-900/40'
              }`}
            >
              <TrendingUp className="h-4 w-4" />
              <span>{t.tabStats}</span>
            </button>

            <button
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'products' ? 'bg-emerald-600 text-white shadow-md' : 'text-gray-400 hover:text-white hover:bg-gray-900/40'
              }`}
            >
              <ShoppingBag className="h-4 w-4" />
              <span>{t.tabProducts}</span>
            </button>

            <button
              onClick={() => setActiveTab('sync')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'sync' ? 'bg-emerald-600 text-white shadow-md' : 'text-gray-400 hover:text-white hover:bg-gray-900/40'
              }`}
            >
              <Sliders className="h-4 w-4" />
              <span>{t.tabSync}</span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'orders' ? 'bg-emerald-600 text-white shadow-md' : 'text-gray-400 hover:text-white hover:bg-gray-900/40'
              }`}
            >
              <FileText className="h-4 w-4" />
              <span>{t.tabOrders}</span>
              {pendingOrders.length > 0 && (
                <span className="bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full ml-auto">
                  {pendingOrders.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('customers')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'customers' ? 'bg-emerald-600 text-white shadow-md' : 'text-gray-400 hover:text-white hover:bg-gray-900/40'
              }`}
            >
              <Users className="h-4 w-4" />
              <span>{t.tabCustomers}</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'settings' ? 'bg-emerald-600 text-white shadow-md' : 'text-gray-400 hover:text-white hover:bg-gray-900/40'
              }`}
            >
              <Settings className="h-4 w-4" />
              <span>{t.tabSettings}</span>
            </button>
          </nav>
        </div>

        <div className="pt-4 border-t border-gray-850 mt-10">
          <button
            onClick={resetAndReinitDatabase}
            className="w-full bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/35 text-[10px] font-bold text-rose-400 rounded-xl py-2.5 flex items-center gap-2 justify-center transition-all cursor-pointer"
          >
            <Database className="h-3.5 w-3.5" />
            <span>{t.formatFirebase}</span>
          </button>
        </div>
      </aside>

      {/* Main Viewport Content */}
      <main className="flex-1 p-6 md:p-10 space-y-8 overflow-x-hidden">
        
        {/* TAB 1: OPERATIONAL & STATS TELEMETRY */}
        {activeTab === 'stats' && (
          <div className="space-y-8 animate-fadeIn">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'الإحصائيات التشغيلية والمالية للمنصة' : 'Analytical Telemetry Matrix'}</span>
            </h2>

            {/* Quick Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div className="bg-[#0c101b] border border-gray-800 p-4.5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'حجم المبيعات الكلي' : 'Digital Volume'}</p>
                  <p className="text-lg font-black text-emerald-400 font-mono mt-1">{formatPrice(totalVolumeUSD)}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <ArrowLeftRight className="h-4.5 w-4.5" />
                </div>
              </div>

              <div className="bg-[#0c101b] border border-gray-800 p-4.5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'الأرباح الكلية المجمعة' : 'Accumulated Profit'}</p>
                  <p className="text-lg font-black text-indigo-400 font-mono mt-1">{formatPrice(totalProfitUSD)}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
                  <Coins className="h-4.5 w-4.5" />
                </div>
              </div>

              <div className="bg-[#0c101b] border border-gray-800 p-4.5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'طلبات بانتظار الشحن' : 'Pending Queue'}</p>
                  <p className="text-lg font-black text-amber-500 font-mono mt-1">{pendingOrders.length}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-500">
                  <Clock className="h-4.5 w-4.5" />
                </div>
              </div>

              <div className="bg-[#0c101b] border border-gray-800 p-4.5 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'العملاء المسجلين' : 'Registered Users'}</p>
                  <p className="text-lg font-black text-teal-400 font-mono mt-1">{usersList.length}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-400">
                  <Users className="h-4.5 w-4.5" />
                </div>
              </div>
            </div>

            {/* Connection and Pool Balance Info */}
            <div className="bg-gray-900 border border-gray-800 p-5 rounded-3xl grid grid-cols-1 md:grid-cols-3 gap-5 items-center">
              <div className="flex items-center gap-3">
                <span className="p-3 bg-indigo-950 text-indigo-400 border border-indigo-900 rounded-2xl shadow">
                  <Sliders className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-[10px] uppercase font-semibold text-gray-500">Oranos API Source Status</p>
                  <p className="text-xs font-black mt-1 text-white">
                    {oranosConfig?.ok ? (locale === 'ar' ? '🟢 متصل ومعتمد' : '🟢 Securely Connected') : (locale === 'ar' ? '🔴 غير متصل' : '🔴 Connection Inactive')}
                  </p>
                </div>
              </div>

              <div>
                <p className="text-[10px] uppercase font-semibold text-gray-500">Masked Security Token</p>
                <p className="text-xs font-mono text-gray-300 mt-1 select-all">{oranosConfig?.maskedToken || 'N/A'}</p>
              </div>

              <div className="p-3 bg-black/40 rounded-2xl border border-gray-850 flex items-center justify-between">
                <div>
                  <span className="text-[9px] uppercase font-bold text-gray-500">{locale === 'ar' ? 'رصيد حزمة الموزع المستقل (أورانوس):' : 'Oranos Reseller Balance:'}</span>
                  {isFetchingProfile ? (
                    <p className="text-xs text-indigo-400 animate-pulse mt-0.5">Fetching live balance...</p>
                  ) : (
                    <p className="text-lg font-black text-emerald-400 font-mono mt-0.5">
                      {liveProfile?.balance !== undefined ? `$${parseFloat(liveProfile.balance).toFixed(2)}` : 'Offline / $0.00'}
                    </p>
                  )}
                </div>
                <button
                  onClick={fetchOranosStatusAndProfile}
                  className="p-1 px-2 hover:bg-gray-800 rounded border border-gray-850 text-gray-500 hover:text-white transition"
                  id="fetch-oranos-profile-refresh-btn"
                >
                  <RefreshCw className="h-3 w-3" />
                </button>
              </div>
            </div>

            {/* Sales Trend Chart */}
            <div className="bg-[#0c101b] border border-gray-800 p-6 rounded-3xl">
              <h3 className="font-bold text-xs text-gray-400 uppercase tracking-wider mb-4">{locale === 'ar' ? 'حركة المبيعات وشحن المحافظ (آخر ٧ أيام)' : 'Operational Volume Trend Matrix (Last 7 Days)'}</h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={getSalesTrend()}>
                    <defs>
                      <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" opacity={0.2} />
                    <XAxis dataKey="day" stroke="#6b7280" fontSize={10} tickLine={false} />
                    <YAxis stroke="#6b7280" fontSize={10} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: '#0a0d16', borderColor: '#1f2937', color: '#fff', fontSize: 11, borderRadius: 12 }} />
                    <Area type="monotone" dataKey="sales" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorSales)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PRODUCTS MANAGER INDEX */}
        {activeTab === 'products' && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <ShoppingBag className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'إدارة كتالوج المنتجات وباقات الشحن' : 'Storefront Product Inventory Manager'}</span>
            </h2>

            <ProductManager
              products={products}
              categories={categories}
              locale={locale}
              showToast={showToast}
              onRefresh={fetchOranosStatusAndProfile}
            />
          </div>
        )}

        {/* TAB 3: AUTOMATED SYNC AND CONFIG DETAILS */}
        {activeTab === 'sync' && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <Sliders className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'إعدادات الاتصال ومزامنة كتالوج أورانوس' : 'Oranos Synchronization Engine Controls'}</span>
            </h2>

            <SyncManager
              locale={locale}
              showToast={showToast}
              syncOranosCatalog={syncOranosCatalog}
              updateOranosConfig={updateOranosConfig}
              getOranosConfig={getOranosConfig}
              onRefreshProducts={fetchOranosStatusAndProfile}
            />
          </div>
        )}

        {/* TAB 4: ORDERS & MANUAL CHARGE ARCHIVE */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-gray-850">
              <h2 className="text-base font-black text-white flex items-center gap-3">
                <FileText className="h-4 w-4 text-emerald-400" />
                <span>{locale === 'ar' ? 'مراجعة طلبات الشحن ورصيد المحافظ' : 'Review live deposit and digital recharges'}</span>
              </h2>

              <select
                value={orderStatusFilter}
                onChange={e => setOrderStatusFilter(e.target.value)}
                className="bg-gray-950 border border-gray-800 text-xs font-bold text-gray-300 rounded-xl px-3 py-1.5 outline-none"
              >
                <option value="all">{locale === 'ar' ? 'جميع الطلبات ومصادرها' : 'All Orders'}</option>
                <option value="pending">{locale === 'ar' ? 'بانتظار المراجعة' : 'Pending Review'}</option>
                <option value="completed">{locale === 'ar' ? 'مكتمل' : 'Completed'}</option>
                <option value="canceled">{locale === 'ar' ? 'ملغي' : 'Canceled'}</option>
              </select>
            </div>

            <div className="relative w-full max-w-md">
              <input
                type="text"
                placeholder={locale === 'ar' ? 'مسح برقم الشحنة، الايدي، أو بريد المشتري...' : 'Search by ID, email, phone or Player ID...'}
                value={orderSearch}
                onChange={e => setOrderSearch(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-[#0c101b] py-2 px-4 pl-10 text-xs text-white placeholder:text-gray-600 focus:outline-none focus:border-emerald-500 font-bold"
              />
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            </div>

            <div className="space-y-4">
              {filteredOrders.length === 0 ? (
                <div className="py-12 text-center border border-gray-800 rounded-2xl bg-gray-950/20">
                  <ShoppingBag className="h-8 w-8 mx-auto text-gray-600 mb-2" />
                  <p className="text-xs text-gray-500">{locale === 'ar' ? 'لم يتم العثور على أي شحنات أو إيصالات للمصادقة.' : 'No checkout items matched current search parameters.'}</p>
                </div>
              ) : (
                filteredOrders.map((order) => {
                  const hasOranosMetaData = order.oranosStatus || order.oranosId;
                  
                  return (
                    <div key={order.id} className="bg-[#0c101b] border border-gray-800 rounded-2xl p-5 space-y-4 shadow-sm hover:border-gray-700 transition">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-850">
                        <div>
                          <span className="text-[10px] bg-indigo-950/40 text-indigo-400 border border-indigo-900/40 font-mono font-bold py-0.5 px-2.5 rounded-lg">
                            STATION ID: {order.id}
                          </span>
                          <div className="text-[11px] text-gray-400 font-bold mt-2 flex items-center gap-1.5">
                            <span>{order.userName || 'Guest'}</span>
                            <span>•</span>
                            <span className="font-mono">{order.userEmail}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${getOrderStatusBadge(order.status)}`}>
                            {order.status.toUpperCase()}
                          </span>
                          <span className="text-[10px] text-gray-500 font-mono">{new Date(order.timestamp).toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                        <div className="space-y-1.5">
                          <p className="text-[11.5px] font-semibold text-gray-400">Order Items & Metadata:</p>
                          {order.items.map((it, idx) => (
                            <div key={idx} className="text-xs font-bold text-white flex items-center gap-1.5">
                              <span className="text-emerald-400">{it.quantity}x</span>
                              <span>{locale === 'ar' ? it.productName_ar : it.productName_en}</span>
                            </div>
                          ))}

                          {order.playerId && (
                            <div className="p-2 py-1 bg-gray-900/40 border border-gray-850 rounded-lg text-xs font-mono text-emerald-400 inline-block mt-2">
                              Target Player ID: <strong>{order.playerId}</strong>
                            </div>
                          )}

                          {hasOranosMetaData && (
                            <div className="p-2.5 bg-indigo-950/25 border border-indigo-900/40 rounded-xl text-[10.5px] font-mono leading-relaxed mt-2.5 space-y-1">
                              <p className="text-indigo-400 font-bold">Oranos Automated Re-charge Log:</p>
                              {order.oranosId && <p className="text-gray-300">Oranos Transaction ID: <span className="font-bold text-white select-all">{order.oranosId}</span></p>}
                              {order.oranosStatus && <p className="text-gray-300">Status Check Payload: <span className="text-emerald-400 font-black uppercase text-[11px]">{order.oranosStatus}</span></p>}
                            </div>
                          )}

                          {order.additionalNotes && (
                            <div className="p-2 rounded-xl bg-orange-950/20 text-orange-400 border border-orange-900/30 text-[10.5px] font-semibold mt-2 max-w-md">
                              Reference / Remittance Note: {order.additionalNotes}
                            </div>
                          )}

                          {(order as any).receiptImage && (
                            <div className="mt-2 text-xs">
                              <p className="text-gray-500 font-semibold mb-1">Receipt Attachment:</p>
                              <a href={(order as any).receiptImage} target="_blank" rel="noreferrer" className="inline-block border border-gray-850 p-1 bg-black/40 hover:border-gray-700 rounded-lg">
                                <img src={(order as any).receiptImage} alt="Receipt" className="h-16 w-16 object-cover rounded" />
                              </a>
                            </div>
                          )}
                        </div>

                        <div className="text-right flex flex-col sm:items-end gap-3 self-end sm:self-center">
                          <div className="text-sm font-black text-emerald-400 font-mono">
                            Total Cost Basis: {formatPrice(order.total)}
                          </div>

                          {!['completed', 'canceled'].includes(order.status) && (
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleCancelOrder(order)}
                                className="px-3 py-1.5 bg-gray-950 hover:bg-rose-950/10 text-gray-400 hover:text-rose-400 border border-gray-850 rounded-lg text-xs font-bold transition-colors"
                              >
                                Decline
                              </button>
                              <button
                                onClick={() => handleApproveOrder(order)}
                                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-black transition-all flex items-center gap-1"
                              >
                                <Check className="h-3.5 w-3.5" />
                                <span>Approve Re-charge</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* TAB 5: REGISTERED CUSTOMER PROFILES */}
        {activeTab === 'customers' && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <Users className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'حسابات ومحافظ الزبائن المسجلين' : 'Platform Register Customer Wallets'}</span>
            </h2>

            <div className="relative w-full max-w-md">
              <input
                type="text"
                placeholder={locale === 'ar' ? 'البحث عن عميل بالبريد، الاسم، الهاتف...' : 'Search customer by name, email, uid or phone...'}
                value={customerSearch}
                onChange={e => setCustomerSearch(e.target.value)}
                className="w-full rounded-xl border border-gray-800 bg-[#0c101b] py-2 px-4 pl-10 text-xs text-white placeholder:text-gray-600 focus:outline-none focus:border-emerald-500 font-bold"
              />
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            </div>

            {/* Customers table */}
            <div className="border border-gray-800 bg-gray-900/40 rounded-xl overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-950/60 text-[11px] uppercase tracking-wider text-gray-400 font-bold border-b border-gray-800">
                      <th className="py-3 px-4">Customer Details</th>
                      <th className="py-3 px-4">Phone Number</th>
                      <th className="py-3 px-4 text-center">Wallet Balance</th>
                      <th className="py-3 px-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800 text-xs text-gray-300">
                    {filteredCustomers.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-8 text-center text-gray-500">
                          {locale === 'ar' ? 'لم يتم العثور على أي حساب مسجل بمواصفات البحث' : 'No registered users matched search filters.'}
                        </td>
                      </tr>
                    ) : (
                      filteredCustomers.map((c) => (
                        <tr key={c.uid} className="hover:bg-gray-950/30 transition-colors">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className="h-8 w-8 rounded-full bg-emerald-950 border border-emerald-900 text-emerald-400 flex items-center justify-center font-bold">
                                {c.displayName ? c.displayName.substring(0,2).toUpperCase() : <User className="h-4 w-4" />}
                              </div>
                              <div className="flex flex-col">
                                <span className="font-bold text-white">{c.displayName || 'No name provided'}</span>
                                <span className="text-[10px] text-gray-500 font-mono select-all lowercase">{c.email}</span>
                              </div>
                            </div>
                          </td>

                          <td className="py-3 px-4 font-mono text-gray-300">
                            {c.phone || <span className="text-gray-600 text-[10px]">Unspecified</span>}
                          </td>

                          <td className="py-3 px-4 text-center font-mono font-black text-emerald-400">
                            ${(c.balance !== undefined ? c.balance : 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>

                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => {
                                setSelectedCustomer(c);
                                setAdjustmentType('credit');
                              }}
                              className="py-1 px-3.5 bg-indigo-950 text-indigo-400 hover:bg-indigo-600 hover:text-white border border-indigo-900 rounded-lg text-xs transition duration font-semibold select-none"
                              id={`adjust-balance-${c.uid}`}
                            >
                              {locale === 'ar' ? 'تعديل الرصيد' : 'Adjust Wallet'}
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: SETTINGS & ADMINISTRATIVE ACCESS */}
        {activeTab === 'settings' && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-base font-black text-white flex items-center gap-2 pb-2 border-b border-gray-850">
              <UserPlus className="h-4 w-4 text-emerald-400" />
              <span>{locale === 'ar' ? 'إدارة مسؤولي السيادة ومعالجة البيانات' : 'Platform Security Administrators & Resets'}</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              
              {/* Add admin accounts card */}
              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-3xl space-y-4">
                <h3 className="font-bold text-xs uppercase text-emerald-400">{locale === 'ar' ? 'تسجيل مسؤول حماية هاتف/مبيعات جديد' : 'Enroll New Administrator'}</h3>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1.5">Google Email Account:</label>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      placeholder="e.g. akiocodex1@gmail.com"
                      value={newAdminEmail}
                      onChange={e => setNewAdminEmail(e.target.value)}
                      className="flex-1 bg-gray-950 border border-gray-800 rounded-2xl py-2 px-3 text-xs text-white placeholder:text-gray-600 focus:outline-none focus:border-emerald-500 font-mono font-bold"
                    />
                    <button
                      onClick={handleAddAdmin}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl flex items-center gap-1"
                    >
                      <Plus className="h-4 w-4" />
                      <span>Grant</span>
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-indigo-950/20 text-indigo-400 border border-indigo-900/40 rounded-xl leading-relaxed text-[10px] font-semibold">
                  Note: Enroll extra Google Account users so they can approve/reject manual recharges and manage products.
                </div>
              </div>

              {/* Emails Active list */}
              <div className="bg-[#0c101b] border border-gray-800 p-5 rounded-3xl space-y-4">
                <h3 className="font-bold text-xs uppercase text-emerald-400">{locale === 'ar' ? 'قائمة المسؤولين النشطين بالمنصة' : 'Active Administrators List'}</h3>
                
                <div className="space-y-2">
                  {activeAdmins.map((adm: string, idx: number) => (
                    <div key={idx} className="p-2.5 bg-gray-950 border border-gray-850 rounded-xl flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-2 text-gray-300">
                        <Mail className="h-4 w-4 text-emerald-500" />
                        <span className="font-bold">{adm}</span>
                      </div>

                      <button
                        onClick={() => handleRemoveAdmin(adm)}
                        className="p-1 hover:text-rose-500 text-gray-500 transition-colors"
                        title="Remove Administrator Access"
                      >
                        <Trash2 className="h-4.5 w-4.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

      </main>

      {/* Adjust balance Modal Popup */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-gray-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form 
            onSubmit={handleAdjustBalanceSubmit} 
            className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-md overflow-hidden p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-gray-800 pb-3">
              <h3 className="font-bold text-white text-sm">Wallet Balance Adjuster</h3>
              <button 
                type="button" 
                onClick={() => setSelectedCustomer(null)}
                className="text-gray-400 hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="p-3 bg-[#0c101b] rounded-xl border border-gray-800 flex flex-col gap-0.5 text-xs">
              <span className="font-semibold text-gray-500">Customer:</span>
              <strong className="text-white text-sm">{selectedCustomer.displayName || 'No Name'}</strong>
              <span className="font-mono text-[10px] text-gray-400 mt-1">Wallet Current Balance: ${Number(selectedCustomer.balance || 0).toFixed(2)}</span>
            </div>

            <div className="space-y-2">
              <label className="block text-xs text-gray-400 font-bold">Adjustment Operation:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setAdjustmentType('credit')}
                  className={`py-2 px-3 text-xs font-bold rounded-lg border transition ${
                    adjustmentType === 'credit' 
                      ? 'bg-emerald-600 border-emerald-500 text-white' 
                      : 'bg-gray-950 border-gray-800 text-gray-400'
                  }`}
                >
                  🟢 Credit (+ Add Fund)
                </button>
                <button
                  type="button"
                  onClick={() => setAdjustmentType('debit')}
                  className={`py-2 px-3 text-xs font-bold rounded-lg border transition ${
                    adjustmentType === 'debit' 
                      ? 'bg-rose-950/40 border-rose-900 text-rose-400' 
                      : 'bg-gray-950 border-gray-800 text-gray-400'
                  }`}
                >
                  🔴 Debit (- Deduct Fund)
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="block text-xs text-gray-400 font-bold">Adjusting Amount (USD):</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-mono">$</span>
                <input
                  type="number"
                  step="0.01"
                  required
                  min="0.01"
                  value={balanceDelta || ''}
                  onChange={(e) => setBalanceDelta(parseFloat(e.target.value) || 0)}
                  className="w-full pl-7 pr-12 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 rounded-xl text-sm font-semibold font-mono text-white"
                  placeholder="0.00"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-gray-500 font-mono">USD</span>
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-2 border-t border-gray-800">
              <button
                type="button"
                onClick={() => setSelectedCustomer(null)}
                className="py-1.5 px-3 bg-gray-950 hover:bg-gray-850 text-gray-400 rounded-lg text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isAdjustingBalance}
                className="py-1.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow disabled:opacity-50"
              >
                {isAdjustingBalance ? 'Processing adjustment...' : 'Confirm Balance Adjustment'}
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};

export default Admin;
