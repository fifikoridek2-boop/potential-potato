import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  ArrowUpRight, 
  Send, 
  Phone, 
  Hash, 
  BadgeCheck, 
  Coins, 
  Smartphone, 
  CreditCard,
  QrCode,
  CheckCircle2,
  AlertCircle,
  Camera
} from 'lucide-react';
import { collection, addDoc, doc, setDoc } from 'firebase/firestore';
import { db } from '../services/firebase';

type PaymentChannel = 'syriatel' | 'cham' | 'vodafone' | 'usdt';

export const BalanceCharge: React.FC = () => {
  const { locale, user, formatPrice, showToast, navigate } = useStore();
  const [channel, setChannel] = useState<PaymentChannel>('syriatel');
  const [amount, setAmount] = useState<string>('');
  const [senderAccount, setSenderAccount] = useState<string>('');
  const [transactionId, setTransactionId] = useState<string>('');
  const [receiptImage, setReceiptImage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Exchange rates for conversion reference in instructions
  const exchangeRates = {
    SYP: 14000,
    EGP: 48,
    USD: 1
  };

  const channelDetails = {
    syriatel: {
      title_ar: 'سيريتل كاش (Syriatel Cash)',
      title_en: 'Syriatel Cash',
      number: '0995123456',
      instructions_ar: 'قم بتحويل رصيد الشحن إلى الرقم المرفق، ثم املأ البيانات بالأسفل مع إضافة لقطة أو رقم العملية المرجعي للمطابقة الفورية.',
      instructions_en: 'Transfer the funds to the Syriatel number above, then supply your registration details and transaction parameters below.',
      currency: 'SYP'
    },
    cham: {
      title_ar: 'شام كاش (Cham Cash)',
      title_en: 'Cham Cash',
      number: '0983987654',
      instructions_ar: 'أرسل المبلغ المطلوب للحساب المدون أعلاه، متبوعاً بكتابة رقم محفظة الإرسال وهوية التحويل بالأسفل لتأكيد الأرصدة.',
      instructions_en: 'Send the amount to the Cham Cash number above, then document your request by populating the sender details below.',
      currency: 'SYP'
    },
    vodafone: {
      title_ar: 'فودافون كاش (Vodafone Cash)',
      title_en: 'Vodafone Cash',
      number: '0101567890',
      instructions_ar: 'حول قيمة الرصيد لمحفظة الإرسال، ثم زود الإدارة برقم هاتفك الكاش ومعرف العملية لتأكيد الحساب ومراجعة السيرفر.',
      instructions_en: 'Transfer via Vodafone Cash to our merchant wallet, then supply the sender wallet number and Tx ID for immediate validation.',
      currency: 'EGP'
    },
    usdt: {
      title_ar: 'تيثر USDT (TRC-20)',
      title_en: 'USDT (TRC-20)',
      number: 'TX8uTjFpS8xK7yWmqZ9pE29cZ7wArf3D',
      instructions_ar: 'أرسل العملات الرقمية عبر شبكة TRON (TRC20) إلى العنوان المنسوخ بالأسفل، وتأكد من كتابة الـ TXID بشكل صحيح.',
      instructions_en: 'Send digital Tether (USDT) via TRON network (TRC20) to the address above. Ensure the TXID hash is accurately copied.',
      currency: 'USD'
    }
  };

  const labels = {
    title: locale === 'ar' ? 'طلب إضافة رصيد الحساب' : 'Deposit Balance Request',
    sub: locale === 'ar' ? 'اشحن رصيد محفظتك الرقمية يدوياً عبر بوابات التحويل المحلية لاستخدامه الفوري لشراء الألعاب والبطاقات.' : 'Fund your digital wallet account manually with local transactions to purchase instant game voucher codes.',
    chooseChannel: locale === 'ar' ? '١. اختر قناة الإيداع والتحويل' : '1. Select Transfer Channel',
    instructionTitle: locale === 'ar' ? '٢. تعليمات الإرسال المباشر' : '2. Direct Sending Instructions',
    inputTitle: locale === 'ar' ? '٣. سجل تفاصيل التحويل المالي' : '3. Enter Transfer Parameters',
    copyBtn: locale === 'ar' ? 'نسخ العنوان' : 'Copy Address',
    copiedText: locale === 'ar' ? 'تم نسخ العنوان بنجاح!' : 'Copied successfully!',
    amountLabel: locale === 'ar' ? 'المبلغ المراد شحنه' : 'Requested Deposit Amount',
    senderLabel: locale === 'ar' ? 'رقم الهاتف المرسل أو رقم المحفظة' : 'Sender Phone / Wallet Number',
    txLabel: locale === 'ar' ? 'رقم أو هوية العملية (Transaction ID / Hash)' : 'Transaction ID / Hash Ref',
    submitBtn: locale === 'ar' ? 'إرسال طلب التحقق للإدارة' : 'Submit Deposit Proof',
    submitting: locale === 'ar' ? 'جاري إرسال البيانات للتأكيدات...' : 'Submitting verification proof...',
    successTitle: locale === 'ar' ? 'تم إرسال طلب الشحن بنجاح!' : 'Deposit Request Submitted!',
    successSub: locale === 'ar' ? 'جاري التحقق من السيرفر وبنك الإدارات. سيتم تفعيل وإضافة رصيدك خلال دقائق قليلة.' : 'We are validating your transfer parameters. Balance will be updated in your digital profile momentarily.',
    amountPlaceholder: (curr: string) => locale === 'ar' ? `ادخل المبلغ بـ ${curr === 'SYP' ? 'الليرة السورية' : curr === 'EGP' ? 'الجنيه المصري' : 'الدولار'}` : `Enter amount in ${curr}`,
    successHomeBtn: locale === 'ar' ? 'الذهاب للمحفظة لمتابعة الرصيد' : 'Go to Wallet to view balance'
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast(labels.copiedText, 'success');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !senderAccount || !transactionId) {
      showToast(locale === 'ar' ? 'يرجى ملء جميع الخانات الإلزامية' : 'Please fill all mandatory fields', 'error');
      return;
    }

    if (isNaN(Number(amount)) || Number(amount) <= 0) {
      showToast(locale === 'ar' ? 'المبلغ يجب أن يكون رقماً صالحاً أكبر من الصفر' : 'Please insert a valid currency amount', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const activeChannel = channelDetails[channel];
      const usdEquivalent = Number(amount) / exchangeRates[activeChannel.currency as keyof typeof exchangeRates];

      // Store in firestore 'orders' with specific product representation of recharging
      const orderId = `DEP-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;

      const depositOrderPayload = {
        id: orderId,
        userId: user?.uid || 'guest_user',
        userName: user?.name,
        userPhone: senderAccount || user?.phone || '',
        items: [
          {
            product: {
              id: `charge_${channel}_${Date.now()}`,
              name_en: `Wallet Recharge via ${activeChannel.title_en}`,
              name_ar: `طلب شحن محفظة - ${activeChannel.title_ar}`,
              price: usdEquivalent,
              coverImage: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=150&q=80',
              description_ar: `إيداع مالي مرسَل من المحفظة/الرقم: ${senderAccount} ومعرف العملية: ${transactionId}`,
              description_en: `Financial deposit sent from wallet/no: ${senderAccount} with TxRef: ${transactionId}`,
              status: 'in_stock',
              rating: 5,
              reviewsCount: 0,
              categoryId: 'charges'
            },
            quantity: 1,
            selectedSize: senderAccount, // Use size slot for sender phone
            selectedType: transactionId  // Use type slot for Tx ID
          }
        ],
        total: usdEquivalent,
        status: 'pending', 
        timestamp: new Date().toISOString(),
        trackingSteps: [
          { status: 'pending', timestamp: new Date().toISOString(), completed: true }
        ],
        receiptImage: receiptImage || null,
        additionalNotes: `Gateway: ${activeChannel.title_en}, Currency: ${activeChannel.currency}`
      };

      await setDoc(doc(db, 'orders', orderId), depositOrderPayload);
      setIsSuccess(true);
      showToast(locale === 'ar' ? 'تم قيد الطلب وبانتظار الموافقة' : 'Deposit registration success', 'success');
    } catch (err) {
      console.error("Failed to register deposit request in firebase", err);
      showToast(locale === 'ar' ? 'فشل حجز التحويل بمخازن السيرفر' : 'Database filing exception', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="max-w-md mx-auto py-12 px-4 text-center space-y-6" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
        <div className="mx-auto w-16 h-16 rounded-full bg-emerald-950/50 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
          <CheckCircle2 className="h-10 w-10 animate-bounce" />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl sm:text-2xl font-black text-white">{labels.successTitle}</h2>
          <p className="text-xs text-gray-400 leading-relaxed max-w-sm mx-auto">{labels.successSub}</p>
        </div>
        <div className="pt-4">
          <button
            onClick={() => navigate('order-history')}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-5 rounded-xl transition-all cursor-pointer shadow-lg shadow-emerald-950/20 text-sm"
          >
            {labels.successHomeBtn}
          </button>
        </div>
      </div>
    );
  }

  const activeChannel = channelDetails[channel];

  return (
    <div className="max-w-2xl mx-auto py-6 px-4 space-y-8" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
      
      {/* Title block */}
      <div className="space-y-1 text-center sm:text-start" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
        <h1 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2 justify-center sm:justify-start">
          <Coins className="h-6 w-6 text-emerald-400" />
          <span>{labels.title}</span>
        </h1>
        <p className="text-xs text-gray-400 leading-relaxed">{labels.sub}</p>
      </div>

      {/* Grid selector - step 1 */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest">{labels.chooseChannel}</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {(['syriatel', 'cham', 'vodafone', 'usdt'] as PaymentChannel[]).map((ch) => {
            const isSelected = channel === ch;
            return (
              <button
                key={ch}
                type="button"
                onClick={() => {
                  setChannel(ch);
                  setAmount('');
                }}
                className={`flex flex-col items-center justify-center p-4 rounded-2xl border transition-all text-center gap-2 cursor-pointer ${
                  isSelected 
                    ? 'border-emerald-500 bg-emerald-950/20 text-white shadow-md' 
                    : 'border-gray-800 bg-gray-950/40 text-gray-400 hover:bg-gray-950 hover:text-white'
                }`}
              >
                {ch === 'usdt' ? <Coins className="h-5 w-5 text-emerald-400" /> : <Smartphone className="h-5 w-5 text-emerald-400" />}
                <span className="text-[11px] font-bold">{locale === 'ar' ? channelDetails[ch].title_ar : channelDetails[ch].title_en}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Copy layout - step 2 */}
      <div className="bg-[#0c101b] border border-gray-800 rounded-3xl p-5 sm:p-6 space-y-4">
        <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest flex items-center gap-2">
          <QrCode className="h-4 w-4 text-emerald-400" />
          <span>{labels.instructionTitle}</span>
        </h3>

        <div className="space-y-4">
          <div className="p-4 bg-gray-950/60 border border-gray-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="block text-[10px] text-gray-500 uppercase tracking-widest">
                {channel === 'usdt' ? (locale === 'ar' ? 'عنوان محفظة الإرسال TRC-20' : 'USDT TRC20 Address') : (locale === 'ar' ? 'رقم محفظة الاستلام' : 'Merchant Wallet Number')}
              </span>
              <span className="font-mono text-sm sm:text-base font-black text-gray-100 block break-all select-all">
                {activeChannel.number}
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(activeChannel.number)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 px-4 rounded-xl transition-all cursor-pointer shrink-0"
            >
              {labels.copyBtn}
            </button>
          </div>

          <div className="flex gap-2.5 items-start text-xs text-gray-400 leading-relaxed bg-[#0e1628]/40 border border-emerald-500/5 p-3 rounded-xl">
            <AlertCircle className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
            <p>{locale === 'ar' ? activeChannel.instructions_ar : activeChannel.instructions_en}</p>
          </div>
        </div>
      </div>

      {/* Form Submission - step 3 */}
      <form onSubmit={handleSubmit} className="bg-[#0c101b] border border-gray-800 rounded-3xl p-5 sm:p-6 space-y-5">
        <h3 className="text-xs font-bold text-gray-300 uppercase tracking-widest flex items-center gap-2">
          <Send className="h-4 w-4 text-emerald-400" />
          <span>{labels.inputTitle}</span>
        </h3>

        <div className="space-y-4">
          {/* Amount input */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider">
              {labels.amountLabel} ({activeChannel.currency})
            </label>
            <input
              type="text"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={labels.amountPlaceholder(activeChannel.currency)}
              className="w-full bg-gray-950 border border-gray-800 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-emerald-500 select-all font-mono"
            />
          </div>

          {/* Sender account */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <Phone className="h-3 w-3" />
              <span>{labels.senderLabel}</span>
            </label>
            <input
              type="text"
              required
              value={senderAccount}
              onChange={(e) => setSenderAccount(e.target.value)}
              placeholder={locale === 'ar' ? 'ادخل الرقم الذي يتم الإرسال منه للتوثيق' : 'Enter sender wallet address or phone'}
              className="w-full bg-gray-950 border border-gray-800 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          {/* Transaction ID */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <Hash className="h-3 w-3" />
              <span>{labels.txLabel}</span>
            </label>
            <input
              type="text"
              required
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder={locale === 'ar' ? 'ادخل معرف التحويل أو رقم العملية المرجعي' : 'Insert transaction ID ref or Tx hash'}
              className="w-full bg-gray-950 border border-gray-800 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>
          {/* Receipt Image */}
          <div className="space-y-2">
            <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <Camera className="h-3 w-3" />
              <span>{locale === 'ar' ? 'صورة إيصال التحويل' : 'Transfer Receipt Image'}</span>
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    setReceiptImage(reader.result as string);
                  };
                  reader.readAsDataURL(file);
                }
              }}
              className="w-full bg-gray-950 border border-gray-800 rounded-xl py-2 px-4 text-white text-xs focus:outline-none focus:border-emerald-500 font-mono file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-emerald-500/10 file:text-emerald-400 hover:file:bg-emerald-500/20"
            />
          </div>
        </div>

        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-800 text-white font-bold py-3 px-5 rounded-xl transition-all cursor-pointer shadow-lg shadow-emerald-950/20 text-xs flex items-center justify-center gap-2"
          >
            <BadgeCheck className="h-4 w-4" />
            <span>{isSubmitting ? labels.submitting : labels.submitBtn}</span>
          </button>
        </div>
      </form>

    </div>
  );
};

export default BalanceCharge;
