import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from '../components/ProductCard';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Zap, 
  Coins, 
  Gamepad2, 
  Flame, 
  Smartphone, 
  CreditCard,
  TrendingUp, 
  ShieldCheck, 
  Lock 
} from 'lucide-react';

export const Home: React.FC = () => {
  const { locale, products, categories, navigate, formatPrice, isDbLoading } = useStore();
  const [selectedFilterCategory, setSelectedFilterCategory] = useState<string>('all');
  const [activeSlide, setActiveSlide] = useState(0);

  // High quality landscape banner images (Aspect ratio: 16:9 like YouTube thumbnail)
  const bannerImages = [
    'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1280&h=720&q=80',
    'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1280&h=720&q=80',
    'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&w=1280&h=720&q=80'
  ];

  // Automatic slide changing timer
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % bannerImages.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [bannerImages.length]);

  // Mock categories filter cards mapping to realistic digital assets
  const mockCategories = [
    {
      id: 'all',
      name_ar: 'الكل',
      name_en: 'All services',
      icon: Flame,
      color: 'text-orange-400 bg-orange-500/10'
    },
    {
      id: 'games',
      name_ar: 'PUBG & الألعاب',
      name_en: 'PUBG & Game UC',
      icon: Gamepad2,
      color: 'text-emerald-400 bg-emerald-500/10'
    },
    {
      id: 'local_cash',
      name_ar: 'سيريتل وفودافون كاش',
      name_en: 'Syriatel & Vodafone Cash',
      icon: Smartphone,
      color: 'text-amber-400 bg-amber-500/10'
    },
    {
      id: 'crypto',
      name_ar: 'USDT والعملات',
      name_en: 'USDT Tether Topups',
      icon: Coins,
      color: 'text-teal-400 bg-teal-500/10'
    },
    {
      id: 'gift_cards',
      name_ar: 'بطاقات الهدايا',
      name_en: 'Digital Codes & Packs',
      icon: CreditCard,
      color: 'text-indigo-400 bg-indigo-500/10'
    }
  ];

  // Logic to dynamically filter products based on user selecting mock tags
  const getFilteredDigitalProducts = () => {
    if (selectedFilterCategory === 'all') return products;

    // Filter by digital tags
    return products.filter(p => {
      const prodId = p.id?.toLowerCase() || '';
      const catId = p.categoryId?.toLowerCase() || '';
      const name = (p.name_ar + p.name_en).toLowerCase();

      if (selectedFilterCategory === 'games') {
        return prodId.includes('pubg') || prodId.includes('game') || catId.includes('play') || name.includes('pubg') || name.includes('فري فاير') || name.includes('جواهر');
      }
      if (selectedFilterCategory === 'local_cash') {
        return prodId.includes('syriatel') || prodId.includes('cash') || name.includes('كاش') || name.includes('سيريتل');
      }
      if (selectedFilterCategory === 'crypto') {
        return prodId.includes('usdt') || prodId.includes('tether') || name.includes('usdt') || name.includes('عملة');
      }
      if (selectedFilterCategory === 'gift_cards') {
        return !prodId.includes('pubg') && !prodId.includes('usdt') && !name.includes('كاش') && !prodId.includes('charge_');
      }
      return p.categoryId === selectedFilterCategory;
    });
  };

  const digitalProducts = getFilteredDigitalProducts().filter(p => !p.id?.startsWith('charge_'));

  return (
    <div className="space-y-8 pb-12">
      
      {/* 1. HORIZONTAL BANNER / SLIDER - PURE PHOTO GALLERY (ASPECT-VIDEO / 16:9 / NO BUTTONS OR CONTROLS) */}
      <section className="relative overflow-hidden rounded-3xl bg-zinc-950 border border-zinc-800 shadow-2xl aspect-video w-full max-h-[420px] mx-auto">
        <AnimatePresence initial={false}>
          <motion.img
            key={activeSlide}
            src={bannerImages[activeSlide]}
            alt="Qadi Tech Promotion"
            initial={{ x: '-100%', opacity: 0.8 }}
            animate={{ x: '0%', opacity: 1 }}
            exit={{ x: '100%', opacity: 0.8 }}
            transition={{ duration: 0.8, ease: 'easeInOut' }}
            className="absolute inset-0 w-full h-full object-cover"
          />
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/10 pointer-events-none" />
      </section>

      {/* 3. MOCK CATEGORIES GRID */}
      <section className="space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-gray-900">
          <h2 className="text-sm font-black uppercase tracking-wider text-emerald-400">
            {locale === 'ar' ? 'فئات الشحن والخدمات الرقمية' : 'Digital Charging Categories'}
          </h2>
          <span className="text-[10px] font-bold text-gray-500">
            {locale === 'ar' ? 'اختر تصنيف للتصفية' : 'Select a classification to filter'}
          </span>
        </div>

        <div className="grid grid-cols-2 xs:grid-cols-3 md:grid-cols-5 gap-3">
          {mockCategories.map((mockCat) => {
            const IconComp = mockCat.icon;
            const isSelected = selectedFilterCategory === mockCat.id;
            return (
              <div
                key={mockCat.id}
                onClick={() => setSelectedFilterCategory(mockCat.id)}
                className={`group cursor-pointer p-4 rounded-2xl border transition-all duration-350 flex flex-col items-center justify-center text-center gap-3 active:scale-95 ${
                  isSelected 
                    ? 'border-emerald-500 bg-[#0e1d1f] shadow-lg shadow-emerald-950/20' 
                    : 'border-gray-800 bg-[#05080e] hover:border-gray-700 hover:bg-gray-900'
                }`}
              >
                <div className={`h-10 w-10 rounded-xl flex items-center justify-center transform group-hover:scale-105 transition-transform ${mockCat.color}`}>
                  <IconComp className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-xs text-gray-200">
                    {locale === 'ar' ? mockCat.name_ar : mockCat.name_en}
                  </h3>
                  <p className="text-[9px] text-gray-500 font-bold mt-1">
                    {locale === 'ar' ? 'تصفح العروض' : 'View Stock'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. ACTIVE DIGITAL CARDS CATALOG */}
      <section id="digital-recharge-section" className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-black text-white" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
              {locale === 'ar' ? 'البطاقات الرقمية المتوفرة للشراء' : 'Available Charging Bundles'}
            </h2>
            <p className="text-xs text-gray-500 mt-0.5" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
              {locale === 'ar' ? 'اختر البطاقة وسيتم استلام الكود والتعليمات في محفظتك فور الدفع' : 'Deliverable items immediately with automated redemption keys'}
            </p>
          </div>
          <div className="text-[10px] bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-extrabold py-1 px-3 rounded-full shrink-0">
            {digitalProducts.length} {locale === 'ar' ? 'عرض متوفر حالياً' : 'deals listed'}
          </div>
        </div>

        {isDbLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
            {[...Array(4)].map((_, idx) => (
              <div key={idx} className="h-48 rounded-2xl bg-gray-900 border border-gray-850" />
            ))}
          </div>
        ) : digitalProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {digitalProducts.map((prod) => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        ) : (
          <div className="py-16 text-center border border-dashed border-gray-800 rounded-3xl bg-gray-950/20">
            <Coins className="h-8 w-8 mx-auto mb-2 text-gray-600 stroke-[1.5]" />
            <p className="text-xs font-bold text-gray-500">
              {locale === 'ar' ? 'لا يوجد شدات أو بطاقات مسجلة في هذا التصنيف حالياً.' : 'No digital credit items in this tag yet.'}
            </p>
          </div>
        )}
      </section>

      {/* 5. USER PROTECTION & SECURITY SECTORS */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-[#05080e]/60 border border-gray-800 rounded-2xl p-6">
        <div className="flex gap-3.5 items-start">
          <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 shrink-0">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-gray-200">
              {locale === 'ar' ? 'أمان وضمان كامل ١٠٠٪' : 'Guaranteed Client Protection'}
            </h4>
            <p className="text-[11px] text-gray-500 leading-relaxed mt-1 font-semibold">
              {locale === 'ar' ? 'منصة قاضي تيك معتمدة ومؤمنة بالكامل لحماية عمليات الشحن والدفع الخاصة بك.' : 'All wallet top-ups are cryptographically logged with instant dispute resolves.'}
            </p>
          </div>
        </div>

        <div className="flex gap-3.5 items-start">
          <div className="p-2.5 rounded-xl bg-orange-500/10 text-orange-400 shrink-0">
            <TrendingUp className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-gray-200">
              {locale === 'ar' ? 'أفضل أسعار صرف بالسوق اللبناني والسوري' : 'Top Exchange Value Rates'}
            </h4>
            <p className="text-[11px] text-gray-500 leading-relaxed mt-1 font-semibold">
              {locale === 'ar' ? 'نوفر سعر صرف عادل وتنافسي لليرة السورية والجنيه المصري للشحن في ثوانٍ معدودة.' : 'Continuous monitoring ensures you get the absolute best price index.'}
            </p>
          </div>
        </div>

        <div className="flex gap-3.5 items-start">
          <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-400 shrink-0">
            <Lock className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-xs text-gray-200">
              {locale === 'ar' ? 'تشفير ومحاسبة تلقائية' : 'Decentralized Accounting Engine'}
            </h4>
            <p className="text-[11px] text-gray-500 leading-relaxed mt-1 font-semibold">
              {locale === 'ar' ? 'كل الرموز السرية ومفاتيح الاسترداد يتم استردادها وتسجيلها في حساب محفظتك الرقمية.' : 'Your billing keys are secure inside your local sandbox account ledger.'}
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
export default Home;
