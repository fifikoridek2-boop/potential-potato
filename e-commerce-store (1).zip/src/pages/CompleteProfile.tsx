import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { UserProfile } from '../types';
import { ShieldCheck, User, Phone, AlertTriangle } from 'lucide-react';

export const CompleteProfile: React.FC = () => {
  const { locale, user, updateProfile, navigate, showToast } = useStore();

  const [formData, setFormData] = useState<UserProfile>({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    avatarUrl: user?.avatarUrl || ''
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const translations = {
    title: locale === 'ar' ? 'إكمال بيانات حسابك' : 'Complete Profile Setup',
    sub: locale === 'ar' ? 'يرجى تقديم بيانات الاتصال الصحيحة لضمان التواصل.' : 'Provide accurate details for instant deliveries.',
    nameLabel: locale === 'ar' ? 'الاسم الكامل' : 'Full Name',
    phoneLabel: locale === 'ar' ? 'رقم الهاتف (للتواصل)' : 'Phone Number',
    phonePlaceholder: locale === 'ar' ? 'مثال: 0501234567' : 'e.g. 0501234567',
    saveBtn: locale === 'ar' ? 'حفظ البيانات والمتابعة' : 'Save Details & Continue',
    requiredErr: locale === 'ar' ? 'هذا الحقل مطلوب' : 'This field is required',
    phoneErr: locale === 'ar' ? 'يجب إدخال رقم هاتف صالح (على الأقل 9 أرقام)' : 'Enter a valid phone number (at least 9 digits)',
    certified: locale === 'ar' ? 'يتم حفظ بياناتك محلياً ومشفرة' : 'Your details are stored securely.'
  };

  // Sync with context if updated elsewhere
  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        name: prev.name || user.name || '',
        email: prev.email || user.email || '',
        phone: prev.phone || user.phone || '',
        avatarUrl: prev.avatarUrl || user.avatarUrl || ''
      }));
    }
  }, [user]);

  // Redirect to login if user is not authenticated with a friendly grace period
  useEffect(() => {
    const handleCheck = setTimeout(() => {
      if (!user) {
        showToast(locale === 'ar' ? 'يرجى تسجيل الدخول أولاً للوصول لصفحة إكمال البيانات.' : 'Please sign in first to access the profile setup.', 'error');
        navigate('login');
      }
    }, 400);
    return () => clearTimeout(handleCheck);
  }, [user, navigate, locale, showToast]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error
    if (errors[name]) {
      setErrors(prev => {
        const updated = { ...prev };
        delete updated[name];
        return updated;
      });
    }
  };

  const validateForm = () => {
    const tempErrors: { [key: string]: string } = {};

    if (!formData.name.trim()) tempErrors.name = translations.requiredErr;
    
    const phoneTrimmed = formData.phone?.trim() || '';
    if (!phoneTrimmed) {
      tempErrors.phone = translations.requiredErr;
    } else if (phoneTrimmed.length < 9) {
      tempErrors.phone = translations.phoneErr;
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      updateProfile(formData);
      showToast(
        locale === 'ar'
          ? 'تم حفظ وتأكيد بيانات حسابك!'
          : 'Profile details updated successfully!',
        'success'
      );
      
      // Navigate to home as requested by user
      navigate('home');
    } else {
      // scroll to error
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="bg-[#080c14] rounded-3xl border border-gray-800 p-6 sm:p-10 shadow-xl space-y-8" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
        
        {/* Header information */}
        <div className="text-center md:text-start" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white border-b border-gray-800 pb-4 flex items-center gap-2 justify-center md:justify-start">
            <User className="h-6 w-6 text-emerald-500" />
            <span>{translations.title}</span>
          </h2>
          <p className="text-xs text-gray-400 mt-2 leading-relaxed">
            {translations.sub}
          </p>
        </div>

        {/* Warning card for missing fields */}
        {Object.keys(errors).length > 0 && (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-rose-950/20 border border-rose-900/50 text-rose-400 text-xs shadow-inner">
            <AlertTriangle className="h-5 w-5 text-rose-500 shrink-0" />
            <p className="font-semibold">
              {locale === 'ar'
                ? 'يرجى مراجعة الحقول وتمحيص الأخطاء المميزة بالأحمر بالأسفل لتأكيد الحفظ.'
                : 'Form contains incomplete fields. Please verify red highlighted segments below.'
              }
            </p>
          </div>
        )}

        {/* Form Body layout */}
        <form onSubmit={handleFormSubmit} className="space-y-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            
            {/* Full Name */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-1">
                <span>{translations.nameLabel}</span>
                <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className={`w-full rounded-xl border py-2.5 px-4 text-sm outline-none transition-all focus:ring-1 bg-gray-950 text-white ${
                    errors.name
                      ? 'border-rose-500/50 focus:border-rose-500 focus:ring-rose-500/20'
                      : 'border-gray-800 focus:border-emerald-500 focus:ring-emerald-500/20'
                  }`}
                />
              </div>
              {errors.name && <p className="text-xs text-rose-500 mt-1">{errors.name}</p>}
            </div>

            {/* Phone Number */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-1">
                <Phone className="h-3.5 w-3.5 text-gray-500" />
                <span>{translations.phoneLabel}</span>
                <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                placeholder={translations.phonePlaceholder}
                className={`w-full rounded-xl border py-2.5 px-4 text-sm outline-none transition-all focus:ring-1 bg-gray-950 text-white ${
                  errors.phone
                    ? 'border-rose-500/50 focus:border-rose-500 focus:ring-rose-500/20'
                    : 'border-gray-800 focus:border-emerald-500 focus:ring-emerald-500/20'
                }`}
                style={{ direction: 'ltr', textAlign: locale === 'ar' ? 'right' : 'left' }}
              />
              {errors.phone && <p className="text-xs text-rose-500 mt-1">{errors.phone}</p>}
            </div>

          </div>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full rounded-full bg-emerald-600 hover:bg-emerald-700 py-3 px-4 text-sm font-bold text-white transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <ShieldCheck className="h-4 w-4" />
              <span>{translations.saveBtn}</span>
            </button>
          </div>
        </form>

        {/* Footer note */}
        <div className="border-t border-gray-800 pt-4 text-center text-[11px] text-gray-500">
          {translations.certified}
        </div>

      </div>
    </div>
  );
};
export default CompleteProfile;
