import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { Sparkles, ShieldCheck } from 'lucide-react';

export const Login: React.FC = () => {
  const { locale, loginWithGoogle, user, isProfileComplete, navigate } = useStore();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      if (isProfileComplete()) {
        navigate('home');
      } else {
        navigate('complete-profile');
      }
    }
  }, [user, navigate, isProfileComplete]);

  const translations = {
    title: locale === 'ar' ? 'مرحباً بك في منصة قاضي تيك' : 'Welcome to Qadi Tech',
    sub: locale === 'ar' ? 'سجل دخولك بنقرة آمنة موثقة لتعبئة محفظتك وشحن خدمات ألعابك بشكل فوري في دقائق.' : 'Sign in securely inside our sandbox database to manage and recharge game packages.',
    googleBtn: locale === 'ar' ? 'المتابعة والدخول بحساب Google' : 'Continue with Google Account',
    mockHint: locale === 'ar' ? 'الدخول التجريبي يتم فوراً بنقرة واحدة لأغراض المعاينة وتجربة الطلب.' : 'Sandbox login is instantaneous for visual order testing in a single tap.',
    connecting: locale === 'ar' ? 'جاري التحقق والدخول الموحد...' : 'Connecting OAuth Service...',
    certified: locale === 'ar' ? 'تشفير ومصادقة سحابية مؤمنة ١٠٠٪' : '100% Secure Cryptographic OAuth Channel'
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      await loginWithGoogle();
    } catch (error) {
      console.error("Login failed", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4 py-12 sm:px-6 lg:px-8 bg-[#07090e]" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
      <div className="w-full max-w-md space-y-8 bg-[#0c101b] border border-gray-850 p-8 sm:p-10 rounded-2xl shadow-2xl text-center">
        
        {/* Brand visual header */}
        <div className="flex flex-col items-center">
          <img 
            src="https://i.postimg.cc/BZrRzwt0/image.png" 
            alt="Qadi Tech Logo" 
            className="h-16 w-auto object-contain mb-5 animate-pulse"
          />
          <h2 className="text-lg sm:text-xl font-black tracking-tight text-white">
            {translations.title}
          </h2>
          <p className="text-xs text-gray-400 mt-2.5 leading-relaxed max-w-xs font-semibold">
            {translations.sub}
          </p>
        </div>

        {/* Action Panel */}
        <div className="mt-8 space-y-4">
          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="group relative flex w-full items-center justify-center gap-3 rounded-full border border-gray-800 bg-gray-950 px-4 py-3 text-xs font-black text-gray-200 hover:text-white hover:border-emerald-500/40 transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            {/* Google G logo colors vector */}
            <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#EA4335"
                d="M12 5.04c1.64 0 3.12.56 4.28 1.67l3.2-3.2C17.52 1.57 14.99 1 12 1 7.35 1 3.39 3.67 1.48 7.57l3.85 2.99C6.27 7.03 8.94 5.04 12 5.04z"
              />
              <path
                fill="#4285F4"
                d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.46c-.29 1.48-1.14 2.74-2.42 3.58l3.77 2.92c2.2-2.03 3.48-5.02 3.48-8.65z"
              />
              <path
                fill="#FBBC05"
                d="M5.33 10.56a7.22 7.22 0 0 1 0 4.28l-3.85 2.99C.54 15.65 0 13.89 0 12s.54-3.65 1.48-5.83l3.85 2.99z"
              />
              <path
                fill="#34A853"
                d="M12 23c3.24 0 5.97-1.07 7.96-2.92l-3.77-2.92c-1.1.74-2.52 1.18-4.19 1.18-3.06 0-5.73-1.99-6.67-5.52l-3.85 2.99C3.39 20.33 7.35 23 12 23z"
              />
            </svg>
            <span>{loading ? translations.connecting : translations.googleBtn}</span>
          </button>

          <div className="rounded-xl bg-gray-950/60 p-3.5 border border-gray-850/50 text-[10px] font-bold text-gray-500 leading-normal flex items-center gap-2 justify-center">
            <Sparkles className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
            <span>{translations.mockHint}</span>
          </div>
        </div>

        {/* Footer info lock secure */}
        <div className="pt-6 border-t border-gray-850 flex items-center justify-center gap-1.5 text-[9px] font-bold text-gray-500">
          <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{translations.certified}</span>
        </div>

      </div>
    </div>
  );
};
export default Login;
