import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { CreditCard, History, Calendar, DollarSign, Wallet as WalletIcon, ArrowUpRight, TrendingUp } from 'lucide-react';

export const Wallet: React.FC = () => {
  const { locale, user, orders, formatPrice, currency } = useStore();
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');

  // Parse wallet balances or mock default starting credits if missing
  const balanceUSD = user?.balanceUSD ?? 250;
  const balanceSYP = user?.balanceSYP ?? 3500000;
  const balanceEGP = user?.balanceEGP ?? 12000;

  // Active balance based on selected currency
  const getActiveBalanceAmount = () => {
    if (currency === 'SYP') return balanceSYP;
    if (currency === 'EGP') return balanceEGP;
    return balanceUSD;
  };

  const getExchangeRateFromUSD = () => {
    if (currency === 'SYP') return 14000;
    if (currency === 'EGP') return 48;
    return 1;
  };

  // Calculate total spent based on completed orders
  const completedOrders = orders.filter(o => o.status === 'completed' || o.status === 'accepted' || o.status === 'shipped');
  
  const totalSpentUSD = completedOrders.reduce((sum, order) => sum + (order.total || 0), 0);
  const totalSpentActive = totalSpentUSD * getExchangeRateFromUSD();

  // Filter completed purchases by date
  const getFilteredTransactions = () => {
    const now = new Date();
    return completedOrders.filter(order => {
      const orderDate = new Date(order.timestamp);
      if (dateFilter === 'today') {
        return orderDate.toDateString() === now.toDateString();
      } else if (dateFilter === 'week') {
        const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        return orderDate >= oneWeekAgo;
      } else if (dateFilter === 'month') {
        const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        return orderDate >= oneMonthAgo;
      }
      return true;
    });
  };

  const filteredTx = getFilteredTransactions();

  const labels = {
    title: locale === 'ar' ? 'المحفظة الرقمية' : 'Digital Wallet',
    currentBalance: locale === 'ar' ? 'الرصيد الحالي' : 'Current Balance',
    totalSpent: locale === 'ar' ? 'إجمالي المشتريات' : 'Total Purchases',
    noTransactions: locale === 'ar' ? 'لا يوجد مشتريات مطابقة للمدة المحددة' : 'No transactions matching this period',
    filters: {
      all: locale === 'ar' ? 'الكل' : 'All',
      today: locale === 'ar' ? 'اليوم' : 'Today',
      week: locale === 'ar' ? 'آخر أسبوع' : 'Last Week',
      month: locale === 'ar' ? 'آخر شهر' : 'Last Month'
    },
    transactionHistory: locale === 'ar' ? 'سجل العمليات الرقمية' : 'Digital Transactions Log',
    service: locale === 'ar' ? 'الخدمة' : 'Service',
    date: locale === 'ar' ? 'التاريخ' : 'Date',
    details: locale === 'ar' ? 'التفاصيل / معرفات الشحن' : 'Details / Game ID',
    value: locale === 'ar' ? 'القيمة' : 'Amount'
  };

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-8" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
      
      {/* Page Header */}
      <div className="flex items-center gap-3 border-b border-gray-800 pb-5">
        <div className="p-2.5 bg-emerald-950/40 rounded-xl border border-emerald-500/20 text-emerald-400">
          <WalletIcon className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white">{labels.title}</h1>
          <p className="text-xs text-gray-400 mt-1">
            {locale === 'ar' ? 'إدارة رصيدك الموحد وسجل معاملات شحن الألعاب والبطاقات' : 'Manage your unified wallet balance and gaming card history'}
          </p>
        </div>
      </div>

      {/* Cards Layout - Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Balance Card */}
        <div className="relative overflow-hidden bg-gradient-to-br from-[#0c1424] to-[#0f172a] border border-emerald-500/20 rounded-3xl p-6 shadow-xl shadow-emerald-950/10">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl -mr-8 -mt-8" />
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{labels.currentBalance}</span>
              <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight mt-1 font-mono">
                {formatPrice(getActiveBalanceAmount() / getExchangeRateFromUSD())}
              </h2>
            </div>
            <div className="h-10 w-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <CreditCard className="h-5 w-5" />
            </div>
          </div>
          
          <div className="mt-8 pt-4 border-t border-gray-800/60 flex justify-between text-xs text-gray-400">
            <span>{locale === 'ar' ? 'الحساب مفعل وبرقم موثق' : 'Account active & phone verified'}</span>
            <span className="font-mono">{user?.phone}</span>
          </div>
        </div>

        {/* Total Spent Card */}
        <div className="relative overflow-hidden bg-gradient-to-br from-[#0c1424] to-[#0f172a] border border-gray-800 rounded-3xl p-6 shadow-xl">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl -mr-8 -mt-8" />
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{labels.totalSpent}</span>
              <h2 className="text-3xl sm:text-4xl font-black text-gray-200 tracking-tight mt-1 font-mono">
                {formatPrice(totalSpentActive / getExchangeRateFromUSD())}
              </h2>
            </div>
            <div className="h-10 w-10 rounded-2xl bg-gray-800 border border-gray-700 flex items-center justify-center text-emerald-400">
              <TrendingUp className="h-5 w-5" />
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-gray-800/60 flex justify-between text-xs text-gray-400">
            <span>{locale === 'ar' ? 'إجمالي الطلبات الناجحة' : 'Total successful digital transactions'}</span>
            <span className="font-bold text-emerald-400 font-mono">{completedOrders.length}</span>
          </div>
        </div>

      </div>

      {/* Date Filters & History Table */}
      <div className="bg-[#0c101b] border border-gray-800 rounded-3xl p-6 space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
            <History className="h-4 w-4 text-emerald-400" />
            <span>{labels.transactionHistory}</span>
          </h3>
          
          {/* Filter segment */}
          <div className="flex gap-1.5 bg-gray-900/60 p-1 rounded-xl border border-gray-800 w-max">
            {(['all', 'today', 'week', 'month'] as const).map(filter => (
              <button
                key={filter}
                onClick={() => setDateFilter(filter)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  dateFilter === filter
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {labels.filters[filter]}
              </button>
            ))}
          </div>
        </div>

        {/* Transaction Cards List */}
        {filteredTx.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-gray-800 rounded-2xl">
            <Calendar className="h-8 w-8 text-gray-600 mx-auto mb-2" />
            <p className="text-xs text-gray-500 font-bold">{labels.noTransactions}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredTx.map(tx => {
              const item = tx.items[0];
              if (!item) return null;
              
              const isReceivedOrder = tx.items[0]?.product?.id?.startsWith('charge_');
              const txTitle = isReceivedOrder 
                ? (locale === 'ar' ? `إيداع رصيد - ${item.product.name_ar}` : `Deposit - ${item.product.name_en}`)
                : (locale === 'ar' ? item.product.name_ar : item.product.name_en);

              return (
                <div 
                  key={tx.id} 
                  className="bg-gray-950/60 border border-gray-800 hover:border-gray-700 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all"
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2.5 rounded-xl shrink-0 ${isReceivedOrder ? 'bg-emerald-950/50 border border-emerald-500/20 text-emerald-400' : 'bg-gray-900 border border-gray-800 text-gray-300'}`}>
                      {isReceivedOrder ? <ArrowUpRight className="h-4 w-4" /> : <CreditCard className="h-4 w-4" />}
                    </div>
                    <div className="space-y-1 min-w-0">
                      <h4 className="font-bold text-xs sm:text-sm text-white truncate">{txTitle}</h4>
                      <p className="text-[11px] text-gray-500 font-mono">
                        {new Date(tx.timestamp).toLocaleString(locale === 'ar' ? 'ar-EG' : 'en-US')}
                      </p>
                    </div>
                  </div>

                  {/* Transaction info block */}
                  <div className="flex items-center justify-between md:justify-end gap-12 border-t md:border-t-0 border-gray-800/40 pt-3 md:pt-0">
                    <div className="text-start md:text-end space-y-1">
                      <span className="block text-[10px] text-gray-500 uppercase tracking-widest">{labels.details}</span>
                      <span className="font-mono text-xs text-gray-300 font-bold">
                        {item.selectedSize ? `${item.selectedSize}` : ''}
                        {item.selectedType ? ` | ID: ${item.selectedType}` : ''}
                        {!item.selectedSize && !item.selectedType ? (locale === 'ar' ? 'لا يوجد معرفات' : 'Instant delivery') : ''}
                      </span>
                    </div>

                    <div className="text-end">
                      <span className="block text-[10px] text-gray-500 uppercase tracking-widest">{labels.value}</span>
                      <span className={`font-mono text-sm sm:text-base font-black ${isReceivedOrder ? 'text-emerald-400' : 'text-gray-100'}`}>
                        {isReceivedOrder ? '+' : ''}{formatPrice(tx.total)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
};

export default Wallet;
