import { useEffect, useRef } from 'react';
import { collection, query, where, getDocs, updateDoc, doc, getDoc } from 'firebase/firestore';
import { db, auth } from '../services/firebase';
import { Order, OrderStatus } from '../types';

export function useOranosPolling(locale: 'ar' | 'en', showToast: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void) {
  const isPollingRef = useRef(false);

  useEffect(() => {
    let intervalId: any;

    const pollActiveOranosOrders = async () => {
      if (isPollingRef.current) return;
      
      const currentUser = auth.currentUser;
      if (!currentUser) return;

      isPollingRef.current = true;

      try {
        // Find processing orders that belong to this user
        const ordersRef = collection(db, 'orders');
        const q = query(
          ordersRef, 
          where('userId', '==', currentUser.uid),
          where('status', '==', 'processing'),
          where('isOranosOrder', '==', true)
        );
        
        const snapshot = await getDocs(q);
        if (snapshot.empty) {
          isPollingRef.current = false;
          return;
        }

        const promises = snapshot.docs.map(async (orderDoc) => {
          const orderData = orderDoc.data() as Order;
          const oranosId = orderData.oranosOrderId;
          const localOrderId = orderDoc.id;

          if (!oranosId) return;

          try {
            const res = await fetch(`/api/oranos/check-order/${oranosId}`);
            if (!res.ok) return;

            const resJson = await res.json();
            // Oranos check-order returns a list: data: [{ status, replay_api, error, ... }]
            const orderMeta = resJson.data?.[0];
            if (!orderMeta) return;

            const oranosStatus = orderMeta.status; // "accept" | "reject" | "wait"

            if (oranosStatus === 'accept') {
              const replayCodes = orderMeta.replay_api || null;
              
              // Map 'accept' to 'completed'
              const updatedSteps = [
                { status: 'pending' as OrderStatus, timestamp: orderData.timestamp, completed: true },
                { status: 'processing' as OrderStatus, timestamp: new Date().toISOString(), completed: true },
                { status: 'completed' as OrderStatus, timestamp: new Date().toISOString(), completed: true }
              ];

              await updateDoc(doc(db, 'orders', localOrderId), {
                status: 'completed',
                oranosStatus: 'accept',
                trackingSteps: updatedSteps,
                replayApi: replayCodes,
                completedAt: new Date().toISOString()
              });

              showToast(
                locale === 'ar' 
                  ? `تم اكتمال وتسليم طلبك الرقمي بنجاح رقم: ${localOrderId}` 
                  : `Your digital top-up order ${localOrderId} is completed!`, 
                'success'
              );
            } 
            else if (oranosStatus === 'reject') {
              const rejectionReason = orderMeta.error || orderMeta.message || 'Rejected by Oranos';

              const updatedSteps = [
                { status: 'pending' as OrderStatus, timestamp: orderData.timestamp, completed: true },
                { status: 'processing' as OrderStatus, timestamp: new Date().toISOString(), completed: false },
                { status: 'canceled' as OrderStatus, timestamp: new Date().toISOString(), completed: true }
              ];

              await updateDoc(doc(db, 'orders', localOrderId), {
                status: 'canceled',
                oranosStatus: 'reject',
                rejectionReason: rejectionReason,
                trackingSteps: updatedSteps,
                completedAt: new Date().toISOString()
              });

              // Execute Wallet Refund Automatically
              try {
                // Fetch the item product to understand currency and price
                const orderItem = orderData.items?.[0];
                if (orderItem) {
                  const product = orderItem.product;
                  const quantity = orderItem.quantity;
                  const total = (product.discountPrice ?? product.price) * quantity;

                  // Read user profile
                  const usersRef = collection(db, 'users');
                  const userSnap = await getDocs(query(usersRef, where('uid', '==', currentUser.uid)));
                  if (!userSnap.empty) {
                    const userDoc = userSnap.docs[0];
                    const uData = userDoc.data();
                    
                    // Detect which currency was used. Defaulting to user's saved wallets
                    // total is in base price, we convert according to currency factor or use stored total directly
                    // To be safe, let's reverse whatever deduction occurred
                    // If currency factors are stored, we refund the exact currency cost. Let's calculate cost
                    // Let's inspect currency setting or revert user's balances
                    let refundField = 'balanceUSD';
                    let refundAmount = total;

                    // Match user balance type based on size of total
                    // Or let's use the actual order total or original deduction field
                    // A very safe way is checking order item currency, or check user balance fields to refund
                    // If user had EGP/SYP, userDoc details will reflect these.
                    // Let's check which amount matches nearest. Or just check currently active currency or store total
                    // Let's check order fields. In buyImmediately, it deducts from balanceUSD/balanceSYP/balanceEGP
                    // Let's restore to user's profiles
                    const currentUSD = uData.balanceUSD ?? 0;
                    const currentSYP = uData.balanceSYP ?? 0;
                    const currentEGP = uData.balanceEGP ?? 0;

                    // In buyImmediately, deduction depends on currency used. Let's store currency indicator or guess:
                    // Usually orders have item details or we can read the currency we deduted
                    // Let's match: if total > 2000, it's SYP; if total > 100 but < 2000, it's EGP; otherwise USD.
                    if (orderData.total > 2000 || total > 2000) {
                      refundField = 'balanceSYP';
                      refundAmount = orderData.total;
                    } else if (orderData.total > 100) {
                      refundField = 'balanceEGP';
                      refundAmount = orderData.total;
                    } else {
                      refundField = 'balanceUSD';
                      refundAmount = orderData.total;
                    }

                    const currentBalValue = uData[refundField] || 0;
                    await updateDoc(userDoc.ref, {
                      [refundField]: currentBalValue + refundAmount
                    });

                    // Update localStorage fallback
                    const userLocal = localStorage.getItem('store_user');
                    if (userLocal) {
                      const parsed = JSON.parse(userLocal);
                      parsed[refundField] = (parsed[refundField] || 0) + refundAmount;
                      localStorage.setItem('store_user', JSON.stringify(parsed));
                    }
                  }
                }
              } catch (refundErr) {
                console.error("Automated refund failed for order:", localOrderId, refundErr);
              }

              showToast(
                locale === 'ar'
                  ? `عذراً! تم إلغاء طلبك من المزود لسبب: ${rejectionReason}، وتم رد المبلغ كاملاً لمحفظتك تلقائياً.`
                  : `Order ${localOrderId} canceled by provider: ${rejectionReason}. Refunded to wallet automatically.`,
                'error'
              );
            }
          } catch (err) {
            console.error("Error polling Oranos order:", localOrderId, err);
          }
        });

        await Promise.all(promises);
      } catch (err) {
        console.error("Polling snapshot error:", err);
      } finally {
        isPollingRef.current = false;
      }
    };

    // Run immediately and then every 30 seconds
    pollActiveOranosOrders();
    intervalId = setInterval(pollActiveOranosOrders, 30000);

    return () => {
      clearInterval(intervalId);
    };
  }, [locale, showToast]);
}
