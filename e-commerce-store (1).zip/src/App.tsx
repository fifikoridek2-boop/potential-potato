/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { StoreProvider, useStore } from './context/StoreContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';

// Pages
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { CompleteProfile } from './pages/CompleteProfile';
import { ProductDetail } from './pages/ProductDetail';
import { OrderHistory } from './pages/OrderHistory';
import { OrderTracker } from './pages/OrderTracker';
import { Categories } from './pages/Categories';
import { CategoryProducts } from './pages/CategoryProducts';
import { Settings } from './pages/Settings';
import { Admin } from './pages/Admin';
import { Contact } from './pages/Contact';
import { Wallet } from './pages/Wallet';
import { BalanceCharge } from './pages/BalanceCharge';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

const MainAppContent: React.FC = () => {
  const { locale, dir, toast, confirmDialog, hideConfirm } = useStore();
  const location = useLocation();

  const isCmsAdmin = location.pathname.startsWith('/admin');

  // Helper for rendering confirm dialog
  const renderConfirmDialog = () => {
    if (!confirmDialog || !confirmDialog.isOpen) return null;
    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" style={{ direction: dir }}>
        <div className="bg-[#0e121f] rounded-3xl p-6 md:p-8 max-w-sm w-full shadow-2xl shadow-black/60 transform animate-slide-up border border-gray-800">
          <h3 className="text-lg font-black text-white mb-2">{confirmDialog.title}</h3>
          <p className="text-sm font-semibold text-gray-400 mb-8 leading-relaxed">{confirmDialog.message}</p>
          
          <div className="flex gap-3">
            <button
              onClick={hideConfirm}
              className="flex-1 py-3 px-4 rounded-xl font-bold text-xs bg-gray-900 hover:bg-gray-800 text-gray-300 transition-colors border border-gray-800"
            >
              {confirmDialog.cancelText || (locale === 'ar' ? 'إلغاء' : 'Cancel')}
            </button>
            <button
              onClick={() => {
                confirmDialog.onConfirm();
                hideConfirm();
              }}
              className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs text-white transition-colors border ${
                confirmDialog.isDestructive 
                  ? 'bg-rose-600 hover:bg-rose-700 border-rose-700 shadow-rose-200' 
                  : 'bg-emerald-600 hover:bg-emerald-700 border-emerald-500 shadow-emerald-950/25'
              } shadow-lg`}
            >
              {confirmDialog.confirmText || (locale === 'ar' ? 'تأكيد' : 'Confirm')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Helper for rendering toast
  const renderToast = () => {
    if (!toast) return null;
    return (
      <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] animate-fade-in pointer-events-none w-max max-w-[95vw]">
        <div className={`px-5 py-2.5 rounded-xl shadow-2xl font-bold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-3 backdrop-blur-md whitespace-nowrap overflow-hidden text-ellipsis border ${
          toast.type === 'success' ? 'bg-black/90 text-white border-zinc-800' : 
          toast.type === 'error' ? 'bg-rose-600/95 text-white border-rose-500' : 
          'bg-white/95 text-black border-gray-200'
        }`}>
          {toast.message}
        </div>
      </div>
    );
  };

  // Route switcher using professional declarative React Router routes
  const renderActivePage = () => {
    return (
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/complete-profile" element={<CompleteProfile />} />
        <Route path="/product/:productId" element={<ProductDetail />} />
        <Route path="/wallet" element={<Wallet />} />
        <Route path="/add-balance" element={<BalanceCharge />} />
        <Route path="/balance-charge" element={<BalanceCharge />} />
        <Route path="/orders" element={<OrderHistory />} />
        <Route path="/orders/:orderId" element={<OrderTracker />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/category/:categoryId" element={<CategoryProducts />} />
        <Route path="/products" element={<CategoryProducts />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/profile" element={<Settings />} />
        <Route path="/settings" element={<Navigate to="/profile" replace />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    );
  };

  if (isCmsAdmin) {
    return (
      <div className="min-h-screen bg-[#07090e] text-gray-100" style={{ direction: dir }}>
        {renderToast()}
        {renderConfirmDialog()}
        <Routes>
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Routes>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-[#07090e] text-gray-100 flex flex-col justify-between selection:bg-emerald-600 selection:text-white"
      style={{ direction: dir }}
    >
      {renderToast()}
      {renderConfirmDialog()}
      {/* Dynamic Header */}
      <Navbar />

      {/* Slide-out Sidebar Menu */}
      <Sidebar />

      {/* Main viewport area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8 focus:outline-none overflow-hidden">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
        >
          {renderActivePage()}
        </motion.div>
      </main>

      {/* Responsive Footer */}
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <StoreProvider>
        <MainAppContent />
      </StoreProvider>
    </BrowserRouter>
  );
}
