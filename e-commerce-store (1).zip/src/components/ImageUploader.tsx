import React, { useState, useRef } from 'react';
import { Upload, X, Image as ImageIcon, CheckCircle, AlertTriangle } from 'lucide-react';

interface ImageUploaderProps {
  value?: string;
  onChange: (base64: string) => void;
  locale: 'ar' | 'en';
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ value, onChange, locale }) => {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(value || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = {
    dragText: locale === 'ar' ? 'اسحب الصورة هنا أو اضغط للاختيار' : 'Drag & drop your image here or click to browse',
    limitText: locale === 'ar' ? 'يدعم JPG, PNG, WebP حتى 2 ميجابايت (مربع 1:1)' : 'Supports JPG, PNG, WebP up to 2MB (Center cropped to 1:1)',
    fileTooLarge: locale === 'ar' ? 'حجم الملف كبير جداً! الحد الأقصى 2 ميجابايت' : 'File is too large! Maximum limit is 2MB',
    invalidType: locale === 'ar' ? 'نوع الملف غير صالح! يرجى اختيار صورة JPG أو PNG أو WebP' : 'Invalid file type! Please choose a JPG, PNG, or WebP image',
    processedSuccess: locale === 'ar' ? 'تمت معالجة الصورة واقتصاصها بنجاح!' : 'Image cropped and scaled successfully!',
    customImageLabel: locale === 'ar' ? 'الصورة المخصصة مجهزة للفروع:' : 'Custom image prepared for resolutions:'
  };

  const processImage = (file: File) => {
    setError(null);

    // Validate size (2MB)
    if (file.size > 2 * 1024 * 1024) {
      setError(t.fileTooLarge);
      return;
    }

    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError(t.invalidType);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        // Create canvas to crop and resize center 1:1 square
        const canvas = document.createElement('canvas');
        const size = Math.min(img.width, img.height);
        canvas.width = 500; // Generate primary 500x500 high-res format
        canvas.height = 500;

        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Source coordinates for center-cropping
          const sx = (img.width - size) / 2;
          const sy = (img.height - size) / 2;

          ctx.drawImage(img, sx, sy, size, size, 0, 0, 500, 500);
          const croppedBase64 = canvas.toDataURL('image/jpeg', 0.85);
          setPreview(croppedBase64);
          onChange(croppedBase64);
        }
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processImage(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processImage(e.target.files[0]);
    }
  };

  const clearImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPreview(null);
    onChange('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-4">
      <div
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center transition-all cursor-pointer ${
          dragActive
            ? 'border-emerald-500 bg-emerald-950/20'
            : preview
            ? 'border-gray-800 bg-gray-950/40 hover:bg-gray-950/60'
            : 'border-gray-800 hover:border-emerald-500/50 hover:bg-gray-900/10'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".jpg,.jpeg,.png,.webp"
          onChange={handleFileInput}
          className="hidden"
        />

        {preview ? (
          <div className="flex flex-col items-center gap-3 w-full">
            <div className="relative group w-32 h-32 rounded-lg overflow-hidden border border-gray-800">
              <img src={preview} alt="Preview" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={clearImage}
                className="absolute top-1 right-1 p-1 bg-gray-950/80 rounded-full hover:bg-rose-600 transition-colors"
                id="clear-img-btn"
              >
                <X className="h-4 w-4 text-white" />
              </button>
            </div>
            
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
              <CheckCircle className="h-4 w-4" />
              <span>{t.processedSuccess}</span>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center text-center space-y-2">
            <div className="p-3 bg-gray-950/60 rounded-xl border border-gray-800 text-gray-400 group-hover:text-emerald-400 transition-colors">
              <Upload className="h-6 w-6" />
            </div>
            <p className="text-sm font-medium text-gray-300">{t.dragText}</p>
            <p className="text-xs text-gray-500 max-w-xs">{t.limitText}</p>
          </div>
        )}

        {error && (
          <div className="absolute bottom-2 left-2 right-2 border border-rose-900/50 bg-rose-950/30 text-rose-400 text-xs py-1.5 px-3 rounded-lg flex items-center gap-2">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {preview && (
        <div className="bg-gray-950/40 p-3 rounded-xl border border-gray-870/50 space-y-2.5">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t.customImageLabel}</p>
          <div className="flex items-end gap-5">
            <div className="flex flex-col items-center gap-1">
              <div className="w-[100px] h-[100px] border border-gray-800 rounded overflow-hidden">
                <img src={preview} className="w-full h-full object-cover" alt="100x100" />
              </div>
              <span className="text-[9px] text-gray-400">100 × 100</span>
            </div>

            <div className="flex flex-col items-center gap-1">
              <div className="w-[70px] h-[70px] border border-gray-800 rounded overflow-hidden">
                <img src={preview} className="w-full h-full object-cover" alt="250x250" />
              </div>
              <span className="text-[9px] text-gray-400">250 × 250</span>
            </div>

            <div className="flex flex-col items-center gap-1">
              <div className="w-[45px] h-[45px] border border-gray-800 rounded overflow-hidden">
                <img src={preview} className="w-full h-full object-cover" alt="500x500" />
              </div>
              <span className="text-[9px] text-gray-400">500 × 500</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
