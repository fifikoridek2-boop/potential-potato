import React from 'react';
import { useStore } from '../context/StoreContext';
import { Mail, ShieldCheck, Gamepad2, Coins, CreditCard, Lock } from 'lucide-react';

export const Footer: React.FC = () => {
  const { locale, navigate, toggleLanguage, toggleCurrency, currency } = useStore();

  const translations = {
    desc: locale === 'ar' 
      ? 'قاضـي تـيـك - المنصة الرقمية والنظام المحوسب المتكامل لشحن فوري مباشر لشدات ألعاب الفيديو وبطاقات الهدايا بأمان وضمان كامل.'
      : 'Qadi Tech is the premier automated platform for immediate direct game-credits charging, digital assets top-ups, and international gift cards.',
    help: locale === 'ar' ? 'الدعم والمساعدة الرقمية' : 'Digital Help Desk',
    shop: locale === 'ar' ? 'خارطة خدماتنا' : 'Services index',
    guarantee: locale === 'ar' ? 'أمان وضمان تام ١٠٠٪' : 'Secure Encrypted Ledger',
    rights: locale === 'ar' ? 'جميع الحقوق محفوظة © ٢٠٢٦ منصة قاضي تيك لخدمات الشحن الرقمي.' : 'All Rights Reserved © 2026 Qadi Tech Billing Systems.',
    instantDelivery: locale === 'ar' ? 'تسليم تلقائي فوري خلال دقيقة واحدة' : 'Automated instant delivery under 60-seconds',
    contactSupport: locale === 'ar' ? 'فريق الدعم الفني: support@qaditech.com' : 'Direct Support: support@qaditech.com',
    links: {
      home: locale === 'ar' ? 'الصفحة الرئيسية' : 'Home Panel',
      categories: locale === 'ar' ? 'فئات وشبكة الشحن' : 'Charging Mesh',
      orders: locale === 'ar' ? 'سجل الطلبات الكلي' : 'Billing Ledger',
      settings: locale === 'ar' ? 'الملف الشخصي' : 'User profile',
      privacy: locale === 'ar' ? 'سياسة الاستخدام الرقمي' : 'Usage Policy'
    }
  };

  const fundingGates = [
    { name: 'USDT', label_ar: 'تيثر USDT', label_en: 'USDT TRC20' },
    { name: 'Syriatel Cash', label_ar: 'سيريتل كاش', label_en: 'Syriatel Cash' },
    { name: 'Vodafone', label_ar: 'فودافون كاش', label_en: 'Vodafone Cash' },
    { name: 'Internal Balance', label_ar: 'رصيد المحفظة', label_en: 'Wallet Balance' }
  ];

  return (
    <footer className="bg-[#04060a] border-t border-gray-850 text-gray-400 mt-20" style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Top Info Banner for Digital security */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 border-b border-gray-900 pb-8 mb-10 text-center md:text-start">
          <div className="flex flex-col md:flex-row items-center gap-3.5" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 shrink-0">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <p className="font-extrabold text-sm text-gray-200">{translations.guarantee}</p>
              <p className="text-[11px] text-gray-500 font-semibold mt-0.5">{locale === 'ar' ? 'نظام دفع مشفر يحمي رصيدك ومعاملاتك الرقمية بالكامل' : 'End-to-end cryptographic shielding for internal balance transfers'}</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-3.5" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 shrink-0">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <p className="font-extrabold text-sm text-gray-200">{translations.contactSupport}</p>
              <p className="text-[11px] text-gray-500 font-semibold mt-0.5">{locale === 'ar' ? 'تواصل معنا مباشرة عبر البريد للحصول على استجابة سريعة' : 'Available 24/7 with immediate ticket response'}</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-3.5" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 shrink-0">
              <Lock className="h-5 w-5" />
            </div>
            <div>
              <p className="font-extrabold text-sm text-gray-200">{translations.instantDelivery}</p>
              <p className="text-[11px] text-gray-500 font-semibold mt-0.5">{locale === 'ar' ? 'التسليم تلقائي وآلي بالكامل فور الدفع' : 'Automated processing triggers instant redeem key delivery'}</p>
            </div>
          </div>
        </div>

        {/* Middle Section: Links */}
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
          
          {/* Column 1: Brand Info */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <img 
                src="https://i.postimg.cc/BZrRzwt0/image.png" 
                alt="Qadi Tech" 
                className="h-8 w-auto object-contain"
              />
              <span className="font-sans text-base font-black tracking-normal text-white">
                {locale === 'ar' ? 'قاضـي تـيـك' : 'QADI TECH'}
              </span>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed max-w-xs font-semibold">
              {translations.desc}
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="font-black text-xs uppercase tracking-wider text-emerald-400 mb-4">{translations.shop}</h4>
            <ul className="space-y-2.5 text-xs font-bold">
              <li>
                <button onClick={() => navigate('home')} className="text-gray-400 hover:text-white transition-colors">{translations.links.home}</button>
              </li>
              <li>
                <button onClick={() => navigate('categories')} className="text-gray-400 hover:text-white transition-colors">{translations.links.categories}</button>
              </li>
              <li>
                <button onClick={() => navigate('profile')} className="text-gray-400 hover:text-white transition-colors">{locale === 'ar' ? 'معلومات العضوية' : 'Membership Info'}</button>
              </li>
            </ul>
          </div>

          {/* Column 3: Customer Care */}
          <div>
            <h4 className="font-black text-xs uppercase tracking-wider text-emerald-400 mb-4">{translations.help}</h4>
            <ul className="space-y-2.5 text-xs font-bold">
              <li>
                <button onClick={() => navigate('order-history')} className="text-gray-400 hover:text-white transition-colors">{translations.links.orders}</button>
              </li>
              <li>
                <button onClick={() => navigate('wallet')} className="text-gray-400 hover:text-white transition-colors">{locale === 'ar' ? 'المحفظة وإيداع الرصيد' : 'My Digital Wallet'}</button>
              </li>
              <li>
                <button onClick={() => navigate('contact')} className="text-gray-400 hover:text-white transition-colors">{locale === 'ar' ? 'اتصل بمسؤولي الدعم' : 'Contact Support'}</button>
              </li>
            </ul>
          </div>

          {/* Column 4: Controls & Theme Details */}
          <div>
            <h4 className="font-black text-xs uppercase tracking-wider text-emerald-400 mb-4">
              {locale === 'ar' ? 'تهيئة العرض' : 'Preferences'}
            </h4>
            <div className="flex flex-col gap-2.5">
              {/* Currency Toggle */}
              <button
                onClick={toggleCurrency}
                className="inline-flex w-fit items-center gap-1.5 px-3 py-1.5 bg-gray-950 text-xs border border-gray-800 rounded-full text-gray-300 hover:border-emerald-500/30 transition-colors font-mono font-black"
              >
                <span>
                  {locale === 'ar' 
                    ? `العملة النشطة بمحفظتك: ${currency}`
                    : `Active wallet currency: ${currency}`
                  }
                </span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom copyright and payment badges */}
        <div className="mt-12 pt-8 border-t border-gray-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-start">
          <p className="text-xs text-gray-500 font-bold">
            {translations.rights}
          </p>

          {/* Secure Funding Channels */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="text-[10px] font-black text-gray-500 mr-2 uppercase tracking-wider">
              {locale === 'ar' ? 'قنوات الإيداع والدفع الآمنة' : 'Funding gateways'}:
            </span>
            {fundingGates.map((pm) => (
              <span
                key={pm.name}
                className="px-2.5 py-1 text-[10px] font-bold text-gray-400 bg-gray-950 rounded-lg border border-gray-850"
              >
                {locale === 'ar' ? pm.label_ar : pm.label_en}
              </span>
            ))}
          </div>
        </div>

      </div>
    </footer>
  );
};
export default Footer;
