import React from 'react';
import { useStore } from '../context/StoreContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Home, 
  Wallet as WalletIcon, 
  PlusCircle, 
  ListOrdered, 
  LogOut, 
  LogIn, 
  CheckCircle2, 
  ShieldAlert, 
  Settings,
  Gamepad2,
  LifeBuoy
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const {
    locale,
    dir,
    isHamburgerOpen,
    setIsHamburgerOpen,
    user,
    logout,
    navigate,
    currentRoute,
    isAdminMode,
    formatPrice,
    currency
  } = useStore();

  const handleLinkClick = (route: any, params?: any) => {
    navigate(route, params);
    setIsHamburgerOpen(false);
  };

  // 6 Core Pivot Navigation Items
  const navItems = [
    {
      id: 'home',
      label_ar: 'الرئيسية (قاضي تيك)',
      label_en: 'Home Page',
      icon: Home,
      route: 'home' as const
    },
    {
      id: 'categories',
      label_ar: 'فئات وأقسام الشحن',
      label_en: 'Service Categories',
      icon: Gamepad2,
      route: 'categories' as const
    },
    {
      id: 'add-balance',
      label_ar: 'إضافة رصيد (شحن)',
      label_en: 'Add Balance (Deposit)',
      icon: PlusCircle,
      route: 'add-balance' as const
    },
    {
      id: 'wallet',
      label_ar: 'المحفظة الرقمية',
      label_en: 'Digital Wallet',
      icon: WalletIcon,
      route: 'wallet' as const
    },
    {
      id: 'orders',
      label_ar: 'طلبات الشحن والبطاقات',
      label_en: 'My Orders & Purchases',
      icon: ListOrdered,
      route: 'order-history' as const
    },
    {
      id: 'contact',
      label_ar: 'الدعم الفني والاتصال',
      label_en: 'Technical Support',
      icon: LifeBuoy,
      route: 'contact' as const
    }
  ];

  const translations = {
    login: locale === 'ar' ? 'تسجيل الدخول' : 'Sign In',
    logout: locale === 'ar' ? 'تسجيل الخروج' : 'Sign Out',
    balance: locale === 'ar' ? 'الرصيد المتوفر:' : 'Available Balance:',
    guestTitle: locale === 'ar' ? 'حساب زائر غير موثق' : 'Guest Account Mode',
    guarantee: locale === 'ar' ? 'منصة قاضي تيك موثقة ومؤمنة ١٠٠٪' : 'Qadi Tech Platform Certified 100%'
  };

  // Get current user active currency balance or default mock
  const getActiveBalanceAmount = () => {
    if (!user) return 0;
    if (currency === 'SYP') return user.balanceSYP ?? 3500000;
    if (currency === 'EGP') return user.balanceEGP ?? 12000;
    return user.balanceUSD ?? 250;
  };

  return (
    <AnimatePresence>
      {isHamburgerOpen && (
        <>
          {/* Dark Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsHamburgerOpen(false)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs"
          />

          {/* Drawer Body - Pure Dark Theme */}
          <motion.div
            initial={{ x: dir === 'rtl' ? '100%' : '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: dir === 'rtl' ? '100%' : '-100%' }}
            transition={{ type: 'spring', damping: 26, stiffness: 220 }}
            className={`fixed inset-y-0 z-51 w-full max-w-sm bg-[#080c14] p-6 shadow-2xl border-l border-gray-800 flex flex-col justify-between ${
              dir === 'rtl' ? 'right-0' : 'left-0'
            }`}
            style={{ direction: dir }}
          >
            <div>
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-6 border-b border-gray-800/80">
                <div className="flex items-center gap-2">
                  <img src="https://i.postimg.cc/BZrRzwt0/image.png" alt="Qadi Tech" className="h-8 w-auto object-contain" />
                  <span className="font-sans text-lg font-black tracking-wider text-emerald-400">
                    {locale === 'ar' ? 'قاضي تيك' : 'QADI TECH'}
                  </span>
                </div>
                <button
                  type="button"
                  id="close-sidebar"
                  onClick={() => setIsHamburgerOpen(false)}
                  className="rounded-lg p-2 text-gray-400 hover:bg-gray-900 hover:text-white transition-all active:scale-95"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Large Premium Profile Box with Balance Container */}
              <div className="my-6 p-5 rounded-2xl bg-gradient-to-br from-[#0c1324] to-[#0e172a] border border-emerald-500/20 shadow-xl space-y-4">
                {user ? (
                  <>
                    <div className="flex items-center gap-3">
                      <img
                        referrerPolicy="no-referrer"
                        src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                        alt={user.name}
                        className="h-12 w-12 rounded-full object-cover border-2 border-emerald-500 shadow-sm"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <p className="font-bold text-sm text-gray-100 truncate">{user.name}</p>
                          {user.phoneConfirmed ? (
                            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                          ) : (
                            <ShieldAlert className="h-4 w-4 text-amber-500 shrink-0" />
                          )}
                        </div>
                        <p className="text-xs text-gray-500 truncate font-mono">{user.email || user.phone}</p>
                      </div>
                    </div>

                    {/* Integrated Wallet Balance Widget */}
                    <div className="bg-gray-950/80 rounded-xl p-3.5 border border-gray-800 flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-400/80">
                          {translations.balance}
                        </span>
                        <p className="text-lg font-black text-white tracking-tight font-mono">
                          {formatPrice(getActiveBalanceAmount() / (currency === 'SYP' ? 14000 : currency === 'EGP' ? 48 : 1))}
                        </p>
                      </div>
                      <div className="h-8 w-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <WalletIcon className="h-4 w-4" />
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-3">
                      <div className="h-11 w-11 rounded-full bg-gray-900 border border-gray-800 flex items-center justify-center text-gray-400">
                        <X className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-gray-400">
                          {translations.guestTitle}
                        </p>
                        <button
                          onClick={() => handleLinkClick('login')}
                          className="text-xs font-bold text-emerald-400 underline hover:text-emerald-300 transition-colors"
                        >
                          {translations.login}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Navigation list */}
              <nav className="space-y-1.5">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentRoute === item.route;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleLinkClick(item.route)}
                      className={`flex w-full items-center gap-3.5 rounded-xl px-4 py-3 text-sm font-bold transition-all border ${
                        isActive
                          ? 'bg-emerald-600/90 text-white border-emerald-500 shadow-md shadow-emerald-950/20'
                          : 'text-gray-300 border-transparent hover:bg-gray-900 hover:text-white'
                      }`}
                      style={{ textAlign: dir === 'rtl' ? 'right' : 'left' }}
                    >
                      <Icon className={`h-5 w-5 ${isActive ? 'text-white animate-pulse' : 'text-emerald-400/85'}`} />
                      <span>{locale === 'ar' ? item.label_ar : item.label_en}</span>
                    </button>
                  );
                })}

                {isAdminMode && (
                  <button
                    onClick={() => handleLinkClick('admin')}
                    className="flex w-full items-center gap-3.5 rounded-xl border border-emerald-500/30 bg-emerald-950/20 px-4 py-3 text-sm font-bold text-emerald-300 hover:bg-emerald-950/40 transition-all mt-4"
                    style={{ textAlign: dir === 'rtl' ? 'right' : 'left' }}
                  >
                    <Settings className="h-5 w-5 text-emerald-400 shrink-0" />
                    <span>{locale === 'ar' ? 'عرض لوحة تحكم الإدارة' : 'System Administration Office'}</span>
                  </button>
                )}
              </nav>
            </div>

            {/* Bottom card & login/logout actions */}
            <div className="border-t border-gray-800 pt-6 space-y-4">
              <div className="rounded-xl bg-[#091515] p-3.5 flex items-center gap-3 border border-emerald-500/20">
                <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
                <p className="text-[10px] sm:text-xs font-bold text-emerald-200 leading-snug">
                  {translations.guarantee}
                </p>
              </div>

              {user ? (
                <button
                  type="button"
                  onClick={() => {
                    logout();
                    setIsHamburgerOpen(false);
                  }}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-rose-950 bg-rose-950/20 py-2.5 text-sm font-bold text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                >
                  <LogOut className="h-4 w-4" />
                  <span>{translations.logout}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => handleLinkClick('login')}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2.5 text-sm font-bold text-white hover:bg-emerald-700 transition-colors cursor-pointer"
                >
                  <LogIn className="h-4 w-4" />
                  <span>{translations.login}</span>
                </button>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
export default Sidebar;
