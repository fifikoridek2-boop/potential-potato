import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  Menu, 
  ShoppingBag, 
  User, 
  Globe, 
  Search, 
  LogOut, 
  Settings, 
  Package, 
  Bell, 
  Download, 
  Sparkles, 
  Tag, 
  CheckCheck, 
  BellRing, 
  ShieldCheck, 
  ShieldAlert,
  Wallet as WalletIcon
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    locale,
    toggleLanguage,
    currency,
    toggleCurrency,
    user,
    navigate,
    setIsHamburgerOpen,
    formatPrice,
    currentRoute,
    logout,
    uiConfig,
    isAdminMode,
    notifications,
    markNotificationRead,
    addNotification,
    systemNotificationPermission,
    requestSystemNotificationPermission,
    markAllNotificationsAsRead
  } = useStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [notifTab, setNotifTab] = useState<'all' | 'unread'>('all');

  const unreadNotifications = notifications.filter(n => !n.read).length;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('category-products', { searchQuery: searchQuery.trim() });
    }
  };

  const menuItems = {
    home: locale === 'ar' ? 'الرئيسية' : 'Home',
    categories: locale === 'ar' ? 'التصنيفات' : 'Categories',
    orders: locale === 'ar' ? 'الطلبات' : 'Orders',
    settings: locale === 'ar' ? 'الإعدادات' : 'Settings',
    searchPlaceholder: locale === 'ar' ? 'ابحث عن خدمات شحن أو بطاقات...' : 'Search for game cards...',
    loginBtn: locale === 'ar' ? 'دخول' : 'Sign In',
    completeProfile: locale === 'ar' ? 'إكمال الحساب' : 'Complete Profile',
    profile: locale === 'ar' ? 'الملف الشخصي' : 'Profile',
    logout: locale === 'ar' ? 'خروج' : 'Log Out'
  };

  // Get current user active currency balance
  const getActiveBalanceAmount = () => {
    if (!user) return 0;
    if (currency === 'SYP') return user.balanceSYP ?? 3500000;
    if (currency === 'EGP') return user.balanceEGP ?? 12000;
    return user.balanceUSD ?? 250;
  };

  return (
    <>
      {uiConfig?.announcementBarActive && (
        <div className="bg-emerald-950/80 text-emerald-300 text-[11px] py-2 px-4 text-center font-bold tracking-wide flex items-center justify-center gap-2 border-b border-emerald-900/50">
          <span>{locale === 'ar' ? uiConfig.announcementText_ar : uiConfig.announcementText_en}</span>
        </div>
      )}

      {/* Pure Dark Navigation Header */}
      <header className="sticky top-0 z-40 w-full border-b border-gray-800 bg-[#080c14]/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          
          {/* Left section: Hamburger Menu & Qadi Tech branding */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              id="nav-menu-toggle"
              onClick={() => setIsHamburgerOpen(true)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-gray-300 hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 active:scale-95 transition-all"
              aria-label="Toggle Menu"
            >
              <Menu className="h-6 w-6" />
            </button>

            {/* Premium Logo */}
            <div
              onClick={() => navigate('home')}
              className="flex cursor-pointer items-center gap-2.5 group"
            >
              <img 
                src="https://i.postimg.cc/BZrRzwt0/image.png" 
                alt="Qadi Tech" 
                className="h-9 w-auto object-contain transform group-hover:scale-105 transition-transform"
                onError={(e) => {
                  // fallback icon if logo fails to load
                  (e.target as any).src = 'https://i.postimg.cc/BZrRzwt0/image.png';
                }}
              />
              <span className="hidden sm:block font-sans text-lg font-black tracking-normal text-white">
                {locale === 'ar' ? 'قاضـي تـيـك' : 'QADI TECH'}
              </span>
            </div>
          </div>

          {/* Center Section: Search query container */}
          <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-sm mx-6">
            <div className="relative w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={menuItems.searchPlaceholder}
                className="w-full rounded-full border border-gray-800 bg-gray-950/80 py-2 pl-4 pr-10 text-xs outline-none transition-all placeholder:text-gray-500 focus:border-emerald-500 font-bold focus:ring-1 focus:ring-emerald-500"
                dir={locale === 'ar' ? 'rtl' : 'ltr'}
              />
              <button
                type="submit"
                className={`absolute top-1/2 -translate-y-1/2 text-gray-400 hover:text-emerald-400 transition-colors ${
                  locale === 'ar' ? 'left-3' : 'right-3'
                }`}
              >
                <Search className="h-4 w-4" />
              </button>
            </div>
          </form>

          {/* Right Section: Currencies + Language + Notifications */}
          <div className="flex items-center gap-2 sm:gap-3.5">
            
            {/* Quick Balance indicator for Desktop */}
            {user && (
              <div 
                onClick={() => navigate('wallet')} 
                className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full border border-emerald-500/10 bg-emerald-950/15 text-xs font-bold text-emerald-400 hover:bg-emerald-950/30 transition-all cursor-pointer"
              >
                <WalletIcon className="h-3.5 w-3.5" />
                <span className="font-mono">
                  {formatPrice(getActiveBalanceAmount() / (currency === 'SYP' ? 14000 : currency === 'EGP' ? 48 : 1))}
                </span>
              </div>
            )}

            {/* Currency Selector Pill */}
            <button
              onClick={toggleCurrency}
              title={locale === 'ar' ? 'تغيير العملة' : 'Toggle Currency'}
              className="flex items-center gap-1 bg-gray-950 border border-gray-800 text-emerald-400 text-xs font-black tracking-wider px-3 py-1.5 rounded-full hover:border-emerald-500/40 transition-all"
            >
              <span>{currency}</span>
              <span className="text-[10px] text-gray-500">
                {currency === 'USD' ? '$' : currency === 'SYP' ? 'ل.س' : 'ج.م'}
              </span>
            </button>

            {/* Notifications panel dropdown container */}
            <div className="relative">
              <button
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className="relative flex h-9 w-9 items-center justify-center rounded-full text-gray-300 hover:bg-gray-900 hover:text-white transition-all active:scale-95"
              >
                <Bell className="h-4.5 w-4.5" />
                {unreadNotifications > 0 && (
                  <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-emerald-500 ring-2 ring-gray-950"></span>
                )}
              </button>
              
              {isNotificationsOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setIsNotificationsOpen(false)} />
                  <div className={`absolute mt-2 w-80 rounded-2xl border border-gray-800 bg-[#0c101b] p-3.5 shadow-2xl z-20 ${locale === 'ar' ? 'left-0' : 'right-0'}`} style={{ direction: locale === 'ar' ? 'rtl' : 'ltr' }}>
                    <div className="flex justify-between items-center mb-3 px-1">
                      <h4 className="font-extrabold text-sm text-white">{locale === 'ar' ? 'صندوق التنبيهات' : 'Notifications'}</h4>
                      {unreadNotifications > 0 && (
                        <span className="text-[10px] bg-emerald-500 text-white font-extrabold px-1.5 py-0.5 rounded-full">
                          {unreadNotifications} {locale === 'ar' ? 'جديد' : 'new'}
                        </span>
                      )}
                    </div>

                    <div className="mb-3">
                      {systemNotificationPermission === 'default' && (
                        <button
                          onClick={requestSystemNotificationPermission}
                          className="w-full flex items-center justify-between gap-1.5 p-2 rounded-xl bg-emerald-950/20 hover:bg-emerald-950/40 text-emerald-400 transition-all text-[10px] font-extrabold border border-emerald-900/30 text-right cursor-pointer"
                        >
                          <span className="flex items-center gap-1.5">
                            <BellRing className="h-3.5 w-3.5 animate-bounce text-emerald-400" />
                            <span>{locale === 'ar' ? 'تشغيل إشعارات النظام الخارجية' : 'Enable system notifications'}</span>
                          </span>
                          <span className="text-emerald-400 font-mono">➜</span>
                        </button>
                      )}
                      {systemNotificationPermission === 'granted' && (
                        <div className="flex items-center gap-1.5 px-2 py-1.5 bg-[#091515] border border-emerald-950/50 rounded-xl text-emerald-400 text-[10px] font-bold">
                          <ShieldCheck className="h-3.5 w-3.5" />
                          <span>{locale === 'ar' ? 'إشعارات النظام الخارجية نشطة 🔔' : 'System notifications are active! 🔔'}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-2 px-1 pb-2 border-b border-gray-800 mb-2">
                      <div className="flex gap-1">
                        <button
                          onClick={() => setNotifTab('all')}
                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                            notifTab === 'all' ? 'bg-emerald-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-850'
                          }`}
                        >
                          {locale === 'ar' ? 'الكل' : 'All'}
                        </button>
                        <button
                          onClick={() => setNotifTab('unread')}
                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                            notifTab === 'unread' ? 'bg-emerald-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-850'
                          }`}
                        >
                          {locale === 'ar' ? 'غير مقروء' : 'Unread'}
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {unreadNotifications > 0 && (
                          <button
                            onClick={markAllNotificationsAsRead}
                            title={locale === 'ar' ? 'تحديد الكل كمقروء' : 'Mark all as read'}
                            className="p-1 rounded-lg hover:bg-gray-900 text-gray-400 hover:text-white transition-colors cursor-pointer"
                          >
                            <CheckCheck className="h-3.5 w-3.5" />
                          </button>
                        )}
                        
                        <button
                          onClick={() => {
                            addNotification({
                              title: locale === 'ar' ? 'تنبيه من قاضي تيك! 👋' : 'Welcome to Qadi Tech! 👋',
                              message: locale === 'ar'
                                ? 'رصيدك والشحن والتسليم التلقائي للبطاقات يعمل الآن بكفاءة متناهية.'
                                : 'Digital currency system, orders, and payments are functioning flawlessly.'
                            });
                          }}
                          title={locale === 'ar' ? 'إرسال إشعار تجريبي' : 'Trigger Demo Notification'}
                          className="p-1 rounded-lg hover:bg-emerald-950 text-emerald-400 transition-colors cursor-pointer"
                        >
                          <Sparkles className="h-3.5 w-3.5 shrink-0" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5 max-h-72 overflow-y-auto">
                      {notifications.filter(n => notifTab === 'all' || !n.read).length === 0 ? (
                        <div className="text-center py-8 text-gray-500">
                          <Bell className="h-6 w-6 mx-auto mb-2 opacity-30 text-emerald-500" />
                          <p className="text-[10px] font-bold">{locale === 'ar' ? 'صندوق الإشعارات فارغ' : 'No notifications match'}</p>
                        </div>
                      ) : (
                        notifications
                          .filter(n => notifTab === 'all' || !n.read)
                          .map(n => (
                            <div 
                              key={n.id}
                              className={`p-2.5 rounded-xl border flex gap-2.5 cursor-pointer transition-all ${
                                n.read ? 'border-transparent bg-transparent hover:bg-gray-900' : 'border-gray-800 bg-[#0e1524] hover:bg-gray-905'
                              }`}
                              onClick={() => {
                                if(!n.read) markNotificationRead(n.id);
                                if(n.route) {
                                  setIsNotificationsOpen(false);
                                  navigate(n.route as any, n.routeParams);
                                }
                              }}
                            >
                              <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${
                                n.read ? 'bg-gray-900 text-gray-500' : 'bg-emerald-600 text-white shadow-sm'
                              }`}>
                                <Bell className="h-4 w-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-black text-gray-200 truncate">{n.title}</p>
                                <p className="text-[10px] font-bold text-gray-500 leading-normal mt-0.5">{n.message}</p>
                              </div>
                            </div>
                          ))
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Profile Dropdown or Login buttons */}
            {user ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                  className="flex items-center gap-1.5 bg-gray-950 p-1 pr-2.5 rounded-full border border-gray-800 transition-all hover:border-emerald-500/20"
                >
                  <span className="hidden sm:inline font-bold text-xs text-gray-300 max-w-[80px] truncate">
                    {user.name.split(' ')[0]}
                  </span>
                  <img
                    referrerPolicy="no-referrer"
                    src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                    alt={user.name}
                    className="h-7 w-7 rounded-full object-cover border border-emerald-500/40"
                  />
                </button>

                {isUserDropdownOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-10" 
                      onClick={() => setIsUserDropdownOpen(false)}
                    />
                    <div
                      className={`absolute mt-2 w-56 rounded-xl border border-gray-800 bg-[#0c101b] p-2 shadow-xl z-20 ${
                        locale === 'ar' ? 'left-0' : 'right-0'
                      }`}
                    >
                      <div className="px-3 py-2 border-b border-gray-800">
                        <p className="text-[10px] text-gray-500 uppercase font-black tracking-wide">
                          {locale === 'ar' ? 'مـرحـبـاً بـك' : 'Connected'}
                        </p>
                        <p className="font-bold text-sm text-white max-w-[200px] truncate">{user.name}</p>
                        <p className="text-[10px] text-gray-500 font-mono truncate">{user.email || user.phone}</p>
                      </div>

                      <div className="py-1 space-y-0.5">
                        <button
                          onClick={() => {
                            setIsUserDropdownOpen(false);
                            navigate('settings');
                          }}
                          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-300 hover:bg-gray-900 transition-colors"
                          style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}
                        >
                          <Settings className="h-4 w-4 text-emerald-400" />
                          <span>{menuItems.settings}</span>
                        </button>

                        <button
                          onClick={() => {
                            setIsUserDropdownOpen(false);
                            navigate('wallet');
                          }}
                          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-300 hover:bg-gray-900 transition-colors"
                          style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}
                        >
                          <WalletIcon className="h-4 w-4 text-emerald-400" />
                          <span>{locale === 'ar' ? 'المحفظة الرقمية' : 'Digital Wallet'}</span>
                        </button>

                        {isAdminMode && (
                          <button
                            onClick={() => {
                              setIsUserDropdownOpen(false);
                              navigate('admin');
                            }}
                            className="flex w-full items-center gap-2 rounded-lg px-3 py-1.5 text-xs text-emerald-300 bg-emerald-950/20 hover:bg-emerald-950/40 transition-colors border border-emerald-900/30 font-bold"
                            style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}
                          >
                            <Settings className="h-4 w-4 text-emerald-400 shrink-0" />
                            <span>{locale === 'ar' ? 'لوحة تحكم المكتب' : 'Administration'}</span>
                          </button>
                        )}

                        <button
                          onClick={() => {
                            setIsUserDropdownOpen(false);
                            navigate('order-history');
                          }}
                          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-300 hover:bg-gray-900 transition-colors"
                          style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}
                        >
                          <Package className="h-4 w-4 text-emerald-400" />
                          <span>{menuItems.orders}</span>
                        </button>
                      </div>

                      <div className="border-t border-gray-800 pt-1">
                        <button
                          onClick={() => {
                            setIsUserDropdownOpen(false);
                            logout();
                          }}
                          className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-rose-450 hover:bg-rose-950/20 transition-colors cursor-pointer"
                          style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}
                        >
                          <LogOut className="h-4 w-4 text-rose-500" />
                          <span>{menuItems.logout}</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate('login')}
                  id="navbar-login-btn"
                  className="flex items-center gap-1.5 rounded-full bg-emerald-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-emerald-700 transition-all active:scale-95 cursor-pointer"
                >
                  <User className="h-3.5 w-3.5" />
                  <span>{menuItems.loginBtn}</span>
                </button>
              </div>
            )}

          </div>
        </div>
      </header>
    </>
  );
};
export default Navbar;
