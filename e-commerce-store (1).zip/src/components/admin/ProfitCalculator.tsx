import React from 'react';
import { DollarSign, Percent, PlusCircle, AlertTriangle, RefreshCw } from 'lucide-react';

interface ProfitCalculatorProps {
  basePrice: number;
  sellingPrice: number;
  onPriceChange: (newPrice: number, mode: 'fixed' | 'percentage' | 'fixed_markup', markupValue: number) => void;
  locale: 'ar' | 'en';
  onReset: () => void;
}

export const ProfitCalculator: React.FC<ProfitCalculatorProps> = ({
  basePrice,
  sellingPrice,
  onPriceChange,
  locale,
  onReset,
}) => {
  const [markupMode, setMarkupMode] = React.useState<'fixed' | 'percentage' | 'fixed_markup'>('fixed');
  const [markupVal, setMarkupVal] = React.useState<number>(0);

  const profit = parseFloat((sellingPrice - basePrice).toFixed(3));
  const margin = basePrice > 0 ? parseFloat(((profit / basePrice) * 100).toFixed(2)) : 0;

  React.useEffect(() => {
    // Sync markup value on mode changes
    if (markupMode === 'percentage') {
      const p = basePrice > 0 ? ((sellingPrice - basePrice) / basePrice) * 100 : 0;
      setMarkupVal(parseFloat(p.toFixed(2)));
    } else if (markupMode === 'fixed_markup') {
      setMarkupVal(parseFloat((sellingPrice - basePrice).toFixed(3)));
    }
  }, [markupMode, basePrice]);

  const t = {
    pricingMode: locale === 'ar' ? 'نمط تحديد الربح:' : 'Profit Margin Mode:',
    fixed: locale === 'ar' ? 'سعر مبيع ثابت (يدوي)' : 'Fixed Selling Price',
    percentage: locale === 'ar' ? 'نسبة مئوية مضافة (%)' : 'Percentage Markup (%)',
    fixed_markup: locale === 'ar' ? 'مبلغ ثابت مضاف (+USD)' : 'Fixed Margin Additive (+USD)',
    basePriceLabel: locale === 'ar' ? 'سعر التكلفة (من أورانوس):' : 'Oranos Base Price (Your Cost):',
    sellingPriceLabel: locale === 'ar' ? 'سعر البيع (للزبون):' : 'Selling Price (Customer):',
    markupValueLabel: locale === 'ar' ? 'قيمة الهامش المضاف:' : 'Applied Markup Value:',
    profitLabel: locale === 'ar' ? 'الربح المتوقع لكل وحدة:' : 'Estimated Unit Profit:',
    marginLabel: locale === 'ar' ? 'هامش الربح (%):' : 'Profit Margin (%):',
    dangerAlert: locale === 'ar' ? 'تحذير: لا يمكنك المبيع بأقل من سعر التكلفة!' : 'Warning: Selling price cannot be below cost price!',
    neutralAlert: locale === 'ar' ? 'تنبيه: الهامش مساوٍ للتكلفة تماماً - صفر أرباح.' : 'Notice: Selling price equals your cost. Margins are break-even (0% profit).',
    resetDefault: locale === 'ar' ? 'إعادة تعيين لأسعار أورانوس الافتراضية' : 'Reset to Oranos Defaults',
    profitIndicator: locale === 'ar' ? 'مؤشر ربحية المنتج:' : 'Profitability Diagnostics:',
    unit: 'USD',
  };

  const handleMarkupChange = (valStr: string) => {
    const val = parseFloat(valStr) || 0;
    setMarkupVal(val);
    
    if (markupMode === 'percentage') {
      const targetPrice = parseFloat((basePrice * (1 + val / 100)).toFixed(3));
      onPriceChange(targetPrice, 'percentage', val);
    } else if (markupMode === 'fixed_markup') {
      const targetPrice = parseFloat((basePrice + val).toFixed(3));
      onPriceChange(targetPrice, 'fixed_markup', val);
    }
  };

  const handlePriceChangeManual = (valStr: string) => {
    const val = parseFloat(valStr) || 0;
    onPriceChange(val, 'fixed', 0);
  };

  // Diagnostic colors
  const isLoss = sellingPrice < basePrice;
  const isZero = sellingPrice === basePrice;
  const isLow = margin < 5;
  const isHealthy = margin >= 10;

  const getStatusColor = () => {
    if (isLoss) return 'text-rose-400 bg-rose-950/20 border-rose-900/40';
    if (isZero) return 'text-amber-400 bg-amber-950/25 border-amber-900/40';
    if (isLow) return 'text-yellow-500 bg-yellow-950/20 border-yellow-900/30';
    if (isHealthy) return 'text-emerald-400 bg-emerald-950/20 border-emerald-900/40';
    return 'text-teal-400 bg-teal-950/20 border-teal-900/40'; // between 5% and 10%
  };

  return (
    <div className="space-y-4 bg-gray-950/20 p-4 rounded-xl border border-gray-870/50">
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-medium text-gray-400">{t.pricingMode}</label>
        <div className="grid grid-cols-3 gap-2" id="markup-mode-selector">
          <button
            type="button"
            onClick={() => setMarkupMode('fixed')}
            className={`py-2 px-2.5 text-xs font-semibold rounded-lg border transition-all ${
              markupMode === 'fixed'
                ? 'bg-emerald-600 border-emerald-500 text-white'
                : 'bg-gray-950/80 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900'
            }`}
          >
            {t.fixed}
          </button>
          <button
            type="button"
            onClick={() => setMarkupMode('percentage')}
            className={`py-2 px-2.5 text-xs font-semibold rounded-lg border transition-all ${
              markupMode === 'percentage'
                ? 'bg-emerald-600 border-emerald-500 text-white'
                : 'bg-gray-950/80 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900'
            }`}
          >
            {t.percentage}
          </button>
          <button
            type="button"
            onClick={() => setMarkupMode('fixed_markup')}
            className={`py-2 px-2.5 text-xs font-semibold rounded-lg border transition-all ${
              markupMode === 'fixed_markup'
                ? 'bg-emerald-600 border-emerald-500 text-white'
                : 'bg-gray-950/80 border-gray-800 text-gray-400 hover:text-white hover:bg-gray-900'
            }`}
          >
            {t.fixed_markup}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Base Price Display */}
        <div className="flex flex-col gap-1">
          <span className="text-xs text-gray-500 font-medium">{t.basePriceLabel}</span>
          <div className="flex items-center gap-1.5 p-2.5 bg-gray-950/80 border border-gray-800 rounded-lg select-all">
            <DollarSign className="h-4 w-4 text-gray-500" />
            <span className="text-sm font-mono font-bold text-gray-300">{basePrice.toFixed(3)}</span>
            <span className="text-[10px] text-gray-600 ml-auto font-mono uppercase">{t.unit}</span>
          </div>
        </div>

        {/* Input Field based on Mode */}
        {markupMode === 'fixed' ? (
          <div className="flex flex-col gap-1">
            <span className="text-xs text-gray-300 font-semibold">{t.sellingPriceLabel}</span>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-mono">$</span>
              <input
                type="number"
                step="0.001"
                value={sellingPrice || ''}
                onChange={(e) => handlePriceChangeManual(e.target.value)}
                className="w-full pl-7 pr-12 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg text-sm text-white font-mono"
                placeholder="0.000"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-gray-500 font-mono">USD</span>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-1">
            <span className="text-xs text-gray-300 font-semibold">{t.markupValueLabel}</span>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                {markupMode === 'percentage' ? <Percent className="h-3.5 w-3.5" /> : '$'}
              </span>
              <input
                type="number"
                step="0.01"
                value={markupVal || ''}
                onChange={(e) => handleMarkupChange(e.target.value)}
                className="w-full pl-7 pr-12 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg text-sm text-white font-mono"
                placeholder="0.00"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-gray-500 font-mono">
                {markupMode === 'percentage' ? '%' : 'USD'}
              </span>
            </div>
          </div>
        )}
      </div>

      {markupMode !== 'fixed' && (
        <div className="flex flex-col gap-1">
          <span className="text-xs text-gray-500 font-medium">{t.sellingPriceLabel}</span>
          <div className="flex items-center gap-1.5 p-2.5 bg-gray-900/30 border border-gray-800 rounded-lg">
            <DollarSign className="h-4 w-4 text-gray-400" />
            <span className="text-sm font-mono font-black text-white">{sellingPrice.toFixed(3)}</span>
            <span className="text-[10px] text-gray-500 ml-auto font-mono">USD (CALCULATED)</span>
          </div>
        </div>
      )}

      {/* Diagnostics Panel */}
      <div className={`p-3 rounded-lg border text-xs leading-relaxed transition-all ${getStatusColor()}`}>
        <div className="flex items-start gap-2">
          {isLoss ? (
            <AlertTriangle className="h-4 w-4 text-rose-500 shrink-0 mt-0.5" />
          ) : (
            <PlusCircle className="h-4 w-4 shrink-0 mt-0.5" />
          )}
          <div className="space-y-1">
            <p className="font-semibold">{t.profitIndicator}</p>
            <div className="flex items-center gap-4 font-mono text-xs font-bold">
              <span>{t.profitLabel} <strong className="text-lg font-black underline">${profit.toFixed(3)}</strong></span>
              <span>{t.marginLabel} <strong className="text-lg font-black underline">{margin.toFixed(2)}%</strong></span>
            </div>
            {isLoss && <p className="text-rose-400 font-bold mt-1.5">{t.dangerAlert}</p>}
            {isZero && <p className="text-amber-400 font-semibold mt-1.5">{t.neutralAlert}</p>}
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-1">
        <button
          type="button"
          onClick={onReset}
          className="flex items-center gap-2 py-1.5 px-3 bg-gray-950 hover:bg-gray-900 text-gray-400 hover:text-white border border-gray-800 rounded-lg text-xs transition-all font-semibold"
          id="pricing-reset-btn"
        >
          <RefreshCw className="h-3 w-3" />
          <span>{t.resetDefault}</span>
        </button>
      </div>
    </div>
  );
};
