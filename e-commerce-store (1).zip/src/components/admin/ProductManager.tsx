import React, { useState, useEffect } from 'react';
import { Search, Filter, Edit, Eye, EyeOff, CheckSquare, Trash2, ArrowUpDown, ChevronRight, Activity, Zap, RefreshCw } from 'lucide-react';
import { db } from '../../services/firebase';
import { collection, doc, deleteDoc, updateDoc, writeBatch } from 'firebase/firestore';
import { Product, Category } from '../../types';
import { ProductEditModal } from './ProductEditModal';

interface ProductManagerProps {
  products: Product[];
  categories: Category[];
  locale: 'ar' | 'en';
  showToast: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  onRefresh: () => void;
}

export const ProductManager: React.FC<ProductManagerProps> = ({
  products,
  categories,
  locale,
  showToast,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all'); // all, active, hidden, out_of_stock
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Bulk action selection IDs
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);

  // Filter products locally for table display
  const filteredProducts = products.filter((p) => {
    const matchesSearch = 
      (p.name_en || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.name_ar || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.id || '').toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || p.categoryId === selectedCategory;
    
    let matchesStatus = true;
    if (selectedStatus === 'active') {
      matchesStatus = p.isActive !== false;
    } else if (selectedStatus === 'hidden') {
      matchesStatus = p.isActive === false;
    } else if (selectedStatus === 'out_of_stock') {
      matchesStatus = p.status === 'out_of_stock' || !p.available;
    }

    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(filteredProducts.map((p) => p.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelectRow = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds((prev) => [...prev, id]);
    } else {
      setSelectedIds((prev) => prev.filter((item) => item !== id));
    }
  };

  // Bulk Actions
  const handleBulkToggleActive = async (targetActive: boolean) => {
    if (selectedIds.length === 0 || isBulkProcessing) return;
    setIsBulkProcessing(true);
    try {
      const batch = writeBatch(db);
      selectedIds.forEach((id) => {
        batch.update(doc(db, 'products', id), {
          isActive: targetActive,
          updatedAt: new Date().toISOString()
        });
      });
      await batch.commit();
      showToast(
        locale === 'ar'
          ? `تم تحديث حالة ${selectedIds.length} منتجات بنجاح!`
          : `Successfully toggled active status for ${selectedIds.length} products!`,
        'success'
      );
      setSelectedIds([]);
      onRefresh();
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsBulkProcessing(false);
    }
  };

  const handleBulkResetToApi = async () => {
    if (selectedIds.length === 0 || isBulkProcessing) return;
    setIsBulkProcessing(true);
    try {
      const batch = writeBatch(db);
      let count = 0;
      selectedIds.forEach((id) => {
        const p = products.find((item) => item.id === id);
        if (p && p.isOranosProduct) {
          const rawCost = p.oranosBasePrice || p.basePrice || 0;
          const defaultSelling = parseFloat((rawCost * 1.15).toFixed(3)); // 15% default markup
          
          batch.update(doc(db, 'products', id), {
            price: defaultSelling,
            sellingPrice: defaultSelling,
            discountPrice: defaultSelling,
            profitMargin: 15,
            profitAmount: parseFloat((defaultSelling - rawCost).toFixed(3)),
            useApiImage: true,
            coverImage: p.apiImage || '',
            name_en: p.name || p.name_en, // revert name overrides if applicable
            updatedAt: new Date().toISOString()
          });
          count++;
        }
      });
      await batch.commit();
      showToast(
        locale === 'ar'
          ? `تمت إعادة تهيئة ${count} منتجاً لمواصفات أورانوس الافتراضية`
          : `Successfully reverted ${count} products to Oranos defaults!`,
        'success'
      );
      setSelectedIds([]);
      onRefresh();
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsBulkProcessing(false);
    }
  };

  const handleSingleToggleActive = async (p: Product) => {
    const nextActive = p.isActive !== false ? false : true;
    try {
      await updateDoc(doc(db, 'products', p.id), {
        isActive: nextActive,
        updatedAt: new Date().toISOString()
      });
      showToast(
        locale === 'ar'
          ? `تم ${nextActive ? 'تفعيل' : 'إخفاء'} المنتج بنجاح`
          : `Product visibility successfully updated!`,
        'success'
      );
      onRefresh();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!window.confirm(locale === 'ar' ? "هل أنت متأكد من حذف هذا المنتج كلياً من قاعدة البيانات والمنصة رقمياً؟" : "Are you sure you want to permanently delete this product?")) {
      return;
    }
    try {
      await deleteDoc(doc(db, 'products', id));
      showToast(locale === 'ar' ? "تم حذف المنتج كليا" : "Product permanently deleted from Firestore Storefront.", "success");
      onRefresh();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const t = {
    searchPlaceholder: locale === 'ar' ? 'البحث عن منتج بالاسم أو المعرف...' : 'Search product by name, ID or Oranos ID...',
    allCats: locale === 'ar' ? 'كافة أقسام الألعاب' : 'All Categories',
    allStatus: locale === 'ar' ? 'كافة حالات العرض والظهور' : 'All Visibilities',
    statusActive: locale === 'ar' ? 'النشط والظاهر فقط' : 'Active & Visible Only',
    statusHidden: locale === 'ar' ? 'المخفي عن المعرض فقط' : 'Hidden & Disabled Only',
    statusOutOfStock: locale === 'ar' ? 'غير متوفر بالشبكة (أورانوس)' : 'Out of Stock (Oranos)',
    bulkLabel: locale === 'ar' ? 'العمليات الجماعية على المحدد:' : 'Bulk Actions on Selected:',
    bulkActive: locale === 'ar' ? 'تفعيل وتنشيط العرض' : 'Set Active & Visible',
    bulkInactive: locale === 'ar' ? 'إخفاء العرض وحجبه' : 'Set Inactive / Hide',
    bulkReset: locale === 'ar' ? 'إرجاع للقيم والأسعار الأساسية' : 'Revert to Oranos Defaults',
    tableProd: locale === 'ar' ? 'المنتج والنوع والمنشأ' : 'Product Information',
    tableCat: locale === 'ar' ? 'القسم' : 'Category',
    tableBase: locale === 'ar' ? 'سعر التكلفة' : 'Cost Cost',
    tableSelling: locale === 'ar' ? 'سعر البيع' : 'Selling Price',
    tableProfit: locale === 'ar' ? 'صافي الربح' : 'Profit Margin',
    tableStatus: locale === 'ar' ? 'العرض / أورانوس' : 'Status / Oranos',
    tableActions: locale === 'ar' ? 'التحكم' : 'Actions',
    oranosBadge: locale === 'ar' ? 'آلي (أورانوس)' : 'Oranos Integration',
    customBadge: locale === 'ar' ? 'مخصص محلي' : 'Manual product',
    inStock: locale === 'ar' ? 'متوفر' : 'In Stock',
    outStock: locale === 'ar' ? 'مقطوع' : 'Out of Stock',
    noProducts: locale === 'ar' ? 'لم يتم العثور على أية منتجات مطابقة للبحث' : 'No matching products found. Synchronize catalog to pull list.',
  };

  return (
    <div className="space-y-4">
      
      {/* Search and filter toolbar */}
      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 h-4.5 w-4.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full pl-10 pr-4 py-2 bg-gray-950 border border-gray-800 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>

        <div className="flex flex-wrap gap-2.5">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-gray-950 border border-gray-800 p-2 rounded-xl text-xs text-white"
          >
            <option value="all">{t.allCats}</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {locale === 'ar' ? c.name_ar : c.name_en}
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-gray-950 border border-gray-800 p-2 rounded-xl text-xs text-white"
          >
            <option value="all">{t.allStatus}</option>
            <option value="active">{t.statusActive}</option>
            <option value="hidden">{t.statusHidden}</option>
            <option value="out_of_stock">{t.statusOutOfStock}</option>
          </select>
        </div>
      </div>

      {/* Bulk action action bar */}
      {selectedIds.length > 0 && (
        <div className="bg-emerald-950/20 border border-emerald-800/40 p-3 rounded-xl flex flex-wrap items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckSquare className="h-5 w-5 text-emerald-400" />
            <span className="text-xs text-emerald-400 font-bold">
              {locale === 'ar' 
                ? `تم تحديد (${selectedIds.length}) منتجات من الجدول:` 
                : `Selected (${selectedIds.length}) products:`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleBulkToggleActive(true)}
              disabled={isBulkProcessing}
              className="py-1 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition"
            >
              {t.bulkActive}
            </button>
            <button
              onClick={() => handleBulkToggleActive(false)}
              disabled={isBulkProcessing}
              className="py-1 px-3 bg-gray-900 border border-gray-850 hover:bg-rose-950/20 text-gray-400 hover:text-rose-400 rounded-lg text-xs transition"
            >
              {t.bulkInactive}
            </button>
            <button
              onClick={handleBulkResetToApi}
              disabled={isBulkProcessing}
              className="py-1 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition"
              id="bulk-reset-to-api-btn"
            >
              {t.bulkReset}
            </button>
          </div>
        </div>
      )}

      {/* Main product table */}
      <div className="border border-gray-800 bg-gray-900/40 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-950/60 text-[11px] uppercase tracking-wider text-gray-400 font-bold border-b border-gray-800">
                <th className="py-3.5 px-4 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={selectedIds.length > 0 && selectedIds.length === filteredProducts.length}
                    onChange={handleSelectAll}
                    className="accent-emerald-500 h-4 w-4"
                  />
                </th>
                <th className="py-3.5 px-4">{t.tableProd}</th>
                <th className="py-3.5 px-4">{t.tableCat}</th>
                <th className="py-3.5 px-4 text-center">{t.tableBase}</th>
                <th className="py-3.5 px-4 text-center">{t.tableSelling}</th>
                <th className="py-3.5 px-4 text-center">{t.tableProfit}</th>
                <th className="py-3.5 px-4 text-center">{t.tableStatus}</th>
                <th className="py-3.5 px-4 text-center">{t.tableActions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800 text-xs text-gray-300">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-gray-500 font-medium">
                    {t.noProducts}
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => {
                  const bCost = p.basePrice || 0;
                  const sPrice = p.sellingPrice || p.price || 0;
                  const unitProfit = p.profitAmount !== undefined ? p.profitAmount : (sPrice - bCost);
                  const pMargin = p.profitMargin !== undefined ? p.profitMargin : (bCost > 0 ? ((sPrice - bCost) / bCost) * 100 : 0);

                  const marginColor = pMargin < 5 ? 'text-rose-400 bg-rose-950/20' : pMargin >= 10 ? 'text-emerald-400 bg-emerald-950/20' : 'text-yellow-500 bg-yellow-950/20';

                  return (
                    <tr 
                      key={p.id} 
                      className={`hover:bg-gray-950/30 transition-colors ${
                        selectedIds.includes(p.id) ? 'bg-emerald-950/5' : ''
                      }`}
                    >
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={selectedIds.includes(p.id)}
                          onChange={(e) => handleSelectRow(p.id, e.target.checked)}
                          className="accent-emerald-500 h-4 w-4"
                        />
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg overflow-hidden border border-gray-800 shrink-0 bg-gray-950">
                            <img src={p.coverImage || p.image} alt={p.name_en} className="w-full h-full object-cover" />
                          </div>
                          <div className="flex flex-col min-w-0">
                            <span className="font-bold text-white truncate" dir="auto">
                              {locale === 'ar' ? p.name_ar : p.name_en}
                            </span>
                            <span className="text-[10px] text-gray-500 font-mono mt-0.5 uppercase truncate tracking-tight">
                              ID: {p.id.replace('oranos_', '')}
                            </span>
                            <div className="flex items-center gap-1.5 mt-1">
                              {p.isOranosProduct ? (
                                <span className="px-1.5 py-0.2 bg-indigo-950 border border-indigo-900 text-indigo-400 text-[8px] font-extrabold rounded-md select-none lowercase">
                                  {t.oranosBadge}
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.2 bg-gray-950 border border-gray-800 text-gray-500 text-[8px] font-semibold rounded-md select-none">
                                  {t.customBadge}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 text-gray-400 font-semibold">
                        {p.categoryId.replace('oranos_cat_', '').replace(/_/g, ' ')}
                      </td>

                      <td className="py-3 px-4 text-center font-mono font-bold text-gray-500">
                        ${bCost.toFixed(3)}
                      </td>

                      <td className="py-3 px-4 text-center font-mono font-extrabold text-white">
                        ${sPrice.toFixed(3)}
                      </td>

                      <td className="py-3 px-4 text-center font-mono">
                        <div className={`inline-flex flex-col py-1 px-1.5 rounded-lg border text-[10px] font-bold ${marginColor}`}>
                          <span>+${unitProfit.toFixed(2)}</span>
                          <span className="text-[8.5px] opacity-80">{pMargin.toFixed(1)}%</span>
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex flex-col items-center gap-1">
                          {p.isActive !== false ? (
                            <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-900 text-emerald-400 text-[9px] rounded-full font-bold select-none">
                              {locale === 'ar' ? 'ظاهر للعملاء' : 'Active'}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-rose-950 border border-rose-950 text-rose-400 text-[9px] rounded-full font-bold select-none text-center">
                              {locale === 'ar' ? 'مخفي' : 'Hidden'}
                            </span>
                          )}

                          {p.available ? (
                            <span className="text-[9px] text-emerald-400 font-bold select-none flex items-center gap-1">
                              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                              {t.inStock}
                            </span>
                          ) : (
                            <span className="text-[9px] text-rose-400 font-bold select-none flex items-center gap-1">
                              <span className="h-1.5 w-1.5 rounded-full bg-rose-500" />
                              {t.outStock}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingProduct(p)}
                            className="p-1 px-2.5 bg-gray-950 hover:bg-emerald-600/10 text-gray-400 hover:text-emerald-400 border border-gray-800 rounded-lg transition"
                            title="Edit Product Details"
                            id={`edit-prod-row-${p.id}`}
                          >
                            <Edit className="h-4 w-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => handleSingleToggleActive(p)}
                            className={`p-1 px-1.5 rounded-lg border transition ${
                              p.isActive !== false
                                ? 'bg-gray-950 hover:bg-rose-950/20 text-gray-500 hover:text-rose-400 border-gray-800'
                                : 'bg-gray-950 hover:bg-emerald-950/20 text-emerald-400 border-gray-800'
                            }`}
                            title="Toggle Visibility"
                          >
                            {p.isActive !== false ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-1 px-1.5 bg-gray-950 hover:bg-rose-950/30 text-gray-500 hover:text-rose-400 border border-gray-800 rounded-lg transition"
                            title="Delete Permanently"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit modal pop-over */}
      {editingProduct && (
        <ProductEditModal
          product={editingProduct}
          categories={categories}
          locale={locale}
          onClose={() => setEditingProduct(null)}
          onSave={() => {
            onRefresh();
            setEditingProduct(null);
          }}
          showToast={showToast}
        />
      )}
    </div>
  );
};
