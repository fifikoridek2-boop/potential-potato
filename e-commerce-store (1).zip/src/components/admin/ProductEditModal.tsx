import React, { useState, useEffect } from 'react';
import { X, Image as ImageIcon, Check, RefreshCw, AlertCircle, Cpu, Calendar, Tag, ChevronDown, ChevronUp } from 'lucide-react';
import { db } from '../../services/firebase';
import { collection, doc, updateDoc, setDoc, getDocs, query, where, writeBatch } from 'firebase/firestore';
import { Product, Category } from '../../types';
import { ImageUploader } from '../ImageUploader';
import { ProfitCalculator } from './ProfitCalculator';

interface ProductEditModalProps {
  product: Product;
  categories: Category[];
  locale: 'ar' | 'en';
  onClose: () => void;
  onSave: (updatedProduct: Product) => void;
  showToast: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}

export const ProductEditModal: React.FC<ProductEditModalProps> = ({
  product,
  categories,
  locale,
  onClose,
  onSave,
  showToast,
}) => {
  // Local state
  const [nameEn, setNameEn] = useState(product.name_en || '');
  const [nameAr, setNameAr] = useState(product.name_ar || '');
  const [descEn, setDescEn] = useState(product.description_en || '');
  const [descAr, setDescAr] = useState(product.description_ar || '');
  const [categoryId, setCategoryId] = useState(product.categoryId || '');
  const [isActive, setIsActive] = useState(product.isActive !== false);
  
  // Pricing
  const [basePrice, setBasePrice] = useState(product.basePrice || 0);
  const [sellingPrice, setSellingPrice] = useState(product.sellingPrice || product.price || 0);
  const [discountPrice, setDiscountPrice] = useState(product.discountPrice || product.price || 0);
  const [pricingMode, setPricingMode] = useState<'fixed' | 'percentage' | 'fixed_markup'>('fixed');
  const [markupValue, setMarkupValue] = useState<number>(0);

  // Images
  const [useApiImage, setUseApiImage] = useState(product.useApiImage !== false);
  const [customImage, setCustomImage] = useState(product.customImage || '');
  const [apiImage] = useState(product.apiImage || product.image || '');

  // Tech / Raw Viewer
  const [showRawJson, setShowRawJson] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Detect base price discrepancy alerts
  const [priceMismatch, setPriceMismatch] = useState(false);

  useEffect(() => {
    // Check if original Oranos cost differs from the cached local base price
    if (product.oranosBasePrice && product.basePrice && product.oranosBasePrice !== product.basePrice) {
      setPriceMismatch(true);
    }
  }, [product]);

  // Handle pricing calculator updates
  const handlePriceChange = (newPrice: number, mode: 'fixed' | 'percentage' | 'fixed_markup', markupVal: number) => {
    setSellingPrice(newPrice);
    setPricingMode(mode);
    setMarkupValue(markupVal);
  };

  const resetToDefaults = () => {
    const rawCost = product.oranosBasePrice || product.basePrice || 0;
    setBasePrice(rawCost);
    // standard 15% default markup behavior
    const defSelling = parseFloat((rawCost * 1.15).toFixed(3));
    setSellingPrice(defSelling);
    setPricingMode('fixed');
    setMarkupValue(0);
    showToast(locale === 'ar' ? 'تمت استعادة الأسعار والاتساقات الافتراضية' : 'Restored pricing parameters to Oranos defaults', 'info');
  };

  // Heavy duty: Apply currently modeled markup mode/percentage to ALL products in this category
  const applyPriceToAllInCategory = async () => {
    if (isSaving) return;
    setIsSaving(true);
    try {
      const q = query(collection(db, 'products'), where('categoryId', '==', categoryId));
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        showToast(locale === 'ar' ? 'لم يتم العثور على منتجات أخرى في هذا القسم' : 'No other products found in this category', 'warning');
        setIsSaving(false);
        return;
      }

      const batch = writeBatch(db);
      let updatedCount = 0;

      snapshot.docs.forEach((docSnap) => {
        const prodData = docSnap.data();
        const itemBasePrice = prodData.basePrice || prodData.price || 0;
        let itemSellingPrice = itemBasePrice;

        if (pricingMode === 'percentage') {
          itemSellingPrice = parseFloat((itemBasePrice * (1 + markupValue / 100)).toFixed(3));
        } else if (pricingMode === 'fixed_markup') {
          itemSellingPrice = parseFloat((itemBasePrice + markupValue).toFixed(3));
        } else {
          // If fixed mode, set to exact selling price value
          itemSellingPrice = sellingPrice;
        }

        // Validate ≥ basePrice
        if (itemSellingPrice >= itemBasePrice) {
          batch.update(docSnap.ref, {
            price: itemSellingPrice,
            sellingPrice: itemSellingPrice,
            discountPrice: itemSellingPrice,
            profitMargin: itemBasePrice > 0 ? parseFloat((((itemSellingPrice - itemBasePrice) / itemBasePrice) * 100).toFixed(2)) : 0,
            profitAmount: parseFloat((itemSellingPrice - itemBasePrice).toFixed(3)),
            updatedAt: new Date().toISOString()
          });
          updatedCount++;
        }
      });

      await batch.commit();
      showToast(
        locale === 'ar' 
          ? `تم تطبيق استراتيجية التسعير على ${updatedCount} منتجاً بالقسم بنجاح!` 
          : `Successfully applied pricing strategy to all ${updatedCount} items in this category!`, 
        'success'
      );
    } catch (err: any) {
      showToast(locale === 'ar' ? `خطأ أثناء تطبيق التسعير الجماعي: ${err.message}` : `Error applying bulk pricing: ${err.message}`, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveProduct = async () => {
    if (sellingPrice < basePrice) {
      showToast(locale === 'ar' ? 'سعر البيع لا يمكن أن يكون أقل من سعر التكلفة!' : 'Selling price cannot be less than your base cost.', 'error');
      return;
    }

    setIsSaving(true);

    const calculatedProfit = parseFloat((sellingPrice - basePrice).toFixed(3));
    const calculatedMargin = basePrice > 0 ? parseFloat(((calculatedProfit / basePrice) * 100).toFixed(2)) : 0;
    const finalCoverImg = useApiImage ? apiImage : (customImage || apiImage);

    const updated: Product = {
      ...product,
      name_en: nameEn,
      name_ar: nameAr,
      description_en: descEn,
      description_ar: descAr,
      categoryId,
      isActive,
      basePrice,
      sellingPrice,
      price: sellingPrice, // compatibility fallback
      discountPrice: discountPrice || sellingPrice,
      profitAmount: calculatedProfit,
      profitMargin: calculatedMargin,
      useApiImage,
      customImage,
      coverImage: finalCoverImg,
      updatedAt: new Date().toISOString()
    };

    try {
      await setDoc(doc(db, 'products', product.id), updated, { merge: true });
      onSave(updated);
      showToast(locale === 'ar' ? 'تم حفظ المنتج بنجاح' : 'Product successfully saved & indexed!', 'success');
      onClose();
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const t = {
    title: locale === 'ar' ? 'تعديل بيانات المنتج والمزود' : 'Edit Product & Provider Integration',
    genTab: locale === 'ar' ? 'البيانات العامة والوصف' : 'General & Descriptions',
    pricingTab: locale === 'ar' ? 'التسعير وهامش الربح' : 'Pricing & Profit Margins',
    imageTab: locale === 'ar' ? 'الصور والأيقونات' : 'Visual Assets & Images',
    oranosTab: locale === 'ar' ? 'بيانات أورانوس التقنية' : 'Oranos Technical Payload',
    nameEn: 'Product Name (English)',
    nameAr: 'اسم المنتج (بالعربية)',
    descEn: 'Marketing Description (English)',
    descAr: 'الوصف التسويقي والتوضيحات (بالعربية)',
    category: locale === 'ar' ? 'القسم / اللعبة:' : 'Associated Category:',
    statusToggle: locale === 'ar' ? 'الظهور للزبائن (نشط):' : 'Active Status (Visible to customers):',
    active: locale === 'ar' ? 'نشط وقابل للشراء' : 'Active & Available to purchase',
    inactive: locale === 'ar' ? 'مخفي' : 'Hidden from layout',
    saveBtn: locale === 'ar' ? 'حفظ البيانات والتعديلات' : 'Save Changes & Index',
    cancel: locale === 'ar' ? 'إلغاء' : 'Close',
    oranosId: locale === 'ar' ? 'معرف المنتج بأورانوس:' : 'Oranos ID:',
    prodType: locale === 'ar' ? 'نوع المنتج:' : 'Product Format:',
    qtyRules: locale === 'ar' ? 'ضوابط الكميات المتاحة ومستوياتها:' : 'Quantity Rules & Permitted Ranges:',
    reqFields: locale === 'ar' ? 'الحقول والمتطلبات الفورية المطلوبة من العميل:' : 'Required Player Verification Parameters:',
    syncedAt: locale === 'ar' ? 'تاريخ المزامنة الآلية الأخيرة:' : 'Last Catalog Sync Timestamp:',
    applyAllBtn: locale === 'ar' ? 'تطبيق هذا النموذج السعري على كافة منتجات القسم' : 'Apply pricing formula to all category products',
    useApiImg: locale === 'ar' ? 'استخدام صورة أورانوس الرسمية المرفقة' : 'Use Official Oranos API Picture',
    uploadCustom: locale === 'ar' ? 'رفع وتجهيز صورة مخصصة مربعة' : 'Upload custom 1:1 image override',
    sideCompare: locale === 'ar' ? 'مقارنة الصور التنافسية:' : 'Side-by-side Visual Options Comparison:',
    apiImgLabel: locale === 'ar' ? 'صورة أورانوس الافتراضية' : 'Default Oranos Image',
    customImgLabel: locale === 'ar' ? 'الصورة المخصصة للـموقع' : 'Your Custom Image',
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-gray-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="relative bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl"
        id="edit-product-modal-container"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-gray-950/60 shrink-0">
          <div className="flex items-center gap-2.5">
            <Cpu className="h-5 w-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white tracking-tight">{t.title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 px-2.5 rounded-lg bg-gray-950 hover:bg-rose-800/15 text-gray-500 hover:text-rose-400 border border-gray-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mismatch warnings */}
        {priceMismatch ? (
          <div className="bg-amber-950/20 border-b border-amber-900/50 p-3 px-4 text-xs text-amber-400 flex items-center gap-2.5 shrink-0">
            <AlertCircle className="h-4 w-4 shrink-0 text-amber-500" />
            <p>
              {locale === 'ar'
                ? `انتباه! تغير سعر التكلفة الأصلي بأورانوس من ($${product.basePrice}) إلى ($${product.oranosBasePrice}). يرجى إعادة مراجعة مبيعاتك للحفاظ على ربحك.`
                : `Cost Discrepancy! Oranos cost changed from $${product.basePrice} to $${product.oranosBasePrice}. Re-calculate pricing to protect your profits.`}
            </p>
          </div>
        ) : null}

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* General Info & Fields */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <Tag className="h-4 w-4 text-emerald-500" />
                <span>{t.genTab}</span>
              </h4>
              
              <div className="grid grid-cols-1 gap-4 bg-gray-950/20 p-4 rounded-xl border border-gray-870/50">
                <div className="flex flex-col gap-1">
                  <span className="text-xs font-semibold text-gray-400">{t.nameAr}</span>
                  <input
                    type="text"
                    value={nameAr}
                    onChange={(e) => setNameAr(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg text-sm text-white"
                    dir="rtl"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <span className="text-xs font-semibold text-gray-400">{t.nameEn}</span>
                  <input
                    type="text"
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg text-sm text-white"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <span className="text-xs font-semibold text-gray-400">{t.descAr}</span>
                  <textarea
                    rows={2}
                    value={descAr}
                    onChange={(e) => setDescAr(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <span className="text-xs font-semibold text-gray-400">{t.descEn}</span>
                  <textarea
                    rows={2}
                    value={descEn}
                    onChange={(e) => setDescEn(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg text-xs text-white"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <span className="text-xs font-semibold text-gray-400">{t.category}</span>
                    <select
                      value={categoryId}
                      onChange={(e) => setCategoryId(e.target.value)}
                      className="w-full px-3 py-2 bg-gray-950 border border-gray-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-lg text-xs text-white"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.id}>
                          {locale === 'ar' ? c.name_ar : c.name_en}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="text-xs font-semibold text-gray-400">{t.statusToggle}</span>
                    <button
                      type="button"
                      onClick={() => setIsActive(!isActive)}
                      className={`w-full py-2 px-3 text-xs font-bold rounded-lg border text-center transition-all ${
                        isActive 
                          ? 'bg-emerald-950/30 border-emerald-800 text-emerald-400' 
                          : 'bg-rose-950/30 border-rose-950 text-rose-400'
                      }`}
                    >
                      {isActive ? t.active : t.inactive}
                    </button>
                  </div>
                </div>
              </div>

              {/* Collapsible raw data container */}
              <div className="border border-gray-800 rounded-xl bg-gray-950/40 overflow-hidden">
                <button
                  type="button"
                  onClick={() => setShowRawJson(!showRawJson)}
                  className="w-full py-2 px-3 flex items-center justify-between text-xs text-gray-400 hover:text-white transition-all hover:bg-gray-950/60"
                >
                  <span className="font-bold flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5 text-indigo-400" />
                    {t.oranosTab}
                  </span>
                  {showRawJson ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </button>
                {showRawJson && (
                  <div className="p-3 border-t border-gray-850">
                    <div className="grid grid-cols-2 gap-4 text-xs font-mono text-gray-400 mb-3 leading-loose">
                      <div>
                        <p>{t.oranosId} <strong className="text-white">{product.oranosProductId || 'N/A'}</strong></p>
                        <p>{t.prodType} <strong className="text-white uppercase">{product.productType || 'N/A'}</strong></p>
                      </div>
                      <div>
                        <p>{t.syncedAt}</p>
                        <p className="text-white text-[10px]">{product.lastSyncedAt ? new Date(product.lastSyncedAt).toLocaleString() : 'N/A'}</p>
                      </div>
                    </div>
                    
                    <div className="text-[11px] font-semibold text-gray-500 uppercase tracking-widest mb-1">{t.qtyRules}</div>
                    <pre className="p-2 border border-gray-800 bg-black text-rose-400 rounded text-[9.5px] max-h-24 overflow-auto font-mono mb-3">
                      {JSON.stringify(product.qtyValues || null, null, 2)}
                    </pre>

                    <div className="text-[11px] font-semibold text-gray-500 uppercase tracking-widest mb-1">{t.reqFields}</div>
                    <div className="flex flex-wrap gap-1.5">
                      {(product.params || ["ادخل الايدي الاعب"]).map((p, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-indigo-950/50 border border-indigo-900 text-indigo-300 text-[10px] rounded-full font-bold">
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Pricing Section */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                <ImageIcon className="h-4 w-4 text-emerald-500" />
                <span>{t.pricingTab}</span>
              </h4>

              {/* Embedded Profit Calculator */}
              <ProfitCalculator
                basePrice={basePrice}
                sellingPrice={sellingPrice}
                onPriceChange={handlePriceChange}
                locale={locale}
                onReset={resetToDefaults}
              />

              <button
                type="button"
                disabled={isSaving}
                onClick={applyPriceToAllInCategory}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-indigo-950/40 hover:bg-indigo-950/80 text-indigo-400 hover:text-white border border-indigo-900 rounded-xl text-xs transition-all font-bold"
                id="apply-category-prices-btn"
              >
                <Check className="h-3.5 w-3.5" />
                <span>{t.applyAllBtn}</span>
              </button>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-gray-850">
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <ImageIcon className="h-4 w-4 text-emerald-500" />
              <span>{t.imageTab}</span>
            </h4>

            {/* API vs Custom Image toggles */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-950/20 p-4 rounded-xl border border-gray-870/50">
              <div className="space-y-4">
                <div className="flex flex-col gap-1.5">
                  <span className="text-xs text-gray-400 font-semibold">Image Source Strategy</span>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 text-xs font-bold text-gray-300 cursor-pointer select-none">
                      <input
                        type="radio"
                        checked={useApiImage}
                        onChange={() => setUseApiImage(true)}
                        className="accent-emerald-500 h-4 w-4"
                      />
                      <span>{t.useApiImg}</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-bold text-gray-300 cursor-pointer select-none">
                      <input
                        type="radio"
                        checked={!useApiImage}
                        onChange={() => setUseApiImage(false)}
                        className="accent-emerald-500 h-4 w-4"
                      />
                      <span>{t.uploadCustom}</span>
                    </label>
                  </div>
                </div>

                {!useApiImage && (
                  <ImageUploader
                    value={customImage}
                    onChange={(b64) => setCustomImage(b64)}
                    locale={locale}
                  />
                )}
              </div>

              {/* Side by side comparison */}
              <div className="space-y-2">
                <span className="text-xs text-gray-500 font-medium">{t.sideCompare}</span>
                <div className="flex gap-4 p-3 bg-black/40 rounded-lg border border-gray-850 items-center justify-center">
                  <div className="flex flex-col items-center gap-1.5">
                    <div className="w-24 h-24 border border-gray-800 rounded bg-gray-900 overflow-hidden flex items-center justify-center">
                      {apiImage ? (
                        <img src={apiImage} className="w-full h-full object-cover" alt="Api" />
                      ) : (
                        <ImageIcon className="h-6 w-6 text-gray-700" />
                      )}
                    </div>
                    <span className="text-[10px] text-gray-500 font-bold">{t.apiImgLabel}</span>
                  </div>

                  <div className="text-gray-600 font-extrabold text-sm">VS</div>

                  <div className="flex flex-col items-center gap-1.5">
                    <div className="w-24 h-24 border border-gray-850 rounded bg-gray-900 overflow-hidden flex items-center justify-center">
                      {customImage ? (
                        <img src={customImage} className="w-full h-full object-cover" alt="Custom" />
                      ) : (
                        <div className="flex items-center justify-center w-full h-full bg-gray-950 text-gray-800 text-[10px] text-center p-2 font-mono">
                          NO OVERRIDE
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] text-emerald-500 font-bold">{t.customImgLabel}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Controls Footer */}
        <div className="flex justify-end gap-3 p-4 border-t border-gray-800 bg-gray-950/60 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gray-900 border border-gray-800 hover:bg-gray-850 text-gray-400 hover:text-white rounded-lg text-xs transition"
          >
            {t.cancel}
          </button>
          
          <button
            type="button"
            disabled={isSaving}
            onClick={handleSaveProduct}
            className="flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition shadow-lg shadow-emerald-900/10 disabled:opacity-50"
            id="modal-save-product-btn"
          >
            {isSaving ? <RefreshCw className="h-4 w-4 animate-spin" /> : null}
            <span>{t.saveBtn}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
