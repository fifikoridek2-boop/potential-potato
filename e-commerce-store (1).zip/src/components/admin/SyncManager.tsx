import React, { useState, useEffect } from 'react';
import { db } from '../../services/firebase';
import { collection, getDocs, query, orderBy, limit } from 'firebase/firestore';
import { Database, RefreshCw, Key, ShieldCheck, CheckCircle2, AlertTriangle, Clock, Server, Eye, EyeOff } from 'lucide-react';

interface SyncLog {
  id: string;
  timestamp: string;
  productsSynced: number;
  categoriesSynced: number;
  newProducts: number;
  priceChanges: number;
  unavailableProducts: number;
  duration: number;
  errors?: string[];
}

interface SyncManagerProps {
  locale: 'ar' | 'en';
  showToast: (msg: string, type: 'success' | 'error' | 'info' | 'warning') => void;
  syncOranosCatalog: () => Promise<any>;
  updateOranosConfig: (apiToken: string) => Promise<any>;
  getOranosConfig: () => Promise<any>;
  onRefreshProducts: () => void;
}

export const SyncManager: React.FC<SyncManagerProps> = ({
  locale,
  showToast,
  syncOranosCatalog,
  updateOranosConfig,
  getOranosConfig,
  onRefreshProducts,
}) => {
  const [tokenInput, setTokenInput] = useState('');
  const [isTokenMasked, setIsTokenMasked] = useState(true);
  const [verifiedEnvLine, setVerifiedEnvLine] = useState('');
  const [connectionState, setConnectionState] = useState<{
    configured: boolean;
    ok: boolean;
    balance: string;
    email: string;
    message?: string;
  } | null>(null);

  const [syncLogs, setSyncLogs] = useState<SyncLog[]>([]);
  const [isConfiguring, setIsConfiguring] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);

  // Fetch Oranos server credentials connection
  const fetchConnection = async () => {
    try {
      const res = await getOranosConfig();
      setConnectionState(res);
      // Do not auto-populate tokenInput with any maskedToken format
    } catch (err: any) {
      console.error(err);
    }
  };

  // Fetch Firestore Audit logs
  const fetchSyncLogs = async () => {
    setIsLoadingLogs(true);
    try {
      const q = query(collection(db, 'syncLogs'), orderBy('timestamp', 'desc'), limit(15));
      const snap = await getDocs(q);
      const logsList: SyncLog[] = [];
      snap.forEach((doc) => {
        logsList.push(doc.data() as SyncLog);
      });
      setSyncLogs(logsList);
    } catch (err) {
      console.error("Failed to fetch syncLogs logs:", err);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  useEffect(() => {
    fetchConnection();
    fetchSyncLogs();
  }, []);

  const handleSaveToken = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenInput.trim() || isConfiguring) return;
    if (tokenInput.trim().length < 10) {
      showToast(
        locale === 'ar' ? 'الرجاء إدخال التوكن كاملاً (لا يقل عن 10 رموز)' : 'Please enter the full token (minimum 10 characters)',
        'error'
      );
      return;
    }
    setIsConfiguring(true);
    setVerifiedEnvLine('');
    try {
      const res = await updateOranosConfig(tokenInput.trim());
      if (res && res.success) {
        if (res.envLine) {
          setVerifiedEnvLine(res.envLine);
        }
        showToast(
          locale === 'ar' 
            ? 'تم التحقق من التوكن بنجاح! انسخ السطر الظاهر وضعه في ملف .env' 
            : 'Token verified! Copy the displayed line and add it to your .env file.', 
          'success'
        );
        fetchConnection();
      }
    } catch (err: any) {
      showToast(
        locale === 'ar'
          ? `المصادقة فشلت: ${err.message || err}`
          : `Validation failed: ${err.message || err}`,
        'error'
      );
    } finally {
      setIsConfiguring(false);
    }
  };

  const handleTriggerSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    showToast(
      locale === 'ar' ? 'بدء سحب المنتجات ومزامنتها من مزود أورانوس...' : 'Sync in progress: Contacting Oranos catalog endpoints...',
      'info'
    );
    try {
      const res = await syncOranosCatalog();
      if (res && res.success) {
        showToast(
          locale === 'ar'
            ? `اكتملت المزامنة الآلية بنجاح! تم مسح ${res.productsSynced} منتج بالدليل الكلي.`
            : `Sync completed! Catalog synchronized successfully. Synced: ${res.productsSynced} products.`,
          'success'
        );
        onRefreshProducts();
        fetchSyncLogs();
      } else {
        showToast(res?.error || 'Sync failed', 'error');
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  const t = {
    settingsTitle: locale === 'ar' ? 'تهيئة الاتصال ومزود الخدمة (Oranos)' : 'Oranos Provider Connection Credentials',
    tokenLabel: locale === 'ar' ? 'رمز الوصول البرمجي للـ API (api-token):' : 'Oranos API ACCESS Token:',
    saveBtn: locale === 'ar' ? 'التحقق من صحة التوكن' : 'Verify Oranos API Token',
    syncTitle: locale === 'ar' ? 'مشغلات المزامنة اليدوية للمنتجات' : 'Manual Catalog Synchronizers',
    syncDesc: locale === 'ar' ? 'بإمكانك المزامنة الفورية لمسح منتجات أورانوس، وتعديل الأسعار الأساسية، تجميد أو توفير بطاقات الألعاب آلياً دون تشويش أسعار المبيعات الخاصة بك.' : 'Pull fresh listings, update base costs, handle structural quantity constraints, and sync category images instantly without overwriting your selling price modifiers.',
    syncBtn: locale === 'ar' ? 'مزامنة الكتالوج الآن' : 'Trigger Sync Products Catalog',
    logsTitle: locale === 'ar' ? 'سجل عمليات المزامنة التاريخية (أول 15 عملية)' : 'Synchronization Audit Trails (Last 15)',
    noLogs: locale === 'ar' ? 'لا توجد أية عمليات مزامنة سابقة مسجلة' : 'No previous sync history audits are currently recorded.',
    time: locale === 'ar' ? 'التاريخ والوقت' : 'Timestamp',
    connected: locale === 'ar' ? 'متصل ومصادق بنجاح' : 'Secure API Access Authorized',
    notConnected: locale === 'ar' ? 'غير متصل (التوكن غير معرف)' : 'Missing Configuration / Not Connected',
    masked: '••••••••••••••••••••••••••••••••',
    syncedItems: locale === 'ar' ? 'منتجات أورانوس الكلية:' : 'Total Items Synced:',
    newProds: locale === 'ar' ? 'المنتجات الجديدة:' : 'New Additions:',
    priceDiff: locale === 'ar' ? 'تغيرات أسعار التكلفة:' : 'Price Modifications:',
    unavail: locale === 'ar' ? 'منتجات معطلة:' : 'Unavailable (Disabled):',
    duration: locale === 'ar' ? 'مدة التنفيذ الكلية:' : 'Execution Time:',
    logId: locale === 'ar' ? 'معرف العملية:' : 'Log Stamp ID:',
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="sync-manager-container">
      
      {/* Configuration & Action buttons (Left Panel) */}
      <div className="lg:col-span-5 space-y-6">
        
        {/* Token Form Card */}
        <div className="bg-gray-900 border border-gray-800 p-5 rounded-2xl shadow-sm space-y-4">
          <div className="flex items-center gap-2.5">
            <Key className="h-5 w-5 text-indigo-400" />
            <h3 className="font-bold text-white text-sm tracking-tight">{t.settingsTitle}</h3>
          </div>

          <form onSubmit={handleSaveToken} className="space-y-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-gray-400 font-semibold">{t.tokenLabel}</label>
              <div className="relative">
                <input
                  type={isTokenMasked ? "password" : "text"}
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 focus:border-emerald-500 rounded-lg py-2 px-3 pl-10 pr-9 text-xs text-white tracking-widest font-mono"
                  placeholder="Insert Oranos API-Token key..."
                  dir="ltr"
                />
                <button
                  type="button"
                  onClick={() => setIsTokenMasked(!isTokenMasked)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition"
                >
                  {isTokenMasked ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isConfiguring}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition disabled:opacity-50 font-semibold"
            >
              {isConfiguring ? <RefreshCw className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
              <span>{t.saveBtn}</span>
            </button>
          </form>

          {verifiedEnvLine && (
            <div className="bg-emerald-950/20 border border-emerald-900/50 p-4 rounded-xl text-xs space-y-2 mt-2">
              <p className="font-bold text-emerald-400">
                {locale === 'ar' 
                  ? '⚡ تم التحقق من الرمز بنجاح! انسخ هذا السجل والْصَقْه في حزمة المتغيرات البيئية .env الخاصة بك:' 
                  : '⚡ Token verified! Add this to your local configuration .env file:'}
              </p>
              <div className="bg-black/85 border border-gray-800 p-2.5 rounded-lg select-all font-mono text-[10.5px] text-emerald-400 font-bold overflow-x-auto break-all">
                {verifiedEnvLine}
              </div>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(verifiedEnvLine);
                  showToast(locale === 'ar' ? 'تم نسخ السطر للمحفظة!' : 'Copied setting format instruction line!', 'success');
                }}
                className="w-full bg-emerald-600/20 hover:bg-emerald-600/35 border border-emerald-900/40 text-[10px] font-bold text-emerald-300 rounded-lg py-1.5 transition cursor-pointer"
              >
                {locale === 'ar' ? 'نسخ السطر البيئي' : 'Copy Env Setting Line'}
              </button>
            </div>
          )}

          {/* Guide / Instructions Block */}
          <div className="bg-zinc-950/60 border border-gray-800 rounded-xl p-4 space-y-3 mt-3">
            <h4 className="text-white font-bold text-xs flex items-center gap-1.5">
              <span>🔑</span>
              <span>{locale === 'ar' ? 'تعليمات إعداد توكن Oranos' : 'Oranos Token Configuration Guide'}</span>
            </h4>

            {(!connectionState || !connectionState.configured) && (
              <p className="text-rose-400 text-[11px] leading-relaxed">
                {locale === 'ar' 
                  ? '⚠️ لم يتم تهيئة أي توكن حالياً. يرجى إضافة متغير ORANOS_API_TOKEN إلى ملف .env الخاص بك.' 
                  : '⚠️ No token configured. Add ORANOS_API_TOKEN to your .env file.'}
              </p>
            )}

            {connectionState && connectionState.configured && connectionState.ok && (
              <p className="text-emerald-400 text-[11px] leading-relaxed font-semibold">
                {locale === 'ar'
                  ? `✅ متصل بنجاح! الرصيد المتاح: ${connectionState.balance}`
                  : `✅ Connected! Balance: ${connectionState.balance}`}
              </p>
            )}

            {connectionState && connectionState.configured && !connectionState.ok && (
              <p className="text-rose-400 text-[11px] leading-relaxed font-semibold">
                {locale === 'ar'
                  ? '❌ التوكن المدخل غير صالح أو انتهت صلاحيته. يرجى تحديث متغير ORANOS_API_TOKEN في ملف .env الخاص بك.'
                  : '❌ Token invalid or expired. Update ORANOS_API_TOKEN in your .env file.'}
              </p>
            )}

            <div className="bg-black border border-gray-850 rounded-lg p-2.5">
              <code className="text-emerald-400 text-[10.5px] font-mono break-all block selection:bg-emerald-900/30">
                ORANOS_API_TOKEN=your_token_here
              </code>
            </div>

            <div className="text-gray-500 text-[10.5px] leading-relaxed space-y-1">
              {locale === 'ar' ? (
                <>
                  1. افتح ملف <span className="font-mono text-gray-400 font-bold">.env</span> في جذر المشروع<br />
                  2. استبدل <span className="font-mono text-gray-400 font-bold">"your_token_here"</span> بالتوكن الكامل المنسوخ أعلاه<br />
                  3. أعد تشغيل السيرفر ليتم تطبيق التغييرات
                </>
              ) : (
                <>
                  1. Open the <span className="font-mono text-gray-400 font-bold">.env</span> file at project root<br />
                  2. Replace <span className="font-mono text-gray-400 font-bold">"your_token_here"</span> with your full verified token<br />
                  3. Restart the application dev server to apply configuration changes
                </>
              )}
            </div>
          </div>

          {/* Connection Status diagnostic info */}
          {connectionState ? (
            <div className={`p-3.5 rounded-xl border text-xs flex gap-2.5 ${
              connectionState.ok 
                ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-400' 
                : 'bg-rose-950/20 border-rose-900/40 text-rose-400'
            }`}>
              {connectionState.ok ? (
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="h-4.5 w-4.5 text-rose-500 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1">
                <p className="font-bold text-[13px]">{connectionState.ok ? t.connected : t.notConnected}</p>
                {connectionState.email && <p className="opacity-80 font-mono text-[10px] lowercase text-white mb-1">User: {connectionState.email}</p>}
                {connectionState.message && <p className="text-[10.5px] font-medium leading-relaxed mt-1 text-gray-300">{connectionState.message}</p>}
              </div>
            </div>
          ) : (
            <div className="p-3.5 bg-gray-950/40 border border-gray-850 rounded-xl text-xs text-gray-500 flex items-center gap-2.5">
              <Server className="h-4 w-4 text-gray-700 animate-pulse" />
              <span>Fetching API connection state...</span>
            </div>
          )}
        </div>

        {/* Sync Controls Card */}
        <div className="bg-gray-900 border border-gray-800 p-5 rounded-2xl shadow-sm space-y-4">
          <div className="flex items-center gap-2.5">
            <Database className="h-5 w-5 text-emerald-400" />
            <h3 className="font-bold text-white text-sm tracking-tight">{t.syncTitle}</h3>
          </div>

          <p className="text-gray-400 text-xs leading-relaxed">
            {t.syncDesc}
          </p>

          <button
            onClick={handleTriggerSync}
            disabled={isSyncing || !connectionState?.ok}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-xl text-xs transition shadow-lg shadow-indigo-950/20 disabled:opacity-50 disabled:hover:bg-indigo-600"
            id="trigger-sync-inventory-btn"
          >
            <RefreshCw className={`h-4.5 w-4.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{t.syncBtn}</span>
          </button>
        </div>
      </div>

      {/* Audit Sync Logs (Right Panel) */}
      <div className="lg:col-span-7 space-y-4">
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
          <Clock className="h-4 w-4 text-emerald-500" />
          <span>{t.logsTitle}</span>
        </h3>

        {isLoadingLogs ? (
          <div className="p-12 text-center border border-gray-800 bg-gray-950/20 rounded-2xl text-gray-500 text-xs flex flex-col items-center justify-center gap-2">
            <RefreshCw className="h-6 w-6 animate-spin text-indigo-400" />
            <span>Loading sync tracking audits...</span>
          </div>
        ) : syncLogs.length === 0 ? (
          <div className="p-12 text-center border border-gray-800 bg-gray-950/20 rounded-2xl text-gray-500 text-xs">
            {t.noLogs}
          </div>
        ) : (
          <div className="space-y-3 max-h-[75vh] overflow-y-auto pr-1">
            {syncLogs.map((log) => {
              const dateStr = new Date(log.timestamp).toLocaleString();
              return (
                <div 
                  key={log.id} 
                  className="bg-gray-950/40 border border-gray-850 p-4 rounded-xl flex flex-col gap-3 hover:border-gray-800 transition"
                >
                  {/* Top line mapping */}
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2.5">
                      <CheckCircle2 className="h-4.5 w-4.5 text-indigo-400" />
                      <span className="text-xs font-bold text-white">{dateStr}</span>
                    </div>
                    <span className="text-[9.5px] font-mono text-gray-600 p-0.5 px-2 bg-black border border-gray-900 rounded-md">
                      {log.id}
                    </span>
                  </div>

                  {/* Operational stats grids */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="p-2 py-1.5 bg-black/40 border border-gray-900 rounded-lg flex flex-col gap-0.5">
                      <span className="text-[9px] text-gray-500 font-semibold">{t.syncedItems}</span>
                      <strong className="text-sm font-black text-indigo-400 font-mono">{log.productsSynced}</strong>
                    </div>

                    <div className="p-2 py-1.5 bg-black/40 border border-gray-900 rounded-lg flex flex-col gap-0.5">
                      <span className="text-[9px] text-gray-500 font-semibold">{t.newProds}</span>
                      <strong className="text-sm font-black text-emerald-400 font-mono">+{log.newProducts}</strong>
                    </div>

                    <div className="p-2 py-1.5 bg-black/40 border border-gray-900 rounded-lg flex flex-col gap-0.5">
                      <span className="text-[9px] text-gray-500 font-semibold">{t.priceDiff}</span>
                      <strong className="text-sm font-black text-amber-500 font-mono">{log.priceChanges}</strong>
                    </div>

                    <div className="p-2 py-1.5 bg-black/40 border border-gray-900 rounded-lg flex flex-col gap-0.5">
                      <span className="text-[9px] text-gray-500 font-semibold">{t.unavail}</span>
                      <strong className="text-sm font-black text-rose-500 font-mono">{log.unavailableProducts}</strong>
                    </div>
                  </div>

                  {/* Run duration footer info */}
                  <div className="flex items-center justify-between border-t border-gray-900/40 pt-2.5 text-[10px] text-gray-500 font-semibold">
                    <span>{t.duration} <strong className="text-gray-400 font-mono">{log.duration}ms</strong></span>
                    <span className="text-emerald-500">Operation Success</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
};
