import React from 'react';
import { useStore } from '../context/StoreContext';
import { OrderStatus, TrackingStep } from '../types';
import { Check, Clock, PackageCheck, Truck, ShieldCheck, MapPin, AlertCircle } from 'lucide-react';

interface OrderTimelineProps {
  steps: TrackingStep[];
  currentStatus: OrderStatus;
}

export const OrderTimeline: React.FC<OrderTimelineProps> = ({ steps, currentStatus }) => {
  const { locale } = useStore();

  const getStatusMeta = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return {
          title_ar: 'تم استلام الطلب',
          title_en: 'Request Received',
          desc_ar: 'تلقينا طلب شحن الرصيد وسنباشر بمراجعته فوراً.',
          desc_en: 'We have received your top-up request and will process it shortly.',
          icon: Clock
        };
      case 'processing':
        return {
          title_ar: 'جاري تنفيذ الطلب وتوليد الأكواد',
          title_en: 'Processing Digital Delivery',
          desc_ar: 'نقوم بتأكيد حسابك وضخ الرصيد المطلوب تلقائياً.',
          desc_en: 'We are verifying your game account and delivering the credits.',
          icon: PackageCheck
        };
      case 'completed':
        return {
          title_ar: 'مكتمل بنجاح',
          title_en: 'Top-UP Completed',
          desc_ar: 'تم الشحن بنجاح! الرصيد الآن في حسابك المربوط.',
          desc_en: 'Credits safely delivered and successfully transferred.',
          icon: Check
        };
      case 'canceled':
        return {
          title_ar: 'تم إلغاء الطلب',
          title_en: 'Transaction Canceled',
          desc_ar: 'تم إيقاف هذه العملية لعدم صحة البيانات أو برغبة المستخدم.',
          desc_en: 'This digital order was rejected or officially voided.',
          icon: AlertCircle
        };
    }
  };

  // Skip rendering canceled unless it actually is canceled
  let timelineSteps = steps.filter(s => s.status !== 'canceled');
  if (currentStatus === 'canceled') {
    timelineSteps = steps.filter(s => s.status === 'pending' || s.status === 'canceled');
  }

  // Determine active flow index
  const activeIndex = timelineSteps.findIndex(s => s.status === currentStatus);

  const formatStepTime = (isoString: string) => {
    if (!isoString) return '';
    const date = new Date(isoString);
    return date.toLocaleDateString(locale === 'ar' ? 'ar-EG' : 'en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      numberingSystem: 'latn'
    });
  };

  return (
    <div className="flow-root py-4">
      <ul className="-mb-8">
        {timelineSteps.map((step, stepIdx) => {
          const meta = getStatusMeta(step.status);
          const isCompleted = step.completed || (activeIndex !== -1 && stepIdx <= activeIndex);
          const isActive = step.status === currentStatus;
          const IconComponent = meta.icon;

          return (
            <li key={step.status}>
              <div className="relative pb-8">
                {stepIdx !== timelineSteps.length - 1 ? (
                  <span
                    className={`absolute top-4 ${
                      locale === 'ar' ? 'right-4 -mr-pxHTML' : 'left-4 -ml-px'
                    } h-full w-0.5 ${isCompleted ? 'bg-black' : 'bg-gray-200'}`}
                    aria-hidden="true"
                    style={{
                      [locale === 'ar' ? 'right' : 'left']: '1rem',
                    }}
                  />
                ) : null}
                <div className="relative flex space-x-3 items-start" style={{ gap: locale === 'ar' ? '0.75rem' : '' }}>
                  <div>
                    <span
                      className={`flex h-8 w-8 items-center justify-center rounded-full ring-8 ring-white transition-all duration-300 ${
                        isActive
                          ? 'bg-black text-white scale-110 animate-pulse'
                          : isCompleted
                          ? 'bg-black text-white'
                          : 'bg-gray-100 text-gray-400'
                      }`}
                    >
                      {isCompleted && !isActive ? (
                        <Check className="h-4 w-4" />
                      ) : (
                        <IconComponent className="h-4 w-4" />
                      )}
                    </span>
                  </div>

                  {/* Text Description Box */}
                  <div className={`flex-1 min-w-0 ${locale === 'ar' ? 'text-right' : 'text-left'}`}>
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
                      <p
                        className={`text-sm font-bold ${
                          isActive ? 'text-black' : isCompleted ? 'text-gray-900' : 'text-gray-400'
                        }`}
                      >
                        {locale === 'ar' ? meta?.title_ar : meta?.title_en}
                      </p>
                      
                      {step.timestamp && (
                        <span className="text-[10px] text-gray-400 font-mono">
                          {formatStepTime(step.timestamp)}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {locale === 'ar' ? meta?.desc_ar : meta?.desc_en}
                    </p>
                  </div>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
};
export default OrderTimeline;
