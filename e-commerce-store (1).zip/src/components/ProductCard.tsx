import React from 'react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';
import { ShoppingBag, ArrowRight, ArrowLeft } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { locale, formatPrice, navigate } = useStore();

  const handleCardClick = () => {
    navigate('product-detail', { productId: product.id });
  };

  const renderBadge = () => {
    const customBadge = locale === 'ar' ? product.badge_ar : product.badge_en;
    if (customBadge) {
      return (
        <span className="absolute top-3 right-3 z-10 px-2.5 py-0.5 text-[9px] font-black uppercase tracking-wide bg-emerald-600 border border-emerald-400/30 text-white rounded-md">
          {customBadge}
        </span>
      );
    }

    if (product.status === 'out_of_stock') {
      return (
        <span className="absolute top-3 right-3 z-10 px-2.5 py-0.5 text-[9px] font-bold bg-rose-950 text-rose-450 border border-rose-900 rounded-md">
          {locale === 'ar' ? 'منتهي المؤقت' : 'Sold Out'}
        </span>
      );
    }

    if (product.discountPrice) {
      const percentage = Math.round(
        ((product.price - product.discountPrice) / product.price) * 100
      );
      return (
        <span className="absolute top-3 right-3 z-10 px-2.5 py-0.5 text-[9px] font-black bg-emerald-950 text-emerald-400 border border-emerald-900 rounded-md">
          {locale === 'ar' ? `وفّر %${percentage}` : `${percentage}% OFF`}
        </span>
      );
    }

    return null;
  };

  const name = locale === 'ar' ? product.name_ar : product.name_en;
  const isOutOfStock = product.status === 'out_of_stock';

  return (
    <div
      onClick={handleCardClick}
      className="group relative cursor-pointer flex flex-col justify-between overflow-hidden rounded-2xl border border-gray-800 bg-[#0c101b] shadow-xs hover:shadow-lg hover:border-emerald-500/30 transition-all duration-300"
    >
      {/* Product Image Panel */}
      <div className="relative aspect-square w-full overflow-hidden bg-gray-950 flex items-center justify-center p-3">
        {renderBadge()}
        
        <img
          src={product.coverImage}
          alt={name}
          className="h-full w-full object-contain transition-transform duration-500 scale-100 group-hover:scale-105"
          loading="lazy"
          referrerPolicy="no-referrer"
        />

        {/* Quick add overlay on hover */}
        {!isOutOfStock && (
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
            <button
              onClick={handleCardClick}
              className="w-full bg-emerald-600 hover:bg-emerald-700 py-2 px-3 rounded-xl text-[10px] uppercase font-black text-white transition-all transform translate-y-2 group-hover:translate-y-0 duration-300 flex items-center justify-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
            >
              <ShoppingBag className="h-3.5 w-3.5 shrink-0" />
              <span>{locale === 'ar' ? 'عرض وشحن' : 'View & Recharge'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Info Content Box */}
      <div className="p-4 flex-1 flex flex-col justify-between" style={{ textAlign: locale === 'ar' ? 'right' : 'left' }}>
        <div>
          <h3 className="font-sans text-xs font-black text-gray-200 group-hover:text-emerald-400 line-clamp-2 transition-colors leading-relaxed">
            {name}
          </h3>
          <p className="text-[10px] text-gray-500 font-bold mt-1">
            {locale === 'ar' ? 'تسليم تلقائي ⚡' : 'Instantly Delivered ⚡'}
          </p>
        </div>

        <div className="mt-4 flex items-end justify-between gap-2 pt-3 border-t border-gray-850">
          <div className="flex flex-col">
            {product.discountPrice ? (
              <div className="flex items-baseline gap-1.5">
                <span className="text-sm font-extrabold text-white font-mono">
                  {formatPrice(product.discountPrice)}
                </span>
                <span className="text-[10px] text-gray-500 line-through font-mono">
                  {formatPrice(product.price)}
                </span>
              </div>
            ) : (
              <span className="text-sm font-extrabold text-emerald-400 font-mono">
                {formatPrice(product.price)}
              </span>
            )}
          </div>

          {/* CTA Link Trigger */}
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gray-900 text-gray-400 group-hover:bg-emerald-600 group-hover:text-white transition-all active:scale-90 border border-gray-800">
            {locale === 'ar' ? (
              <ArrowLeft className="h-4 w-4" />
            ) : (
              <ArrowRight className="h-4 w-4" />
            )}
          </span>
        </div>
      </div>
    </div>
  );
};
export default ProductCard;
