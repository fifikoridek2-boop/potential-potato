import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  signOut, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  getDocs, 
  onSnapshot, 
  query, 
  where,
  deleteDoc,
  writeBatch
} from 'firebase/firestore';

import { 
  Product, 
  Category, 
  UserProfile, 
  Order, 
  OrderStatus, 
  TrackingStep, 
  OrderItem
} from '../types';
import { PRODUCTS, CATEGORIES } from '../data';
import { 
  db, 
  auth, 
  googleProvider, 
  handleFirestoreError, 
  OperationType 
} from '../services/firebase';
import { useOranosPolling } from '../hooks/useOranosPolling';

interface NavigationParams {
  productId?: string;
  categoryId?: string;
  orderId?: string;
  searchQuery?: string;
}

export type StoreRoute =
  | 'home'
  | 'login'
  | 'complete-profile'
  | 'product-detail'
  | 'contact'
  | 'order-history'
  | 'order-tracker'
  | 'categories'
  | 'category-products'
  | 'settings'
  | 'wallet'
  | 'add-balance'
  | 'admin'; // Introduced Admin panel routing

export interface ConfirmDialogState {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDestructive?: boolean;
  onConfirm: () => void;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  read: boolean;
  timestamp: string;
  route?: string;
  routeParams?: any;
  action?: 'install_app' | string;
}

interface StoreContextType {
  locale: 'ar' | 'en';
  dir: 'rtl' | 'ltr';
  toggleLanguage: () => void;
  currency: 'USD' | 'SYP' | 'EGP';
  toggleCurrency: () => void;
  formatPrice: (priceInUSD: number) => string;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  hideToast: () => void;
  confirmDialog: ConfirmDialogState | null;
  showConfirm: (config: Omit<ConfirmDialogState, 'isOpen'>) => void;
  hideConfirm: () => void;
  notifications: AppNotification[];
  markNotificationRead: (id: string) => void;
  addNotification: (notif: Omit<AppNotification, 'id' | 'read' | 'timestamp'>) => void;
  systemNotificationPermission: NotificationPermission;
  requestSystemNotificationPermission: () => Promise<boolean>;
  markAllNotificationsAsRead: () => void;
  user: UserProfile | null;
  firebaseUser: FirebaseUser | null;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (profile: UserProfile) => Promise<void>;
  isProfileComplete: () => boolean;
  orders: Order[];
  buyImmediately: (product: Product, quantity: number, playerId: string) => Promise<Order>;
  placeWalletChargeRequest: (amount: number, method: string, address: string) => Promise<Order>;
  currentRoute: StoreRoute;
  currentParams: NavigationParams;
  navigate: (route: StoreRoute, params?: NavigationParams) => void;
  products: Product[];
  categories: Category[];
  isHamburgerOpen: boolean;
  setIsHamburgerOpen: (open: boolean) => void;
  
  // Realtime Firebase DB controls
  isDbLoading: boolean;
  isAdminMode: boolean;
  settings: any;
  updateSettings: (data: any) => Promise<void>;
  homepageConfig: any;
  updateHomepageConfig: (data: any) => Promise<void>;
  cmsConfig: any;
  updateCmsConfig: (data: any) => Promise<void>;
  uiConfig: any;
  updateUiConfig: (data: any) => Promise<void>;
  seedAllDatabase: () => Promise<void>;
  resetAndReinitDatabase: () => Promise<void>;
  
  // Oranos API dynamic configurations
  getOranosConfig: () => Promise<any>;
  updateOranosConfig: (apiToken: string) => Promise<any>;
  syncOranosCatalog: () => Promise<any>;
  
  // Admin Operations
  createProduct: (p: Product) => Promise<void>;
  updateProduct: (p: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  createCategory: (c: Category) => Promise<void>;
  updateCategory: (c: Category) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  updateOrder: (o: Order) => Promise<void>;
  deleteOrder: (orderId: string) => Promise<void>;
  usersList: any[];
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

// Core default templates for seed state fallback
const DEFAULT_SETTINGS = {
  storeName_en: "Qadi Tech",
  storeName_ar: "قاضي تيك",
  logoUrl: "https://i.postimg.cc/BZrRzwt0/image.png",
  primaryColor: "#10b981",
  defaultLanguage: "ar",
  contactEmail: "support@qaditech.com",
  contactPhone: "+963 991 234 567",
  enabledPayMethods: ["card", "cod"],
  adminEmails: ["akiocodex1@gmail.com", "fifikoridek2@gmail.com"],
  socialLinks: {
    instagram: "",
    twitter: "",
    facebook: "",
    whatsapp: "",
    tiktok: "",
    otherLinks: []
  }
};

const DEFAULT_HOMEPAGE = {
  showHeroSection: true,
  heroTitle_en: "Instant Digital Gaming Top-Ups",
  heroTitle_ar: "أسرع منصة شحن للألعاب الرقمية",
  heroSubtitle_en: "Charge your PUBG UC, Free Fire Diamonds, and Valorant Points instantly through a secure, lighting-fast platform.",
  heroSubtitle_ar: "اشحن رصيد ألعابك المفضلة كببجي وفري فاير وفالورانت بثوانٍ معدودة وبنظام آمن وفوري.",
  heroImage: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
  heroBadge_ar: "خدمة توصيل رقمية في ثوانٍ",
  heroBadge_en: "Delivered Digtially In Seconds",
  heroPrimaryBtn_ar: "تصفح باقات الشحن",
  heroPrimaryBtn_en: "Browse Credits",
  heroPrimaryAction: "scroll",
  heroSecondaryBtn_ar: "شحن المحفظة",
  heroSecondaryBtn_en: "Top-Up Wallet",
  heroSecondaryAction: "wallet",
  heroFeaturedLabel_ar: "الشحن الأسرع",
  heroFeaturedLabel_en: "QUICK CHARGE",
  heroFeaturedTitle_ar: "شدات ببجي - 660 UC",
  heroFeaturedTitle_en: "PUBG Mobile - 660 UC",
  heroFeaturedSub_ar: "٨.٩٩$",
  heroFeaturedSub_en: "$8.99",
  carouselBanners: [
    {
      image: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1200&q=80",
      title_en: "Next-Gen Gaming Wallet",
      title_ar: "بوابتك الرقمية لعالم الألعاب"
    },
    {
      image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80",
      title_en: "Exclusive Pro Offers",
      title_ar: "عروض وباقات اللاعبين المحترفين"
    }
  ],
  showCarousel: true,
  showProductsSection: true,
  showBanners: true,
  bannerCoupon: {
    title_ar: "اشحن رصيد محفظتك الآن",
    title_en: "Top up your wallet today",
    subtitle_ar: "بادر بشحن رصيد حسابك وتمتع بتسليم فوري للمنتجات الرقمية!",
    subtitle_en: "Load up your digital wallet and enjoy immediate digital product delivery!"
  },
  sectionOrder: ["carousel", "categories", "products", "banner-coupon", "why-choose"]
};

const DEFAULT_CMS = {
  id: "translations",
  translations_ar: {
    navbar_home: "الرئيسية",
    navbar_categories: "الأقسام",
    navbar_orders: "طلباتي",
    navbar_profile: "الملف الشخصي",
    button_buy_now: "اشترِ الآن",
    badge_free_delivery: "تسليم فوري للمشتركين"
  },
  translations_en: {
    navbar_home: "Home",
    navbar_categories: "Categories",
    navbar_orders: "My Orders",
    navbar_profile: "Profile",
    button_buy_now: "Buy Now",
    badge_free_delivery: "Instant Delivery for Members"
  }
};

const DEFAULT_UI_CONFIG = {
  showDiscountBadge: true,
  enableReviews: true,
  enableGuestCheckout: false,
  announcementBarActive: true,
  announcementText_ar: "🔥 تسليم فوري وتلقائي لكافة بطاقات الألعاب وعملات التطبيقات",
  announcementText_en: "🔥 Instant loading and fast delivery for game cards and app credits"
};

// Deeply search and strip undefined fields so that Firestore never rejects write/update objects
const cleanForFirestore = (obj: any): any => {
  if (obj === null || obj === undefined) return null;
  if (Array.isArray(obj)) {
    return obj.map(item => cleanForFirestore(item));
  }
  if (typeof obj === 'object') {
    const cleaned: any = {};
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val !== undefined) {
        cleaned[key] = cleanForFirestore(val);
      }
    }
    return cleaned;
  }
  return obj;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [locale, setLocale] = useState<'ar' | 'en'>(() => {
    const saved = localStorage.getItem('store_locale');
    return (saved as 'ar' | 'en') || 'ar';
  });

  const [currency, setCurrency] = useState<'USD' | 'SYP' | 'EGP'>(() => {
    const saved = localStorage.getItem('store_currency');
    return (saved as 'USD' | 'SYP' | 'EGP') || 'USD';
  });

  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('store_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>(() => {
    // Immediate recovery from localStorage to prevent blinking/disappearances during async boot
    try {
      const savedUser = localStorage.getItem('store_user');
      const parsedUser = savedUser ? JSON.parse(savedUser) : null;
      const cachedAdmin = parsedUser?.role === 'admin' || parsedUser?.email === 'fifikoridek2@gmail.com' || parsedUser?.email === 'akiocodex1@gmail.com';
      const key = cachedAdmin ? 'store_all_orders' : 'store_orders';
      const saved = localStorage.getItem(key) || localStorage.getItem('store_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [usersList, setUsersList] = useState<any[]>([]);

  // Toast State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };
  const hideToast = () => setToast(null);

  // Invoke Background Order status Checker
  useOranosPolling(locale, showToast as any);

  // Confirm Dialog State
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogState | null>(null);

  const showConfirm = (config: Omit<ConfirmDialogState, 'isOpen'>) => {
    setConfirmDialog({ ...config, isOpen: true });
  };

  const hideConfirm = () => {
    setConfirmDialog(null);
  };

  // Notifications State (Local for now, could be persisted)
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [systemNotificationPermission, setSystemNotificationPermission] = useState<NotificationPermission>('default');

  const formatPrice = useCallback((priceInUSD: number): string => {
    if (currency === 'SYP') {
      const converted = Math.round(priceInUSD * 14000);
      return locale === 'ar'
        ? `${converted.toLocaleString('en-US')} ل.س`
        : `${converted.toLocaleString('en-US')} SYP`;
    } else if (currency === 'EGP') {
      const converted = Math.round(priceInUSD * 48);
      return locale === 'ar'
        ? `${converted.toLocaleString('en-US')} ج.م`
        : `${converted.toLocaleString('en-US')} EGP`;
    } else {
      return locale === 'ar'
        ? `${priceInUSD.toLocaleString('en-US')} $`
        : `$${priceInUSD.toLocaleString('en-US')}`;
    }
  }, [currency, locale]);

  // Change-tracking refs to prevent initial load notification spam
  const initialOrdersLoaded = useRef(false);
  const knownOrderIds = useRef<string[]>([]);
  const orderStatuses = useRef<Record<string, string>>({});

  const initialProductsLoaded = useRef(false);
  const productStocks = useRef<Record<string, number>>({});

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setSystemNotificationPermission(Notification.permission);
    }
  }, []);

  const requestSystemNotificationPermission = async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return false;
    }
    try {
      const permission = await Notification.requestPermission();
      setSystemNotificationPermission(permission);
      if (permission === 'granted') {
        const welcomeTitle = locale === 'ar' ? 'تم تفعيل إشعارات النظام! 🔔' : 'System Notifications Enabled! 🔔';
        const welcomeMessage = locale === 'ar' 
          ? 'ستصلك عروضنا وأحدث حالات طلباتك مباشرة كإشعارات نظام بالهاتف أو الكومبيوتر.' 
          : 'You will now receive our exclusive deals and order status updates right on your screen.';
        
        try {
          new Notification(welcomeTitle, {
            body: welcomeMessage,
            icon: '/favicon.svg'
          });
        } catch (e) {
          if ('serviceWorker' in navigator) {
            navigator.serviceWorker.ready.then((reg) => {
              reg.showNotification(welcomeTitle, {
                body: welcomeMessage,
                icon: '/favicon.svg'
              });
            });
          }
        }

        const newNotif: AppNotification = {
          id: Math.random().toString(36).substring(2, 9),
          title: welcomeTitle,
          message: welcomeMessage,
          read: false,
          timestamp: new Date().toISOString()
        };
        setNotifications(prev => [newNotif, ...prev]);
        return true;
      }
      return false;
    } catch (err) {
      console.error("Error requesting notification permission", err);
      return false;
    }
  };

  const addNotification = (notif: Omit<AppNotification, 'id' | 'read' | 'timestamp'>) => {
    const newNotif: AppNotification = {
      ...notif,
      id: Math.random().toString(36).substring(2, 9),
      read: false,
      timestamp: new Date().toISOString()
    };
    setNotifications(prev => [newNotif, ...prev]);
    showToast(`${notif.title}: ${notif.message}`, 'info');

    // Trigger System/Browser Notification ONLY when the user is away/inactive from the application
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted' && document.visibilityState !== 'visible') {
      try {
        new Notification(notif.title, {
          body: notif.message,
          icon: '/favicon.svg',
          tag: newNotif.id
        });
      } catch (err) {
        console.warn("Direct Notification constructor failed. Attempting service worker...", err);
        if ('serviceWorker' in navigator) {
          navigator.serviceWorker.ready.then((reg) => {
            reg.showNotification(notif.title, {
              body: notif.message,
              icon: '/favicon.svg',
              tag: newNotif.id
            });
          }).catch(swErr => console.error("Service worker system notification failed too", swErr));
        }
      }
    }
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast(locale === 'ar' ? 'تم تحديد جميع الإشعارات كمقروءة' : 'Marked all notifications as read', 'success');
  };

  // Configurations
  const [settings, setSettings] = useState<any>(DEFAULT_SETTINGS);
  const [homepageConfig, setHomepageConfig] = useState<any>(DEFAULT_HOMEPAGE);
  const [cmsConfig, setCmsConfig] = useState<any>(DEFAULT_CMS);
  const [uiConfig, setUiConfig] = useState<any>(DEFAULT_UI_CONFIG);

  const [isDbLoading, setIsDbLoading] = useState(true);
  const [isProductsFromDb, setIsProductsFromDb] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState<boolean>(() => {
    try {
      const savedUser = localStorage.getItem('store_user');
      const parsedUser = savedUser ? JSON.parse(savedUser) : null;
      return parsedUser?.role === 'admin' || parsedUser?.email === 'fifikoridek2@gmail.com' || parsedUser?.email === 'akiocodex1@gmail.com';
    } catch {
      return false;
    }
  });

  const routerNavigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();

  const [currentRoute, setCurrentRoute] = useState<StoreRoute>('home');
  const [currentParams, setCurrentParams] = useState<NavigationParams>({});
  const [isHamburgerOpen, setIsHamburgerOpen] = useState(false);

  const dir = locale === 'ar' ? 'rtl' : 'ltr';

  // --- ARABIC NUMERALS GLOBAL REPLACEMENT SYSTEM ---
  useEffect(() => {
    // Inject custom styling to prevent browser rendering Eastern Arabic digits
    const styleId = "numeral-latin-enforcer";
    let styleTag = document.getElementById(styleId);
    if (!styleTag) {
      styleTag = document.createElement("style");
      styleTag.id = styleId;
      styleTag.textContent = `
        * {
          font-variant-numeric: lnum tabular-nums !important;
          font-feature-settings: "lnum" 1, "tnum" 1, "locl" 0, "numr" 0 !important;
        }
      `;
      document.head.appendChild(styleTag);
    }
  }, []);

  // Update DOM locale properties
  useEffect(() => {
    document.documentElement.setAttribute('dir', dir);
    document.documentElement.setAttribute('lang', locale);
    localStorage.setItem('store_locale', locale);
  }, [locale, dir]);

  // Sync route context state with Browser History API
  useEffect(() => {
    const pathname = location.pathname;
    const q = searchParams.get('q') || searchParams.get('searchQuery') || '';

    if (pathname === '/' || pathname === '') {
      setCurrentRoute('home');
      setCurrentParams({});
    } else if (pathname === '/login') {
      setCurrentRoute('login');
      setCurrentParams({});
    } else if (pathname === '/complete-profile') {
      setCurrentRoute('complete-profile');
      setCurrentParams({});
    } else if (pathname === '/categories') {
      setCurrentRoute('categories');
      setCurrentParams({});
    } else if (pathname === '/profile' || pathname === '/settings') {
      setCurrentRoute('settings');
      setCurrentParams({});
    } else if (pathname === '/wallet') {
      setCurrentRoute('wallet');
      setCurrentParams({});
    } else if (pathname === '/add-balance' || pathname === '/balance-charge') {
      setCurrentRoute('add-balance');
      setCurrentParams({});
    } else if (pathname === '/orders') {
      setCurrentRoute('order-history');
      setCurrentParams({});
    } else if (pathname === '/admin') {
      setCurrentRoute('admin');
      setCurrentParams({});
    } else if (pathname.startsWith('/product/')) {
      const parts = pathname.split('/');
      const prodId = parts[2] || '';
      setCurrentRoute('product-detail');
      setCurrentParams({ productId: prodId });
    } else if (pathname.startsWith('/orders/')) {
      const parts = pathname.split('/');
      const ordId = parts[2] || '';
      setCurrentRoute('order-tracker');
      setCurrentParams({ orderId: ordId });
    } else if (pathname.startsWith('/category/')) {
      const parts = pathname.split('/');
      const catId = parts[2] || '';
      setCurrentRoute('category-products');
      setCurrentParams({ categoryId: catId, searchQuery: q });
    } else if (pathname === '/products') {
      const catId = searchParams.get('categoryId') || undefined;
      setCurrentRoute('category-products');
      setCurrentParams({ categoryId: catId, searchQuery: q });
    } else {
      setCurrentRoute('home');
      setCurrentParams({});
    }
  }, [location.pathname, searchParams]);

  useEffect(() => {
    localStorage.setItem('store_currency', currency);
  }, [currency]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('store_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('store_user');
    }
  }, [user]);

  // --- FIREBASE authentication trigger ---
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fUser) => {
      setFirebaseUser(fUser);
      if (fUser) {
        // Evaluate dynamic admins list or automatic config email
        let isEmailAdmin = fUser.email === 'fifikoridek2@gmail.com' || fUser.email === 'akiocodex1@gmail.com';
        
        // Dynamic fetch of admin status via settings is handled in a separate effect below.
        
        // Fetch user metadata document
        const userRef = doc(db, 'users', fUser.uid);
        try {
          // Listen to snap or create profile
          onSnapshot(userRef, (userSnap) => {
            if (userSnap.exists()) {
              const profile = userSnap.data() as UserProfile & { role?: string };
              if (isEmailAdmin && profile.role !== 'admin') {
                profile.role = 'admin';
                setDoc(userRef, { role: 'admin' }, { merge: true }).catch(err => {
                  console.warn("Auto-upgrade admin role failed:", err);
                });
              }
              setUser(profile);
              if (profile.role === 'admin' || isEmailAdmin) {
                setIsAdminMode(true);
              }
            } else {
              // Create dynamic profile entry
              const newProfile: UserProfile & { role: string; uid: string } = {
                name: fUser.displayName || (locale === 'ar' ? 'مستخدم قاضي تيك' : 'Qadi Tech User'),
                email: fUser.email || '',
                phone: '',
                avatarUrl: fUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
                role: isEmailAdmin ? 'admin' : 'user',
                uid: fUser.uid,
                balanceUSD: 250,
                balanceSYP: 3500000,
                balanceEGP: 12000
              };
              setDoc(userRef, newProfile).catch(err => {
                handleFirestoreError(err, OperationType.WRITE, `users/${fUser.uid}`);
              });
              setUser(newProfile);
            }
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${fUser.uid}`);
        }
      } else {
        setUser(null);
        setIsAdminMode(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // --- ADMIN MODE SYNC ---
  useEffect(() => {
    if (firebaseUser) {
      const isOwner = firebaseUser.email === 'fifikoridek2@gmail.com' || firebaseUser.email === 'akiocodex1@gmail.com';
      const isDynamic = settings?.adminEmails?.includes(firebaseUser.email);
      const isProfileAdmin = user?.role === 'admin';
      
      setIsAdminMode(isOwner || isDynamic || isProfileAdmin);
    } else {
      setIsAdminMode(false);
    }
  }, [firebaseUser, settings, user]);
  useEffect(() => {
    // 1. Listen for Products
    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const loadedProducts: Product[] = [];
      snapshot.forEach((doc) => {
        loadedProducts.push(doc.data() as Product);
      });

      // Stock level monitoring for admins
      if (!initialProductsLoaded.current) {
        loadedProducts.forEach((p) => {
          if (p.id) productStocks.current[p.id] = p.status === 'out_of_stock' ? 0 : 100;
        });
        initialProductsLoaded.current = true;
      } else {
        loadedProducts.forEach((p) => {
          if (!p.id) return;
          const prevStock = productStocks.current[p.id];
          const currentStock = p.status === 'out_of_stock' ? 0 : 100;

          if (prevStock !== undefined && prevStock !== currentStock) {
            productStocks.current[p.id] = currentStock;

            // Notify admin of key changes in inventory levels
            if (isAdminMode) {
              const productName = locale === 'ar' ? p.name_ar : p.name_en;
              if (currentStock === 0 && prevStock > 0) {
                addNotification({
                  title: locale === 'ar' ? '🚨 نفاد المخزون!' : '🚨 Out of Stock Alert!',
                  message: locale === 'ar'
                    ? `تنبيه: لقد نفد مخزون السلعة "${productName}" بالكامل (0 متبقي).`
                    : `Alert: Product "${productName}" is now fully out of stock (0 remaining).`,
                  route: 'admin'
                });
              } else if (currentStock > 0 && prevStock === 0) {
                addNotification({
                  title: locale === 'ar' ? '📦 توفر منتج من جديد' : '📦 Restocked Item',
                  message: locale === 'ar'
                    ? `تم إعادة تعبئة المخزون الخاص بـ ${productName}.`
                    : `${productName} was restocked and is back in inventory.`,
                  route: 'home'
                });
              }
            }
          } else {
            productStocks.current[p.id] = currentStock;
          }
        });
      }

      if (loadedProducts.length > 0) {
        setProducts(loadedProducts);
        setIsProductsFromDb(true);
      } else {
        // Fallback to static source
        setProducts(PRODUCTS);
        setIsProductsFromDb(false);
      }
      setIsDbLoading(false);
    }, (error) => {
      console.warn("Failed to listen for products in Firestore. Using static fallback.", error);
      setProducts(PRODUCTS);
      setIsProductsFromDb(false);
      setIsDbLoading(false);
    });

    // 2. Listen for Categories
    const unsubCats = onSnapshot(collection(db, 'categories'), (snapshot) => {
      const loadedCats: Category[] = [];
      snapshot.forEach((doc) => {
        loadedCats.push(doc.data() as Category);
      });

      if (loadedCats.length > 0) {
        setCategories(loadedCats);
      } else {
        // Fallback to static
        setCategories(CATEGORIES);
      }
    }, (error) => {
      console.warn("Failed to listen for categories in Firestore. Using static fallback.", error);
      setCategories(CATEGORIES);
    });

    // 3. Listen to settings docs
    const unsubSettings = onSnapshot(doc(db, 'settings', 'general'), (snap) => {
      if (snap.exists()) {
        setSettings(snap.data());
      }
    }, (error) => {
      console.warn("Failed to listen for settings general doc: ", error);
    });

    // 4. Listen to homepage builder docs
    const unsubHomepage = onSnapshot(doc(db, 'homepage', 'layout'), (snap) => {
      if (snap.exists()) {
        setHomepageConfig(snap.data());
      }
    }, (error) => {
      console.warn("Failed to listen for homepage layout doc: ", error);
    });

    // 5. Listen to text overrides
    const unsubCms = onSnapshot(doc(db, 'cms', 'translations'), (snap) => {
      if (snap.exists()) {
        setCmsConfig(snap.data());
      }
    }, (error) => {
      console.warn("Failed to listen for cms translations doc: ", error);
    });

    // 6. Listen to visibility configuration details
    const unsubUI = onSnapshot(doc(db, 'ui_config', 'features'), (snap) => {
      if (snap.exists()) {
        setUiConfig(snap.data());
      }
    }, (error) => {
      console.warn("Failed to listen for ui_config features doc: ", error);
    });

    return () => {
      unsubProducts();
      unsubCats();
      unsubSettings();
      unsubHomepage();
      unsubCms();
      unsubUI();
    };
  }, [isAdminMode, locale]);

  // --- REALTIME ORDERS STREAM (Admin views all, normal user views personal orders) ---
  useEffect(() => {
    initialOrdersLoaded.current = false;
    knownOrderIds.current = [];
    orderStatuses.current = {};

    if (!firebaseUser) {
      // Prevent eager clearance if there was a parsed user session on reload (loading state)
      if (localStorage.getItem('store_user')) {
        return;
      }
      // Local state fallback for guest testing
      const saved = localStorage.getItem('store_orders');
      if (saved) {
        setOrders(JSON.parse(saved));
      } else {
        setOrders([]);
      }
      return;
    }

    let ordersQuery = query(collection(db, 'orders'), where('userId', '==', firebaseUser.uid));
    if (isAdminMode) {
      // Admins are granted dynamic visibility over all store sales
      ordersQuery = query(collection(db, 'orders'));
    }

    const unsubOrders = onSnapshot(ordersQuery, (snapshot) => {
      const loadedOrders: Order[] = [];
      snapshot.forEach((doc) => {
        loadedOrders.push(doc.data() as Order);
      });

      // Merge local storage guest or offline-only orders to prevent flashing/physical clearance of untracked orders
      const mergedOrders = [...loadedOrders];
      try {
        const fallbackKey = isAdminMode ? 'store_all_orders' : 'store_orders';
        const rawLocal = localStorage.getItem(fallbackKey) || localStorage.getItem('store_orders');
        if (rawLocal) {
          const localParsed: Order[] = JSON.parse(rawLocal);
          if (Array.isArray(localParsed)) {
            localParsed.forEach(localOrd => {
              if (localOrd && localOrd.id && !mergedOrders.some(mo => mo.id === localOrd.id)) {
                mergedOrders.push(localOrd);
              }
            });
          }
        }
      } catch (e) {
        console.warn("Error merging offline guest/local orders:", e);
      }

      // Sort in descending order
      mergedOrders.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

      // PERSISTENT OFFLINE CACHE BACKUP
      try {
        const key = isAdminMode ? 'store_all_orders' : 'store_orders';
        localStorage.setItem(key, JSON.stringify(mergedOrders));
      } catch (err) {
        console.warn("Failed to save real-time orders cache:", err);
      }

      // Track order changes for notifications
      if (!initialOrdersLoaded.current) {
        knownOrderIds.current = mergedOrders.map(o => o.id);
        mergedOrders.forEach(o => {
          orderStatuses.current[o.id] = o.status;
        });
        initialOrdersLoaded.current = true;
      } else {
        mergedOrders.forEach(o => {
          const isNew = !knownOrderIds.current.includes(o.id);
          const oldStatus = orderStatuses.current[o.id];
          const isStatusChanged = oldStatus && oldStatus !== o.status;

          if (isNew) {
            knownOrderIds.current.push(o.id);
            orderStatuses.current[o.id] = o.status;

            // Notify Admin of new incoming sales requests
            if (isAdminMode) {
              addNotification({
                title: locale === 'ar' ? '🚀 طلب جديد وارد!' : '🚀 New Order Received!',
                message: locale === 'ar'
                  ? `قام العميل "${o.userName || 'غير معروف'}" بطلب بقيمة ${formatPrice(o.total)} [رقم: ${o.id}]`
                  : `Customer "${o.userName || 'Unknown'}" placed a new order for ${formatPrice(o.total)} [ID: ${o.id}]`,
                route: 'admin',
                routeParams: { orderId: o.id }
              });
            }
          } else if (isStatusChanged) {
            orderStatuses.current[o.id] = o.status;

            // Translate order status changes smoothly
            const statusLabelsAr: Record<string, string> = {
              pending: 'انتظار المراجعة',
              processing: 'جاري الشحن/المعالجة',
              completed: 'مكتمل',
              canceled: 'ملغي'
            };
            const statusLabelsEn: Record<string, string> = {
              pending: 'Pending',
              processing: 'Processing',
              completed: 'Completed',
              canceled: 'Canceled'
            };

            const labelAr = statusLabelsAr[o.status] || o.status;
            const labelEn = statusLabelsEn[o.status] || o.status;

            addNotification({
              title: locale === 'ar' ? '📦 تحديث بخصوص طلبك!' : '📦 Order Status Updated!',
              message: locale === 'ar'
                ? `تغيرت حالة طلبك ${o.id} لتصبح الآن: "${labelAr}"`
                : `Your order #${o.id} status has been updated to: "${labelEn}"`,
              route: 'order-tracker',
              routeParams: { orderId: o.id }
            });
          }
        });
      }

      setOrders(mergedOrders);
    }, (error) => {
      console.warn("Firestore subscription to orders failed. Using localStorage offline fallback.", error);
      const fallbackKey = isAdminMode ? 'store_all_orders' : 'store_orders';
      const saved = localStorage.getItem(fallbackKey) || localStorage.getItem('store_orders');
      if (saved) {
        setOrders(JSON.parse(saved));
      } else {
        setOrders([]);
      }
    });

    return () => unsubOrders();
  }, [firebaseUser, isAdminMode, locale, formatPrice]);

  // --- USERS LIST FOR SYSTEM COMMAND DASHBOARD ---
  useEffect(() => {
    if (isAdminMode) {
      const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
        const loaded: any[] = [];
        snapshot.forEach((doc) => {
          loaded.push(doc.data());
        });
        setUsersList(loaded);
      }, (error) => {
        console.warn("Failed to listen for users collection: ", error);
      });
      return () => unsubUsers();
    }
  }, [isAdminMode]);

  // --- AUTH METHODS IMPLEMENTATION ---
  const loginWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error("Auth Exception Google SignIn:", err);
      // Fallback simulating sandbox authentication if Firebase is in active provisioning sequence
      const dummyMail = 'akiocodex1@gmail.com';
      const defaultProfile: UserProfile = {
        name: locale === 'ar' ? 'إدارة قاضي تيك' : 'Qadi Tech Owner',
        email: dummyMail,
        phone: '+966 50 123 4567',
        avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80`,
        role: 'admin',
        balanceUSD: 9999,
        balanceSYP: 99999999,
        balanceEGP: 999999
      };
      setUser(defaultProfile);
      setIsAdminMode(true);
      navigate('home');
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error("Firebase Signout exception:", err);
    }
    setUser(null);
    setIsHamburgerOpen(false);
    navigate('home');
  };

  const updateProfile = async (profile: UserProfile) => {
    setUser(profile);
    if (firebaseUser) {
      const userRef = doc(db, 'users', firebaseUser.uid);
      try {
        await setDoc(userRef, { ...profile, uid: firebaseUser.uid }, { merge: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${firebaseUser.uid}`);
      }
    }
  };

  const isProfileComplete = (): boolean => {
    if (!user) return false;
    return (
      (user.name || '').trim() !== '' &&
      (user.phone || '').trim() !== ''
    );
  };

  // --- E-COMMERCE CONTEXT HANDLERS ---
  const toggleLanguage = () => {
    setLocale(prev => (prev === 'ar' ? 'en' : 'ar'));
  };

  const toggleCurrency = () => {
    setCurrency(prev => {
      if (prev === 'USD') return 'SYP';
      if (prev === 'SYP') return 'EGP';
      return 'USD';
    });
  };

  const buyImmediately = async (product: Product, quantity: number, playerId: string): Promise<Order> => {
    if (!user) {
      showToast(locale === 'ar' ? 'سجل دخولك أولاً للمتابعة' : 'Please login first', 'error');
      throw new Error('Unauthenticated');
    }

    const total = (product.discountPrice ?? product.price) * quantity;
    
    let currentBalance = 0;
    let costInCurrency = 0;
    let balanceField = 'balanceUSD';
    
    if (currency === 'SYP') {
      currentBalance = user.balanceSYP ?? 3500000;
      costInCurrency = total * 14000;
      balanceField = 'balanceSYP';
    } else if (currency === 'EGP') {
      currentBalance = user.balanceEGP ?? 12000;
      costInCurrency = total * 48;
      balanceField = 'balanceEGP';
    } else {
      currentBalance = user.balanceUSD ?? 250;
      costInCurrency = total;
      balanceField = 'balanceUSD';
    }

    if (currentBalance < costInCurrency) {
      const errorMsg = locale === 'ar' 
        ? `عذراً! رصيدك غير كافي. الرصيد الحالي: ${formatPrice(currentBalance / (currency === 'SYP' ? 14000 : currency === 'EGP' ? 48 : 1))} والتكلفة: ${formatPrice(total)}`
        : `Insufficient balance! Balance: ${formatPrice(currentBalance / (currency === 'SYP' ? 14000 : currency === 'EGP' ? 48 : 1))}, Cost: ${formatPrice(total)}`;
      showToast(errorMsg, 'error');
      throw new Error('INSUFFICIENT_BALANCE');
    }

    const newDeductedBalance = currentBalance - costInCurrency;
    try {
      const snap = await getDocs(query(collection(db, 'users'), where('uid', '==', user.uid)));
      if (!snap.empty) {
        const userDoc = snap.docs[0];
        await setDoc(userDoc.ref, { [balanceField]: newDeductedBalance }, { merge: true });
      } else {
        const updatedUser = { ...user, [balanceField]: newDeductedBalance };
        setUser(updatedUser);
        localStorage.setItem('store_user', JSON.stringify(updatedUser));
      }
    } catch (err) {
      const updatedUser = { ...user, [balanceField]: newDeductedBalance };
      setUser(updatedUser);
      localStorage.setItem('store_user', JSON.stringify(updatedUser));
    }

    const generateUUIDv4 = (): string => {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      });
    };

    let oranosData: any = null;
    let finalStatus: OrderStatus = 'processing';
    let isOranos = !!product.isOranosProduct;
    let oranosOrderId = "";
    let orderUuid = "";
    let replayApiData: any = null;

    if (isOranos) {
      orderUuid = generateUUIDv4();
      try {
        const oranosRes = await fetch("/api/oranos/order", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            product_id: product.oranosProductId,
            qty: quantity,
            playerId: playerId,
            order_uuid: orderUuid
          })
        });

        const oranosResult = await oranosRes.json();
        
        if (oranosResult.status === "OK" && oranosResult.data) {
          oranosData = oranosResult.data;
          oranosOrderId = oranosData.order_id;
          const oStatus = oranosData.status; // accept, reject, wait
          replayApiData = oranosData.replay_api || null;
          
          if (oStatus === "accept") {
            finalStatus = "completed";
          } else if (oStatus === "reject") {
            finalStatus = "canceled";
          } else {
            finalStatus = "processing";
          }
        } else {
          // If the Oranos API transaction failed, restore local user funds immediately
          const errorMsg = oranosResult.error || oranosResult.message || (locale === 'ar' ? "رصيد المطور غير كافي أو عائق معالجة آخر" : "Developer pool insufficiency or other processing barrier");
          
          try {
            const snap = await getDocs(query(collection(db, 'users'), where('uid', '==', user.uid)));
            if (!snap.empty) {
              const userDoc = snap.docs[0];
              await setDoc(userDoc.ref, { [balanceField]: currentBalance }, { merge: true });
            }
          } catch(recreditErr) {
            console.error("Recredit balance fails:", recreditErr);
          }
          
          const updatedUser = { ...user, [balanceField]: currentBalance };
          setUser(updatedUser);
          localStorage.setItem('store_user', JSON.stringify(updatedUser));

          const arText = `تعذر شحن الطلب التلقائي: ${errorMsg}`;
          const enText = `Automated fulfillment failed: ${errorMsg}`;
          showToast(locale === 'ar' ? arText : enText, 'error');
          throw new Error(`ORANOS_API_ERROR: ${errorMsg}`);
        }
      } catch (err: any) {
        if (err.message?.includes("ORANOS_API_ERROR")) {
          throw err;
        }
        
        // Re-credit balance immediately on network disconnect
        try {
          const snap = await getDocs(query(collection(db, 'users'), where('uid', '==', user.uid)));
          if (!snap.empty) {
            const userDoc = snap.docs[0];
            await setDoc(userDoc.ref, { [balanceField]: currentBalance }, { merge: true });
          }
        } catch(recreditErr) {
          console.error("Recredit balance error:", recreditErr);
        }
        
        const updatedUser = { ...user, [balanceField]: currentBalance };
        setUser(updatedUser);
        localStorage.setItem('store_user', JSON.stringify(updatedUser));

        showToast(locale === 'ar' ? 'عذراً! تعذر الاتصال بمركز الشحن التلقائي حالياً وتم رد رصيدك.' : 'Downstream API connection failure. Wallet funds re-credited.', 'error');
        throw new Error('ORANOS_API_NETWORK_ERROR');
      }
    }

    const orderId = isOranos ? `QT-${oranosOrderId.replace('ID_', '')}` : `QT-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
    const newOrder: Order = {
      id: orderId,
      userId: user.uid || 'guest',
      userName: user.name,
      userPhone: user.phone,
      items: [{ product, quantity }],
      total: total,
      status: finalStatus,
      timestamp: new Date().toISOString(),
      trackingSteps: [
         { status: finalStatus, timestamp: new Date().toISOString(), completed: true }
      ],
      playerId: playerId,
      isOranosOrder: isOranos,
      oranosOrderId: oranosOrderId || undefined,
      oranosOuuid: orderUuid || undefined,
      replayApi: replayApiData || undefined
    };

    // If finalStatus came back directly ascanceled (was rejected during creation), run automatic re-credit
    if (isOranos && finalStatus === 'canceled') {
      try {
        const snap = await getDocs(query(collection(db, 'users'), where('uid', '==', user.uid)));
        if (!snap.empty) {
          const userDoc = snap.docs[0];
          await setDoc(userDoc.ref, { [balanceField]: currentBalance }, { merge: true });
        }
      } catch(recreditErr) {
        console.error("Refund failed on cancel status:", recreditErr);
      }
      
      const updatedUser = { ...user, [balanceField]: currentBalance };
      setUser(updatedUser);
      localStorage.setItem('store_user', JSON.stringify(updatedUser));
      
      showToast(locale === 'ar' ? "تم رفض الطلب تلقائياً من المزود وإعادة الرصيد لمحفظتك فوراً!" : "Order was auto-rejected by network and balance has been refunded!", "error");
    }

    try {
      await setDoc(doc(db, 'orders', orderId), newOrder);
      if (finalStatus === 'completed') {
        showToast(locale === 'ar' 
          ? `يا للروعة! تم الشحن والتسليم تلقائياً فورا برقم: ${orderId}`
          : `Amazing! Order processed and delivered instantly: ${orderId}`, 'success');
      } else if (finalStatus === 'processing') {
        showToast(locale === 'ar' 
          ? `تم خصم الرصيد بنجاح والطلب قيد التسليم الآلي السريع: ${orderId}`
          : `Success! Balance deducted, Automated order pending delivery: ${orderId}`, 'success');
      } else {
        showToast(locale === 'ar' ? `تم رفض الطلب ورد كامل الرصيد.` : `Order rejected, balance fully refunded.`, 'error');
      }
      setOrders(prev => [newOrder, ...prev]);
    } catch(err) {
      const savedOrders = JSON.parse(localStorage.getItem('store_orders') || '[]');
      savedOrders.unshift(newOrder);
      localStorage.setItem('store_orders', JSON.stringify(savedOrders));
      setOrders(prev => [newOrder, ...prev]);
      showToast(locale === 'ar' ? 'تمت العملية محلياً مؤقتاً!' : 'Placed offline!', 'success');
    }
    
    navigate('order-tracker', { orderId: newOrder.id });
    return newOrder;
  };

  const placeWalletChargeRequest = async (amount: number, method: string, address: string): Promise<Order> => {
     if (!user) throw new Error('Auth required');
     const orderId = `QTC-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
     const newOrder: Order = {
       id: orderId,
       userId: user.uid || 'guest',
       userName: user.name,
       userPhone: user.phone,
       items: [],
       total: amount,
       status: 'pending',
       timestamp: new Date().toISOString(),
       trackingSteps: [ { status: 'pending', timestamp: new Date().toISOString(), completed: true } ],
       additionalNotes: `Method: ${method}, Address/Sender: ${address}`
     };
     try {
        await setDoc(doc(db, 'orders', orderId), newOrder);
        setOrders(prev => [newOrder, ...prev]);
     } catch(e) {
        const savedOrders = JSON.parse(localStorage.getItem('store_orders') || '[]');
        savedOrders.unshift(newOrder);
        localStorage.setItem('store_orders', JSON.stringify(savedOrders));
        setOrders(prev => [newOrder, ...prev]);
     }
     return newOrder;
  };

  // --- SECURE FIRESTORE ENGINE WRITES (Admin only) ---
  const updateSettings = async (data: any) => {
    try {
      await setDoc(doc(db, 'settings', 'general'), data, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'settings/general');
    }
  };

  const updateHomepageConfig = async (data: any) => {
    try {
      await setDoc(doc(db, 'homepage', 'layout'), data, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'homepage/layout');
    }
  };

  const updateCmsConfig = async (data: any) => {
    try {
      await setDoc(doc(db, 'cms', 'translations'), data, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'cms/translations');
    }
  };

  const updateUiConfig = async (data: any) => {
    try {
      await setDoc(doc(db, 'ui_config', 'features'), data, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'ui_config/features');
    }
  };

  const createProduct = async (p: Product) => {
    try {
      await setDoc(doc(db, 'products', p.id), p);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `products/${p.id}`);
    }
  };

  const updateProduct = async (p: Product) => {
    try {
      await setDoc(doc(db, 'products', p.id), p, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `products/${p.id}`);
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'products', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `products/${id}`);
    }
  };

  const createCategory = async (c: Category) => {
    try {
      await setDoc(doc(db, 'categories', c.id), c);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `categories/${c.id}`);
    }
  };

  const updateCategory = async (c: Category) => {
    try {
      await setDoc(doc(db, 'categories', c.id), c, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `categories/${c.id}`);
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'categories', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `categories/${id}`);
    }
  };

  const updateOrder = async (o: Order) => {
    // Optimistic local state update
    setOrders(prev => prev.map(item => item.id === o.id ? o : item));

    // Synchronize to local storage for personal fallbacks
    const savedOrders = JSON.parse(localStorage.getItem('store_orders') || '[]');
    const newSavedOrders = savedOrders.map((item: any) => item.id === o.id ? o : item);
    if (!savedOrders.some((item: any) => item.id === o.id)) {
      newSavedOrders.unshift(o);
    }
    localStorage.setItem('store_orders', JSON.stringify(newSavedOrders));

    // Synchronize to local storage for admin fallback list
    const savedAll = JSON.parse(localStorage.getItem('store_all_orders') || '[]');
    const newSavedAll = savedAll.map((item: any) => item.id === o.id ? o : item);
    if (!savedAll.some((item: any) => item.id === o.id)) {
      newSavedAll.unshift(o);
    }
    localStorage.setItem('store_all_orders', JSON.stringify(newSavedAll));

    // Balance crediting check for deposit orders
    if (o.status === 'completed') {
      const chargeItem = o.items.find(item => item.product.id?.startsWith('charge_'));
      if (chargeItem) {
        const targetUserId = o.userId;
        const depositAmount = Number(chargeItem.product.price) || 0;
        const gateCurrency = 'USD';
        try {
          const userRef = doc(db, 'users', targetUserId);
          const snap = await getDocs(query(collection(db, 'users'), where('uid', '==', targetUserId)));
          if (!snap.empty) {
            const userDoc = snap.docs[0];
            const currentData = userDoc.data();
            const currentBal = currentData.balanceUSD || 0;
            await setDoc(userDoc.ref, { balanceUSD: currentBal + depositAmount }, { merge: true });
          } else {
            // Local fallback inside localStorage if no Firestore profile yet
            const savedProfileStr = localStorage.getItem('store_user');
            if (savedProfileStr) {
              const savedProfile = JSON.parse(savedProfileStr);
              if (savedProfile.uid === targetUserId || targetUserId === 'guest') {
                savedProfile.balanceUSD = (savedProfile.balanceUSD || 0) + depositAmount;
                localStorage.setItem('store_user', JSON.stringify(savedProfile));
                setUser(savedProfile);
              }
            }
          }
        } catch (err) {
          console.error("Failed to credit order recharge in Firestore:", err);
        }
      }
    }

    try {
      await setDoc(doc(db, 'orders', o.id), cleanForFirestore(o), { merge: true });
    } catch (err) {
      console.warn("Firestore updateOrder write failed. Using local storage fallback.", err);
    }
  };

  const deleteOrder = async (orderId: string) => {
    // Update local React state instantly
    setOrders(prev => prev.filter(o => o.id !== orderId));

    // Update local storage
    const saved = JSON.parse(localStorage.getItem('store_orders') || '[]');
    localStorage.setItem('store_orders', JSON.stringify(saved.filter((o: any) => o.id !== orderId)));

    const savedAll = JSON.parse(localStorage.getItem('store_all_orders') || '[]');
    localStorage.setItem('store_all_orders', JSON.stringify(savedAll.filter((o: any) => o.id !== orderId)));

    try {
      await deleteDoc(doc(db, 'orders', orderId));
    } catch (err) {
      console.warn("Firestore deleteOrder failed:", err);
    }
  };

  // Automated booster/seeder that populates Firestore on click
  const seedAllDatabase = async () => {
    try {
      const batch = writeBatch(db);

      // Seed core configs
      batch.set(doc(db, 'settings', 'general'), DEFAULT_SETTINGS);
      batch.set(doc(db, 'homepage', 'layout'), DEFAULT_HOMEPAGE);
      batch.set(doc(db, 'cms', 'translations'), DEFAULT_CMS);
      batch.set(doc(db, 'ui_config', 'features'), DEFAULT_UI_CONFIG);

      // Seed default categories
      CATEGORIES.forEach((cat) => {
        batch.set(doc(db, 'categories', cat.id), {
          ...cat,
          isVisible: true,
          orderIndex: 0
        });
      });

      // Seed default products
      PRODUCTS.forEach((prod) => {
        batch.set(doc(db, 'products', prod.id), {
          ...prod,
          isVisible: true,
          isFeatured: true,
          createdAt: new Date().toISOString()
        });
      });

      await batch.commit();
      showToast(locale === 'ar' ? "تمت تهيئة قاعدة بيانات Firestore بنجاح وبشكل متكامل!" : "Firestore database seeded successfully!", "success");
    } catch (err) {
      console.error("Batch seed transaction failed:", err);
      showToast(locale === 'ar' ? "تعذر رفع البيانات للـ Firestore تلقائياً، يرجى مراجعة الصلاحيات." : "Could not seed data to Firestore automatically.", "error");
    }
  };

  const resetAndReinitDatabase = async () => {
    try {
      showToast(locale === 'ar' ? "جاري البدء في فرمتة وتصفير قاعدة البيانات..." : "Starting database formatting...", "info");
      
      // 1. Fetch and delete products, categories, orders from Firestore
      const productsSnap = await getDocs(collection(db, 'products'));
      const categoriesSnap = await getDocs(collection(db, 'categories'));
      const ordersSnap = await getDocs(collection(db, 'orders'));
      
      const batch = writeBatch(db);
      
      productsSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
      });
      
      categoriesSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
      });
      
      ordersSnap.forEach((docSnap) => {
        batch.delete(docSnap.ref);
      });
      
      // 2. Set default configuration templates
      batch.set(doc(db, 'settings', 'general'), DEFAULT_SETTINGS);
      batch.set(doc(db, 'homepage', 'layout'), DEFAULT_HOMEPAGE);
      batch.set(doc(db, 'cms', 'translations'), DEFAULT_CMS);
      batch.set(doc(db, 'ui_config', 'features'), DEFAULT_UI_CONFIG);
      
      await batch.commit();
      showToast(locale === 'ar' ? "تمت الفرمتة وإعادة تهيئة الإعدادات بنجاح! قاعدة البيانات الآن خالية من أي منتجات وهمية ومستعدة للمزامنة." : "Database formatted and settings reconfigured successfully! The database is now completely clean and ready to sync.", "success");
    } catch (err: any) {
      console.error("Database formatting reset failed:", err);
      showToast(locale === 'ar' ? `فشلت الفرمتة: ${err.message}` : `Formatting failed: ${err.message}`, "error");
    }
  };

  const getOranosConfig = async () => {
    if (!firebaseUser) return null;
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await fetch("/api/admin/oranos/config", {
        headers: {
          "Authorization": `Bearer ${idToken}`
        }
      });
      return await res.json();
    } catch (e) {
      console.error("fetch oranos config fails:", e);
      return { configured: false, balance: "0", email: "", message: "Backend offline." };
    }
  };

  const updateOranosConfig = async (apiToken: string) => {
    if (!firebaseUser) throw new Error("Auth required");
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await fetch("/api/admin/oranos/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${idToken}`
        },
        body: JSON.stringify({ apiToken })
      });
      return await res.json();
    } catch (e) {
      console.error("update oranos config fails:", e);
      throw e;
    }
  };

  const syncOranosCatalog = async () => {
    if (!firebaseUser) throw new Error("Auth required");
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await fetch("/api/admin/oranos/sync-products", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${idToken}`
        }
      });
      return await res.json();
    } catch (e: any) {
      console.error("sync oranos catalog fails:", e);
      throw e;
    }
  };

  const navigate = (route: StoreRoute, params: NavigationParams = {}) => {
    setIsHamburgerOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });

    switch (route) {
      case 'home':
        routerNavigate('/');
        break;
      case 'login':
        routerNavigate('/login');
        break;
      case 'complete-profile':
        routerNavigate('/complete-profile');
        break;
      case 'categories':
        routerNavigate('/categories');
        break;
      case 'settings':
        routerNavigate('/profile');
        break;
      case 'contact':
        routerNavigate('/contact');
        break;
      case 'order-history':
        routerNavigate('/orders');
        break;
      case 'admin':
        routerNavigate('/admin');
        break;
      case 'product-detail':
        routerNavigate(`/product/${params.productId || ''}`);
        break;
      case 'order-tracker':
        routerNavigate(`/orders/${params.orderId || ''}`);
        break;
      case 'wallet':
        routerNavigate('/wallet');
        break;
      case 'add-balance':
        routerNavigate('/add-balance');
        break;
      case 'category-products':
        if (params.categoryId) {
          const queryStr = params.searchQuery ? `?q=${encodeURIComponent(params.searchQuery)}` : '';
          routerNavigate(`/category/${params.categoryId}${queryStr}`);
        } else if (params.searchQuery) {
          routerNavigate(`/products?q=${encodeURIComponent(params.searchQuery)}`);
        } else {
          routerNavigate('/products');
        }
        break;
      default:
        routerNavigate('/');
    }
  };

  return (
    <StoreContext.Provider
      value={{
        locale,
        dir,
        toggleLanguage,
        currency,
        toggleCurrency,
        formatPrice,
        toast,
        showToast,
        hideToast,
        confirmDialog,
        showConfirm,
        hideConfirm,
        notifications,
        addNotification,
        markNotificationRead,
        systemNotificationPermission,
        requestSystemNotificationPermission,
        markAllNotificationsAsRead,
        user,
        firebaseUser,
        loginWithGoogle,
        logout,
        updateProfile,
        isProfileComplete,
        orders,
        buyImmediately,
        placeWalletChargeRequest,
        currentRoute,
        currentParams,
        navigate,
        products,
        categories,
        isHamburgerOpen,
        setIsHamburgerOpen,

        // Realtime DB exposure
        isDbLoading,
        isAdminMode,
        settings,
        updateSettings,
        homepageConfig,
        updateHomepageConfig,
        cmsConfig,
        updateCmsConfig,
        uiConfig,
        updateUiConfig,
        seedAllDatabase,
        resetAndReinitDatabase,

        // Oranos API dynamic context
        getOranosConfig,
        updateOranosConfig,
        syncOranosCatalog,

        // Admin panel DB helpers
        createProduct,
        updateProduct,
        deleteProduct,
        createCategory,
        updateCategory,
        deleteCategory,
        updateOrder,
        deleteOrder,
        usersList
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
